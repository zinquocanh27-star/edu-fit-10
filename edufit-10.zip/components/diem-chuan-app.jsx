"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import {
  GraduationCap, MapPin, ChevronDown, Home, Landmark, UserCircle2, Bookmark,
  FileText, MessageCircle, Search, Plus, Pencil, Trash2, X, ArrowRight,
  TrendingUp, CheckCircle2, School, GripVertical, Sparkles, Calculator,
  ShieldCheck, Users, BarChart3, MessageSquare, Send, Scale, Phone, Mail,
  Globe, Share2 as Facebook, Image as ImageIcon, Star, Eye, Calendar, BadgeCheck,
  ClipboardList, Clock, RotateCcw, Award, ChevronRight, Filter, Bot,
  Heart, AlertTriangle, Target, BookOpen,
  Megaphone, Radio, ThumbsUp, Newspaper, PlayCircle,
} from "lucide-react";

/* ============================================================================
 * SEED DATA — ĐIỂM CHUẨN THẬT (Sở GD&ĐT Hà Nội)
 * 2024: thang 50 (Toán×2 + Văn×2 + Ngoại ngữ)
 * 2025, 2026: thang 30 (Toán + Văn + Ngoại ngữ, không hệ số) — theo QĐ 2606/QĐ-SGDĐT 19/6/2026
 * ========================================================================== */

const DISTRICTS = [
  "Đống Đa", "Cầu Giấy", "Thanh Xuân", "Hà Đông", "Hai Bà Trưng", "Hoàn Kiếm",
  "Ba Đình", "Hoàng Mai", "Long Biên", "Tây Hồ", "Nam Từ Liêm", "Bắc Từ Liêm",
  "Đông Anh", "Gia Lâm", "Sóc Sơn", "Thanh Trì", "Hoài Đức", "Đan Phượng",
  "Thạch Thất", "Quốc Oai", "Chương Mỹ", "Thanh Oai", "Thường Tín", "Ứng Hòa",
  "Mỹ Đức", "Ba Vì", "Sơn Tây", "Phúc Thọ", "Mê Linh", "Phú Xuyên",
];

const COLOR_THEMES = [
  { bg: "#EEF2FF", text: "#4338CA" },
  { bg: "#ECFDF5", text: "#047857" },
  { bg: "#FFF7ED", text: "#C2410C" },
  { bg: "#FDF2F8", text: "#BE185D" },
  { bg: "#F0F9FF", text: "#0369A1" },
];

function themeFor(id) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) >>> 0;
  return COLOR_THEMES[hash % COLOR_THEMES.length];
}

function slugId(name) {
  return (
    "s_" +
    name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/đ/g, "d")
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
  );
}

// 8 trường mẫu — có ĐẦY ĐỦ thông tin chi tiết (địa chỉ, liên hệ, giới thiệu, ảnh...)
const DETAILED_SCHOOLS = [
  {
    id: "s1",
    name: "THPT Kim Liên",
    district: "Đống Đa",
    address: "Số 1 Phương Mai, Đống Đa, Hà Nội",
    type: "Công lập",
    quota: 675,
    tuition: 217000,
    scores: { 2024: 43.25, 2025: 25.5, 2026: 26.0 },
    founded: 1974,
    studentCount: 2400,
    accredited: true,
    rating: 4.6,
    views: 5200,
    phone: "024 3852 2204",
    email: "c3kimlien@hanoiedu.vn",
    facebook: "facebook.com/thptkimlien",
    website: "thptkimlien.edu.vn",
    intro:
      "Trường THPT Kim Liên là một trong những trường THPT công lập hàng đầu của Hà Nội, nổi tiếng với chất lượng đào tạo cao và tỷ lệ học sinh đỗ đại học luôn ở mức top đầu thành phố. Trường có truyền thống lâu năm trong giảng dạy các môn khoa học tự nhiên và đội tuyển học sinh giỏi quốc gia.",
    distanceKm: 3.4,
    busService: true,
    admissionRate: ">80%",
  },
  {
    id: "s2",
    name: "THPT Yên Hòa",
    district: "Cầu Giấy",
    address: "Số 3 Trung Kính, Yên Hòa, Cầu Giấy, Hà Nội",
    type: "Công lập",
    quota: 700,
    tuition: 217000,
    scores: { 2024: 42.5, 2025: 25.0, 2026: 26.0 },
    founded: 1996,
    studentCount: 2300,
    accredited: true,
    rating: 4.5,
    views: 4800,
    phone: "024 3784 6463",
    email: "c3yenhoa@hanoiedu.vn",
    facebook: "facebook.com/thptyenhoa",
    website: "thptyenhoa.edu.vn",
    intro:
      "THPT Yên Hòa được biết đến là một trong những trường có tỷ lệ chọi cao nhất Hà Nội mỗi năm, đồng thời là trường có thành tích học tập và thi đại học rất tốt, đặc biệt mạnh ở khối tự nhiên.",
    distanceKm: 5.1,
    busService: true,
    admissionRate: ">80%",
  },
  {
    id: "s3",
    name: "THPT Nhân Chính",
    district: "Thanh Xuân",
    address: "Số 1 Ngụy Như Kon Tum, Nhân Chính, Thanh Xuân, Hà Nội",
    type: "Công lập",
    quota: 630,
    tuition: 217000,
    scores: { 2024: 41.75, 2025: 24.5, 2026: 25.0 },
    founded: 1992,
    studentCount: 2100,
    accredited: true,
    rating: 4.4,
    views: 3900,
    phone: "024 3556 8221",
    email: "c3nhanchinh@hanoiedu.vn",
    facebook: "facebook.com/thptnhanchinh",
    website: "c3nhanchinh.edu.vn",
    intro:
      "THPT Nhân Chính nằm tại trung tâm quận Thanh Xuân, là một trong những trường tốp đầu khu vực phía Nam Hà Nội, có tỷ lệ chọi và điểm chuẩn luôn thuộc nhóm cao của thành phố.",
    distanceKm: 4.2,
    busService: true,
    admissionRate: "75%",
  },
  {
    id: "s4",
    name: "THPT Lê Quý Đôn - Hà Đông",
    district: "Hà Đông",
    address: "Đường Lê Lợi, Hà Đông, Hà Nội",
    type: "Công lập",
    quota: 560,
    tuition: 217000,
    scores: { 2024: 42.5, 2025: 25.5, 2026: 26.0 },
    founded: 1959,
    studentCount: 1900,
    accredited: true,
    rating: 4.5,
    views: 3600,
    phone: "024 3382 4451",
    email: "c3lequydon-hadong@hanoiedu.vn",
    facebook: "facebook.com/thptlequydonhadong",
    website: "lequydonhadong.edu.vn",
    intro:
      "THPT Lê Quý Đôn - Hà Đông là trường có điểm chuẩn cao nhất khu vực Hà Đông trong nhiều năm liền, nổi bật với phong trào học tập sôi nổi và tỷ lệ học sinh giỏi cao.",
    distanceKm: 8.7,
    busService: true,
    admissionRate: ">80%",
  },
  {
    id: "s5",
    name: "THPT Việt Đức",
    district: "Hai Bà Trưng",
    address: "Số 47 Lý Thường Kiệt, Hai Bà Trưng, Hà Nội",
    type: "Công lập",
    quota: 650,
    tuition: 217000,
    scores: { 2024: 43.0, 2025: 25.25, 2026: 25.75 },
    founded: 1955,
    studentCount: 2200,
    accredited: true,
    rating: 4.6,
    views: 4500,
    phone: "024 3826 2468",
    email: "c3vietduc@hanoiedu.vn",
    facebook: "facebook.com/thptvietduc",
    website: "vietduc.edu.vn",
    intro:
      "THPT Việt Đức là một trong những trường THPT lâu đời và uy tín nhất của Hà Nội, có truyền thống đào tạo học sinh giỏi quốc gia và quốc tế qua nhiều thế hệ.",
    distanceKm: 4.9,
    busService: true,
    admissionRate: ">80%",
  },
  {
    id: "s6",
    name: "THPT Phan Đình Phùng",
    district: "Ba Đình",
    address: "Số 28 Cửa Bắc, Ba Đình, Hà Nội",
    type: "Công lập",
    quota: 600,
    tuition: 217000,
    scores: { 2024: 42.75, 2025: 25.25, 2026: 25.75 },
    founded: 1981,
    studentCount: 2000,
    accredited: true,
    rating: 4.5,
    views: 4100,
    phone: "024 3716 0394",
    email: "c3phandinhphung@hanoiedu.vn",
    facebook: "facebook.com/thptphandinhphung",
    website: "phandinhphung.edu.vn",
    intro:
      "THPT Phan Đình Phùng là trường công lập tốp đầu của quận Ba Đình, có truyền thống giảng dạy chất lượng cao và đội ngũ giáo viên giàu kinh nghiệm.",
    distanceKm: 3.1,
    busService: false,
    admissionRate: ">80%",
  },
  {
    id: "s7",
    name: "THPT Hoàng Văn Thụ",
    district: "Hoàng Mai",
    address: "Đường Tân Mai, Hoàng Mai, Hà Nội",
    type: "Công lập",
    quota: 540,
    tuition: 217000,
    scores: { 2024: 36.5, 2025: 21.0, 2026: 21.5 },
    founded: 1988,
    studentCount: 1700,
    accredited: true,
    rating: 4.1,
    views: 2300,
    phone: "024 3636 1234",
    email: "c3hoangvanthu@hanoiedu.vn",
    facebook: "facebook.com/thpthoangvanthu",
    website: "hoangvanthu.edu.vn",
    intro:
      "THPT Hoàng Văn Thụ phục vụ nhu cầu học tập của học sinh khu vực Hoàng Mai, với cơ sở vật chất ngày càng được nâng cấp và chất lượng giảng dạy ổn định.",
    distanceKm: 7.5,
    busService: false,
    admissionRate: "65%",
  },
  {
    id: "s8",
    name: "THPT Nguyễn Gia Thiều",
    district: "Long Biên",
    address: "Số 1 Thạch Bàn, Long Biên, Hà Nội",
    type: "Công lập",
    quota: 585,
    tuition: 217000,
    scores: { 2024: 41.75, 2025: 25.0, 2026: 25.25 },
    founded: 1973,
    studentCount: 1950,
    accredited: true,
    rating: 4.4,
    views: 3300,
    phone: "024 3827 1156",
    email: "c3nguyengiathieu@hanoiedu.vn",
    facebook: "facebook.com/thptnguyengiathieu",
    website: "nguyengiathieu.edu.vn",
    intro:
      "THPT Nguyễn Gia Thiều là trường công lập tốp đầu khu vực Long Biên, có chất lượng đào tạo tốt và tỷ lệ đỗ đại học cao trong nhiều năm liên tiếp.",
    distanceKm: 6.3,
    busService: true,
    admissionRate: "78%",
  },
];

// Điểm chuẩn NV1 năm 2026 — toàn bộ 122 trường công lập Hà Nội
// Theo Quyết định 2606/QĐ-SGDĐT ngày 19/6/2026 của Sở GD&ĐT Hà Nội
const SCORES_2026_FULL = {
  "THPT Nguyễn Trãi - Ba Đình": 22.25, "THPT Phạm Hồng Thái": 24.0, "THPT Phan Đình Phùng": 25.75,
  "THPT Ba Vì": 14.0, "THPT Bất Bạt": 13.5, "THPT Minh Quang": 10.0, "THPT Ngô Quyền - Ba Vì": 16.0,
  "THPT Quảng Oai": 16.75, "Phổ thông Dân tộc nội trú": 19.0, "TH, THCS và THPT Minh Châu": 8.5,
  "THPT Nguyễn Thị Minh Khai": 25.75, "THPT Thượng Cát": 22.0, "THPT Xuân Đỉnh": 24.5,
  "THPT Cầu Giấy": 24.5, "THPT Yên Hòa": 25.75, "THPT Hoàng Quốc Chi": 23.0, "THPT Chúc Động": 17.5,
  "THPT Chương Mỹ A": 21.5, "THPT Chương Mỹ B": 15.25, "THPT Xuân Mai": 16.25,
  "THPT Nguyễn Văn Trỗi": 14.0, "THPT Đan Phượng": 21.25, "THPT Hồng Thái": 16.75,
  "THPT Tân Lập": 19.5, "THPT Thọ Xuân": 16.0, "THPT Bắc Thăng Long": 21.25, "THPT Cổ Loa": 21.25,
  "THPT Đông Anh": 18.75, "THPT Liên Hà": 21.5, "THPT Vân Nội": 18.25, "THPT Phúc Thịnh": 15.75,
  "THPT Việt Hùng": 17.0, "THPT Đống Đa": 22.75, "THPT Kim Liên": 26.0,
  "THPT Lê Quý Đôn - Đống Đa": 24.75, "THPT Quang Trung - Đống Đa": 23.75, "THPT Hoàng Cầu": 21.25,
  "THPT Cao Bá Quát - Gia Lâm": 23.25, "THPT Dương Xá": 20.0, "THPT Nguyễn Văn Cừ": 19.0,
  "THPT Yên Viên": 20.0, "THPT Lê Lợi": 21.5, "THPT Lê Quý Đôn - Hà Đông": 26.0,
  "THPT Quang Trung - Hà Đông": 24.0, "THPT Trần Hưng Đạo - Hà Đông": 20.5,
  "THPT Đoàn Kết - Hai Bà Trưng": 22.5, "THPT Thăng Long": 25.5, "THPT Trần Nhân Tông": 24.0,
  "THPT Hoài Đức A": 22.0, "THPT Hoài Đức B": 20.25, "THPT Vạn Xuân - Hoài Đức": 18.5,
  "THPT Hoài Đức C": 17.75, "THPT Trần Phú - Hoàn Kiếm": 24.75, "THPT Việt Đức": 25.75,
  "THPT Hoàng Văn Thụ": 21.75, "THPT Trương Định": 22.75, "THPT Việt Nam - Ba Lan": 23.75,
  "THPT Đỗ Mười": 20.5, "THPT Lý Thường Kiệt": 23.5, "THPT Nguyễn Gia Thiều": 25.25,
  "THPT Phúc Lợi": 20.25, "THPT Thạch Bàn": 20.0, "THPT Mê Linh": 20.0, "THPT Quang Minh": 15.0,
  "THPT Tiền Phong": 16.25, "THPT Tiến Thịnh": 14.0, "THPT Tự Lập": 14.0, "THPT Yên Lãng": 17.5,
  "THPT Hợp Thanh": 12.5, "THPT Mỹ Đức A": 17.25, "THPT Mỹ Đức B": 15.0, "THPT Mỹ Đức C": 9.0,
  "THPT Đại Mỗ": 20.0, "THPT Trung Văn": 21.5, "THPT Xuân Phương": 22.5, "THPT Mỹ Đình": 24.25,
  "THPT Đồng Quan": 16.5, "THPT Phú Xuyên A": 17.0, "THPT Phú Xuyên B": 14.0, "THPT Tân Dân": 14.25,
  "THPT Ngọc Tảo": 15.25, "THPT Phúc Thọ": 15.25, "THPT Vân Cốc": 14.25,
  "THPT Cao Bá Quát - Quốc Oai": 17.0, "THPT Minh Khai - Quốc Oai": 16.0, "THPT Quốc Oai": 21.25,
  "THPT Phan Huy Chú - Quốc Oai": 16.0, "THPT Đa Phúc": 18.5, "THPT Kim Anh": 17.0,
  "THPT Minh Phú": 15.25, "THPT Sóc Sơn": 19.75, "THPT Trung Giã": 15.5, "THPT Xuân Giang": 15.5,
  "THPT Tùng Thiện": 19.25, "THPT Xuân Khanh": 14.5, "THPT Tây Hồ": 22.75,
  "THPT Bắc Lương Sơn": 13.0, "Hai Bà Trưng - Thạch Thất": 14.0,
  "THPT Phùng Khắc Khoan - Thạch Thất": 16.25, "THPT Thạch Thất": 18.25, "THPT Minh Hà": 14.75,
  "THPT Nguyễn Du - Thanh Oai": 16.5, "THPT Thanh Oai A": 16.5, "THPT Thanh Oai B": 19.25,
  "THPT Ngọc Hồi": 22.0, "THPT Ngô Thì Nhậm": 20.75, "THPT Đông Mỹ": 19.25,
  "THPT Nguyễn Quốc Trinh": 18.5, "THPT Nhân Chính": 25.0, "THPT Trần Hưng Đạo - Thanh Xuân": 22.75,
  "THPT Khương Đình": 22.0, "TH, THCS và THPT Khương Hạ": 20.0, "THPT Lý Tử Tấn": 15.0,
  "THPT Nguyễn Trãi - Thường Tín": 17.5, "THPT Tô Hiệu - Thường Tín": 14.75,
  "THPT Thường Tín": 19.5, "THPT Vân Tảo": 16.0, "THPT Đại Cường": 12.0, "THPT Lưu Hoàng": 11.0,
  "THPT Trần Đăng Ninh": 14.75, "THPT Ứng Hòa A": 16.0, "THPT Ứng Hòa B": 13.0,
};

// Map quận/huyện gần đúng theo khu vực tuyển sinh, dùng để gán cho các trường chỉ có điểm chuẩn
const DISTRICT_BY_KEYWORD = [
  [/Ba Đình/i, "Ba Đình"], [/Ba Vì|Bất Bạt|Minh Quang|Tản Lĩnh/i, "Ba Vì"],
  [/Minh Khai|Thượng Cát|Xuân Đỉnh|Cầu Giấy|Yên Hòa|Hoàng Quốc Chi/i, "Cầu Giấy"],
  [/Chương Mỹ|Xuân Mai/i, "Chương Mỹ"], [/Trỗi|Đan Phượng|Hồng Thái|Tân Lập|Thọ Xuân/i, "Đan Phượng"],
  [/Đông Anh|Bắc Thăng Long|Cổ Loa|Liên Hà|Vân Nội/i, "Đông Anh"],
  [/Phúc Thịnh|Việt Hùng|Đống Đa|Kim Liên|Lê Quý Đôn - Đống Đa|Quang Trung - Đống Đa|Hoàng Cầu/i, "Đống Đa"],
  [/Gia Lâm|Dương Xá|Nguyễn Văn Cừ|Yên Viên|Lê Lợi/i, "Gia Lâm"],
  [/Hà Đông/i, "Hà Đông"], [/Hai Bà Trưng|Đoàn Kết|Thăng Long|Trần Nhân Tông/i, "Hai Bà Trưng"],
  [/Hoài Đức/i, "Hoài Đức"], [/Hoàn Kiếm|Trần Phú/i, "Hoàn Kiếm"],
  [/Việt Đức|Hoàng Văn Thụ|Trương Định|Việt Nam - Ba Lan|Đỗ Mười|Lý Thường Kiệt/i, "Hai Bà Trưng"],
  [/Long Biên|Nguyễn Gia Thiều|Phúc Lợi|Thạch Bàn/i, "Long Biên"],
  [/Mê Linh|Quang Minh|Tiền Phong|Tiến Thịnh|Tự Lập|Yên Lãng/i, "Mê Linh"],
  [/Mỹ Đức|Hợp Thanh/i, "Mỹ Đức"],
  [/Đại Mỗ|Trung Văn|Xuân Phương|Mỹ Đình|Nam Từ Liêm/i, "Nam Từ Liêm"],
  [/Phú Xuyên|Tân Dân/i, "Phú Xuyên"], [/Phúc Thọ|Ngọc Tảo|Vân Cốc/i, "Phúc Thọ"],
  [/Quốc Oai|Phan Huy Chú/i, "Quốc Oai"],
  [/Sóc Sơn|Đa Phúc|Kim Anh|Minh Phú|Trung Giã|Xuân Giang/i, "Sóc Sơn"],
  [/Sơn Tây|Tùng Thiện|Xuân Khanh/i, "Sơn Tây"], [/Tây Hồ/i, "Tây Hồ"],
  [/Thạch Thất|Bắc Lương Sơn|Phùng Khắc Khoan|Minh Hà|Hai Bà Trưng - Thạch Thất/i, "Thạch Thất"],
  [/Thanh Oai|Nguyễn Du - Thanh Oai/i, "Thanh Oai"],
  [/Thanh Trì|Ngọc Hồi|Ngô Thì Nhậm|Đông Mỹ|Nguyễn Quốc Trinh/i, "Thanh Trì"],
  [/Nhân Chính|Trần Hưng Đạo - Thanh Xuân|Khương Đình|Khương Hạ|Thanh Xuân/i, "Thanh Xuân"],
  [/Thường Tín|Lý Tử Tấn|Nguyễn Trãi - Thường Tín|Tô Hiệu|Vân Tảo/i, "Thường Tín"],
  [/Ứng Hòa|Đại Cường|Lưu Hoàng|Trần Đăng Ninh/i, "Ứng Hòa"],
];

function guessDistrict(name) {
  for (const [re, district] of DISTRICT_BY_KEYWORD) {
    if (re.test(name)) return district;
  }
  return "Khác";
}

function buildSeedSchools() {
  const detailedNames = new Set(DETAILED_SCHOOLS.map((s) => s.name));
  const lightweight = Object.entries(SCORES_2026_FULL)
    .filter(([name]) => !detailedNames.has(name))
    .map(([name, score2026]) => ({
      id: slugId(name),
      name,
      district: guessDistrict(name),
      address: "",
      type: "Công lập",
      quota: 0,
      tuition: 217000,
      scores: { 2026: score2026 },
      founded: null,
      studentCount: null,
      accredited: false,
      rating: null,
      views: null,
      phone: "",
      email: "",
      facebook: "",
      website: "",
      intro: "",
      distanceKm: null,
      busService: false,
      admissionRate: "",
    }));
  return [...DETAILED_SCHOOLS, ...lightweight];
}

const BOY_GRAD_IMG = "data:image/webp;base64,UklGRhCdAABXRUJQVlA4WAoAAAAQAAAAowEA+wEAQUxQSPA7AAANp+IgkiQpih7s4N8cdBX/nYSIyHUfkeCT0KQqARbwD5z66NjUqdqkkm3ZJyFBkuSwbWqxi8WtKvz/gwmQAJ0HRPR/AvBfbUD1bv2r2Gc0sW6wAdtj2PaRXBN7tZR0Qgk2S3VC0iZI3Adb2QQp+wC7NkHSAdhtE6AcAEZutQFqB5IJAVS9kbRHT6rwXna24AGwA1DVKwK94/Q74puSnpAf0qp/B5K0SD7Aq4EGMMYs76o2XGP4NwCQk2zY2jg8fljnK621au1r1Zran0BcNauvoFX9kkVbfiBJ9f61Sku1ReW/1pKgL9ryRZIdlbQcQe0ZFznDnlS96q2VvRp7dva06QxX/kLnlpZ3UD1KtmAHqh609RvuaH+jqmpx7draeF1DnBQ/k2TYKgCo+kqScAXpG7m77jfb5rFCfpkuYPjimSTufcbMAIx2ptj9W5ErFI+Yw7kxfFHtQJEcYzjJp0ZIDI+EL2BJm8KmGzw4fwKI3MJEM+Dq/Z3ttoGMbc9cGwDkXV22rTbD2NB77490AxzzPul5V5JuthOAnDAk+0xtukk/JZxxfUs2QJIAQHpA5km4BZA04x0gw7XJbIIUAFiQ7LMEIMlNkAkAk3vv+QIsYTobJZG/21lLDQAXksmcg20PriX74hjHAJuPbZP8AF7Mv3CcgqBt2zQpf9T/90GIiAnIvCn5tVP51Az7gw7SHzR9pM6KaVvvmCeKaoZ4x00umG/ScAyb3ikeDKbBaxZBs03ZS9ufvlo9HAyx1xXv9T3JI6tIkrpRKEn0r6WtKv629CEyb6H4zrRNwemrbZO4Ahc+pChwOMUUDFATzBStwZKAmXtNoCweJ86z7FuSJEuSJNsiEvO615/U//9cZLjyg5l7uKt2SWjfI2ICPEuS5Ei2bVsiZh5RNeacG6Pu/v/v2gfDheaszAg3bVTNMTfObkRMAC9t29tIkqQ97weANHMRUZk9Ws9s49//FrTWoqo6MyPc3Ywk8L0HmSXSBN36LCImwJNk27IlSZK01rnEpvMfrqrQO6vx3v9EJkzM7YiYgL/4v///tT5O5pazuIwzGNnKeVF84BvgSZlSGJXCTeSLzIN3w4gBgkGKLAIfDNoUaNUqZMvGpyJgAF9BhIioWJDEwDAEDiAKQFxhsBYVqFVrHZJQboD89xjYW8ZzGOm67FQUEDE77MSsnEZEBp2dwrQZaADGPtkYIDXNU+sY9Nn7cn6L3YA0SGj2ZtFEQrCsxj2YpY7NCtA4NIwOGmozjYgAh7ZLxrZrKTE3evKJ9l/K96QHe7BveSyYBTqQ67qzExNNgIyYA6MDgxFKJJ1wBBsGZpjJ4Z4QNDPMtnGNdemej/VsS58kibwZ+WA0KwaJaxL4FBEtApGz1tQAwU4KJAj0IQdmOAwDnLVobCcCZGcVEAdXM0CA5SgW5JW9dx9rJmk+v8YAzd4AewCMNQNortMSjEMh1JoBCMRcwzLbTDDpJ2rCgI4yDA3sFPfknrAUREYuEfeHgcAdGI4U5GmZX9rYeuizI0ngRSGA0BJhdcUknCtmxmlRSM+QgLgTBgEis+BKJsymSBh7ornm6TkFREjiWb4oJIyoAv0jD8coYwzrtTGQuZ6mOca2h2kwTE0IENdD4iaCHoQQMa5DQxBncadAWYBI2Cjjpb2DvBYQkO+VRxsitK3Tc/PJ+NJIp59+fj/HTCABE7inVe7mTnp5dvKCGUTizQRIWZk1LJgwKAVDMqSH9+VfniQifLamudI7r6z76fyxUufjpPOrWWNxhZ2SBrKYa6pU5KUQRMwKIYDx2ISBZSEIAn7td7QM5XlbViQUXxJHxli+xT/8sx8PEDZgZKs7wQ6ZEBiYKwi9wADki0nyRUF+YPWc2jhnvFUSX5Bfb/ERPxSHr+BjSyINV+7urABNQMhc8mYAAtgbgH3lhzZudfSBjUpeknz/8hKnbe0GvASMd41vFDBfIX920X2cvTznkPiCuGzf9FSCPoyWJvbOtwqJ/DUamhgjGRrzclga30fpqYhiJpz4V8rfpYdq5EoTUq8GkL2LBEs6/KXLEqQzNjgvhlJMWjqIFPAvDcuE6x73FPhaAPU1/nyukYDErjdQz1FMfCnk8od8w2uEjfCOC115HBlKyQshu8yH5+XP42UMYWLHAXGv4+NebYKvw6/jy/HPPx/KuYDY+6lzp+ZhWeSFkD1r1Ti3AykZ7zrcc3LvnnLwdQBEdW/tnSkR2ndkOTpjrPhCCFeiLsuHbQXed2R35+7R8ErgDMj4+r/+P1RZ7Hytbfd2poOvA0WZvJTv+rKtSHjXEeZ0jwkUeR0YEsv76z/bvkUJBtp1RK9xb1fP4OsgpT/isK4vcepZwvsOt8t7dTZV5GXAKOK0Ph9PvdTo1r6D3rvq2iWOvgzIZJ/aWa86r6p454Xu8dybKvM6YKnwNr5M2UvNrshdB9ycc2OY6MsAZtD6aX72+xotUfM85jrdd6cSfBkggqVMpWep6xZ7j7l73cGqk9fSVpmhv63TszJ3Hq0rnfua48z4QhCMMj+fvn3Up4yifddkTkzVbJqXMguqZco/vn09YoP3G0zPriG7esf4Oki25ufxfWnbBxSjHQfp2hSZVMJLKZH1Nf6fdxQ5Au85MukjDxYb8ZVIVJ95z9f1bWvhfWeayeG910Hi64AEvX0Jr5q0DeEdB9z2et513nfzYppSD/2HH7Zf+lQA77mqydj38/jx1ZAyjy/z+U/bc0uCsPYbk27nueay4isBDpAO40+np6PAaL9R7Lj64Xtg6pUQaT0/n38asylFlvvG2HilfVaV80IAAX36kn/+iKfGAE3XqJmst+uRYyb4Sgjjw3G8Qc9pQgzsGmnWfbX3vJu8EiDJ2/RU3r5tr/MQmrbBDqfPveZufCl+s0yxMD58aICNs8gcax7rGAZfCslZn6b1z9tTvQv2jYy19uXxoKzklfi1Ss1YvudLNRbaa4DG+Vse/8sUtuNzIbCmp+WXbKYEYr+bYPlT/2djKKT8VICDKNO0/LI+TS3B3mu/HvntlzNVsuO1EBaHeXkPL5RmdrwlnX4u0+ilBPhKgJBzfh7fTryEsXcbGJjWk4B8NQBznLK3vi6ikeCdhkOrj5xREHwxFO7tMJ1/2Y4f78jWXsP2wQtl8OfyepoaSSn9z99OEWLHl9zm1gd//+c1+mKIpH35+v5HMp2S+mZCf/rl+G9SsebFAFlqX/TP9PY9a4m0DdTL+x+PxZWh8mIgm+nHmLUsPgSNN7X//L2u6UXiiwEIHHN86Fgw74tgLmwFmPi+n9XFyMsp22YZ9dgMvu/aUzcdsd7Huu9qB18MEOPtnX/eus070oinAMgA0wgY9Tjuazrh9XTkOH/M/+otkdenJQ/lXAYfmA4A95x1P9c/uPW1AH87Pf2zj4Fp/3AWT/32t0fGlyKjvn38oQ2Bb0pZbwJ9Ka3pD0fvXfYeKrwSjljGsdnRg9cnXsP7vmPJ32JmVZIx94J8FmS39f3lx8WSfgcgsfAhkLtBCGnp+qdD71Rgau2oz0JkmdZAG+JzGFZy0FxZOvUZMCWX52eNKnGJ+ST0kC9sx5qaSMI/Fc5Yl0ntCeT9J2Xhl/5jWli/X/JsyHcmyfPYHwuqNke45ig22n1IkH1EZnDhvbIEkmcXueufi501kMWmAO+8ECzly9yrrN/N9Z3kO43kMQQI3SnWTKWvRzaMJUC7jYy69hePEeJqe+O1JX/6TFcSnmdlN3s+guW1RqSwfhejCRKwffKG4K0A2xN/gzJTB+XlC+cBRkj7Kn5RY3lfnp6XEBZXGHflWeWvMk3srfVB1KZkj0dCycuBMYKLNSCFgEBeBgg7rrg+aOt+4c3yeYkjTKVgo50UiUIw5OOX9fU5HANdzJsC8rby15kqxsJh6ue+6vULW9oWOQKM2VzUz/oyrZYM6MKQe08ByCIlYPmGJd8lnEgRdt96e5nZRtLdHojhymNvvh3r7V+0dRhAXHrcHRDwBsr3ytZ9AlGqzXNkvp0OL7kwqjcCZt/es0jso9cPp7NtxNUGctcH8lvuuxWhKvzLevwy+U/SFsuCsPPjMXN8s9+O99zPK+eBuIkCoamOgTp/5BHKZLRTZBmWbeRZ7VFN3QHZ5LgRZ+1JhNi0t8ccymCHWhbC7uuyMv/5D8cx93WPJKIiuK2ptOPrTHav3SWM0K6wiJThdM7S6hxt8UtS1GwJhs+zqX5ef7astZr9aY/cWDgcn45jmRlz9xRg8PY47EpwhvXWDx5oNxhJSZ7XTcf2NJu+WZqtY+TlNsovroUhay+IxP08ijVNh+fzSJwDBYx5vYDwlEYv7EPLEmzvC/XpdW791EGAnU+veqzLGqVulu6fJHk7a1Wdp0M9G5UkSYvipQ8t+2HaLO69SRjLeYn55evxvGwGUIjCI3DNpmLrvlkh5ceS9XBsh3VDGgkZDh6AKTnXMc+kdMfEYPSReXh5fX7b0jYSDsSDUJw/2iGk1L2KFOX3JV++zPNbJ/wbPBJd6vm05pcnjO6UM/rqrNGePkbSs4DwQ4FilfWDqVVxj4OSp1O8/PD8sTiweUDKHI/r+7f+NKfjDsl8PH18au3cQz1R4McDUm0tv39omgq+N7bRepp+/Jfllw0LyzwoQ/3/35knNam74hDb+/r69enLx0DdWXhgVN1/yra3bd4Ryx5b9PaHdenYEuaRuZf3dFkZoftgEfZp08srSw+6LB6dctuVm1L6PshmZKG0FWmNsPzwSDh2ZvZQQr4Dlnz6qT99mZaOk0dpz17svVqMFLp58npaPOlMdceBHyOZdlyMjIrxbRuV5dv78V9/6TmoiMepbnpdGyV7WLcsXXzO44E1VbIjHqlhkQTdVSnfLrOzsJbnkTko4sHqjIuxznVD6FbFsi/TXLoDDfxoAWuHgvNo2NZNkk3KYBpkEjxkJwVvTOGQ8A1K2v2Mw7ZlAH7M0E5FYU0NoxtUE2gPlTWFeNAmFc4s0xhV+Na4y3n4LXOUsMzDVkpHhLeJDd2YlMPqvYkcMo/dYpduraUZ64bIqbH5aA2OyO4d2bX7LbuQb0gdetIaRN3Zv7HCWI/9ls3tNNRtTAOPww2EM1Xrus88WtatKOP9xd8DSoY9XAk598dx2vJNkDXeR5kiurSLSIkffdyu4hZa6sN/nDQmpdjGbljnYx843wJJvK+vZ5ccwQM5NHXPT4fvpyJfHaYv+mdzV0v2YCrfBGomnGcfbeuyrssRYzQOik08nCvX/zo/P7GmuDKXPuanc4bQXYsnQzTfg+ju+l2WgjtXnRIRi6ox9z1yjiZovgMQa+7SVbVauiIIuylSqTv3XY2EsqlzzamJ3MqTHUb3LD4TO+FvymwpEgpGXhVuSD3JDvZixMQmZL7wgdRXeuHLCNYWZ3RdPDdiFCF2oYmYSBcbkCcHXxTqJn4hfiXD0cryMUvXlHkszC0Rd95EOtrn4pNQiYCMpwL1Nnh1sP766f2nqXFFlldX5tkG3bOQAejvwvj+w97XRWAgC8YxCpoJn0tIMmBZ30X57c9f2zDmaoXKNo7zYu69Agj6V0H50zc+dIYPD5IHidFYNb/8j/9zLVx/fFXixEmkSVEwuuobfzh3sK7GwUiY5r5Z945FgZBQaYGpWYeXnMM4CU7nEhUo2j/+oVbJ6R8Oy3uYYZExSMEoter+nzOIq5UVvc/HniHuvxYyJIktSMd970vhFIsgqyWQ2vuHH//i3NZSm386ISJsaXQIOs51rTeBr0ijp+ucw7sA5C6drHpeBl1KuKE6IGx++vP3zaGY0zsEUljZjBsqZIQgcbVG2xKHUNro/sFIIPmKtD+PwapkjrvI3YQQAarH0EdB20bjN2XAGL7TyRUbZTnmZjA7UQFpY0lSFDtCw0vDl4ZxQWBnbMWyxd8uwdWaGCNa80gs7n54+954c/0DSQhLRJDXEQUiWdwEhFwsI/8d/i1LkIufY5PNozIoCRDvy9dChrIkBLfYwWZaG5lCO8Dy2wwQ0x+J0gkQmC9+XWAsEEI3SBmx+fmwIIudGwFc/0AGOkwIybcKFRHyDXJEWuPQB4gHplQYML5fg4DCzRXWss7H1U6xg11d/0hUCCRv+4WhgES6OUDNpUxd2kMm+XObIP+voYMc4uYaW/mUbBHs4aTpjxQUCZG+I0UUCG5QifxozwsF8+DUsQYI+U4BROL2SkZuMadD7GQZ6w7JcqhTQ3htBCNYMli3JMW9lqkrczfd7bBSYOOLBKNAAMi3RMWaLz0Lu1mpO2URg9+7ICgNFjdUSiw+2NZuut9GqfydTAWQEvl2iFl1KCPIx0fYzvY7UQSk5Lam6mN7pRfr8ZHyFgjIyddA5OZKNcuBzODxKXrnAOBpXPiVRI3wLQk1q7FJ1gME+qoyucKzAb8noZCNboh63Hd5GlHGQ0TbqRwrwwsvzvkOJgUeRNyMCCvPVjJDPD4tjV5CqkgehScNQLST6lshKWee1TxGLZyMOkksCAEqT0R2bMJ4VKObgFD3SoL1CAFHOZ8OxyMmAALxCaAqGzNUCHwboLn8aaik9RihfKxP889FfALya8N2FTCWPjdZN+Ksx5w2wWNUIeLg+hlzCiDgF1Pr//9f/+IE/P/8f/O/fQ1bN0Dpa6IUD1JHqo7z8bvD05NBwuOPf5p3fhZ5+Xaenl9CXH2kNv1GwXqQCIrOw981XwDG/v0/Hf/44+8y0vTv5//6vzv++ESiK8OlbaMOl2zTiM/M49D4W8iuc/STIxGt/+x/RymIKzdl8toM2SdGrv7T3edUfoPL6afXH9TBIQGc+Ok4jauDEtv6BLhPoOj1u5/Pw+33WFB+/pP/lSM6Aqyy/dF1YKOFrKBqWxOyU8Tej0tT+Q6HTfn+x9PqpPKboi+v20dPB0sLrDKCzRrczyr5jUqf1sgyrN/6TadWdF3UbdTq4rhVNOSy4vdYkYtacwS/bQmXw7SdzZW3fpoxwWaVI/dWfqOTEqC/gFBOs8/JdTum5e0I1l4JlTd+fq618btA0ZO/LKPpyFlxXYLGUhT5YPnceU4r3+0oc9tOir9AmJe5f4irtiDDWyD2zFl8r0DRXvKPbrJ+Q87jtBYcviIUb1GPGUrtl0pQYgBBWOpP/4z/a32G36KPdjgHkq5IeDl7tiU2bN8JCvK1BK229UzVbzgoIwLMNVvONQOLh6tDHXMn8v3iPL/yXitGopMxCrouwXl1iEds6OKZynfJ0H0Y21wRSMspS1FKVwXOhcdsylR2yiBEQKDsOWJqIQPk9/N8aOKaLcHWIzB6uABypRYpvlfk9/UwIYSJ0t9oU7kqEwIFkg3TXF5+SKAPEZqfOxCRDNuox8i4IpAf/hQMO9Y+rloQcAFNSTapQX5dOOVX0nFN4eM4PiDumI5e0ZMEsbx8H5Rf9cd4akNcb6j7cTMDs19S9LEl3UAxs86fH3/Jd1jZOxO2tIqM3P2JRPasc5G8K/X+/OPBd0q447C45hzc2LhTvBRIWOdcgfgrWGuPSdZV3Y+xczzbC0DNUeyp8J2KbY2WXG/EW9w5TCvSTVKIZ4pfNSLWLWYyrsahhz+2Tdp1fi04BEHnlz4rEr+QgNqHQr4aDBWIe8Zg/8MCKPdUZgHy3YXBlft5gMMtg+wZgMQgJp2GfI+FxFbkaxrHHTB7BhNFAMFd7kL5XoHqWCVdE/HOtjWAY7d7zawqfqMVIzObXAtJ9s19BnwFdN+/JaCB02JRYVg43DWSkwAJCDq/wUGgAVjXIBHA7BpoYCwFHCYWxO8QVuvOQCw7uB0i+9aRUF4mIF+dvVTWDBoOqGybEAQe2gN22ZeaT6dqCSWUgNtGHeJZXfBc+iVtG1n4kK07YU8gKJ16K5Gz8RunZOdaDm/GzoH0LUHX1XUGx9aBYQOfwGFJvujlxwWtYyXbB3lTkq/v+Dn8zsXeTUHeKpC+oJ1P/I0OGBsnx3g3HAN9L6HBSC1SDjauLEA+KTx8/RQckEVl61pNvG18qxMa69bIxtmZ1rfqV33PCq4hg9uIiZtG4oML8I0P2++gmWVVHUjYtc3O7PKmXIx8h4a5CFCOsW1oanpDiuHriQiyrJWRuGuAZbAnGBw2fA/QkGWDOsy+8XwCvhAUO8XfM+yrSUWHo9KUtLdiN4zRi3ctC2P9dbIpiKs1BKhhU74q7Uw6zVsCY/G3SqDELnIpoZ3RPBPIc/Aq2ADAf/QtEGL8TZhIIVwpNDchAaNcK02cektAiZF/m+QwV12Dhpr4BPJSJBdI/vbcHGDeQTCxjL8NKRO7juVnQ55O0CdAr9C/PXBPrdgrUFXvxr8lQEBJJ4rrGCLpiSUY0otmip8IvhPP+mVR0W8NgS2X5965XhlWEuwJpO0Yf6c75/My5LWIV72vT/xaGeoFBef456woqwQrsmv1uMMX41h1/tYK4JL1SKSy+/CPw2JRA9YYPYmulrj+lRh18QU5Srycv+dTYWJtB6gjx5bxDa4mgpCedNiBy/eA4cPT1ErIG0HmqZQzkzpmVSGWn6HSD7Pj+kb6INgEtBDfEYPydKD36NSx5qAGdcagVcJI6ucksR+Ai+B6g3glbWzjG33qYyx0T9NYNBXy5VgFZtnU+PHTT+ODnrryrvFQ0gObw35H37aeSCEVZ8UJwRVr8uOnn26fQhoCWL6AeoD2AM+vPU1fAY+UJA+1wEgkV/9anTbaJ1/2qokRrVRbfwdSIDWRH1BHipHZo9FAfKKVStWpB38PkbtA/JAv1aS1S5ob69gs5L/t543khWKzT0005FGwDxIisxLmHvqFUjYcbggQEfCiTB/Q2CnupCe3w9Yj1ZOzPKl9gJS7oQyPefLGTo201RB0pHvw6z43VgfpCJgIaQgoOvheZLQBmdURE+lqVj0kuhMirZKpSEf66sgiMLoP4MwpMmU2CnjoEda9sFeOscrsVOWQLWzuokCr52OuivtEwtEMCd2FX3ee2tIV9mkKF5u5n7IdxU73iYLdG/cknbXUbtwnw7GYFXQ3iKyWcfYJ4blt5+J7gsg2Lx8Ds0nknObzR+G+po/T+eND3CRITiOjuyGLbPPH6YNNKgMmkbibVpHxlOPTtCKapiCKPIZH6G4AkvvH0yvYis6KHOc+Pc3B/bSceR5fX4temqB5KpUeODTW96U+vzwJ6U5gv53iD18/TC96K61vb55+/KHZugvOXsv5fKZWsBkmPmXaYG0fb/yhNDkI3z4H2+n8+g/xvduijdHwdBDANkBu2dePn891Dm6fwEuet60EGfoqObVS+Pu3JSJ7SrcOlIvaujpEJ018Jj3J6Icj556hId22iPNpXqKypdSJL0aC7bCyzClCtYd8ywR6O/9w6NSw6evpHDvx6zGKYm6jKuN2WWVbo/2heWCxY4MX/XSlUxQtwTdLsHy0f3aiDrFPo4kXQUw3YLisvASBdatgKme3xMFujeAwcrYfLvnzejjXOcWtlrIydQ20V8ypucn39/UwJbe6wjuvw5XHrs7/GGXtwrpFWet6fiWJPePwZGJTTNnepq0fSHGDO1fUOrqU2h0Rc4Uh0ttM9/q0bbdpgGkagXj4jrOmTG5zsakmsnaHIT6TStBhsCeRmkmDdYNgk0DsZ2mqFEWpgbjBSSTIu8chDkTSEYfVxpYU35yQjagGa/cAKYZGeiq1GHaCbowEowBmF5FiIF0N6pogcWuNZq0IvIuugy0xoZJDvj1JpXYsdrOB0NNEkYG4yZIhtYtMBCQ9ESreuMlriCS8i66DdDXkoZvEsLOj9FXBwLpBI/demfQGwy1WMI3qrSkS3aCgiJvoc5no1jSYsI9TROLWypARN1EQEDfabCKFIOsWGbaxSeGwfsO/5b8Hhn3clT0EAjD6rc/+isEVnGNwp7J/IimCYECAEhAICtEUgHMJfBx1Hwz3D0FSjIVRygJSnq6ISUGhsuJxy4/IHu66gxAWZkBWq4qVJgWOfO1MDVjcIfvHcDizC7AzsttqvYTq2+BYASmBEJxFMGUR9w9qzVUxir6cllZqpbpkm0uq+q3fkAxCJEzUzUHYwu2k6HR65FjbU0hVm1zJpG1WQeoA5OwcgJ/WHkr1XNPG0rrw/LVZaw4Ehr0m13U9++ifBUXDzHVw30Ie89irYiZW18OSo5pRUgU9zL4eQ3pQt5umCM4hHOhbFyUfPhxrz0wVnO8/Pn/ZyQ4F4jBMO/R5cR49kwIk/yog1SiZMo9dx3k/59JgfXu/5JqNidIwjCr7ueWaKET512kzyjHe1R49CKuvacnOcV7j6iZmXEUEEId51tESqgL4Pgbqke9j1mPH3W83BxNt5pAdSDMgqJR3Yq5ldbFMLKaUPKzvpT52HNYPdXEm3LZJT7ElVTB2djIAoePlKiDtEHwflkYrG8iPG2D9+ZEnayrDDxNnJF2pgmENVGmAndZASHACQaM966MjHrbuzrfjzU2s7MEJYGLREQKTixOm3Htcm4yD8V0gRn1afy6BHzaQt749Kq12TaEJbCHox4qwI4g42cpVwV0ypTWtIEf4YcPRz71K+6ZqKEorGQIs4hizIp9rIIphTgHJS/sYkegxU9z1re+pqeWlCfm0+CIuHg3JiDCbRdXEk+8CuU9fTz+XinjMTtU1zVi40zoIRlEStkCSVHEEtlVWInP2w7SMVvMxIznW/XSJiSkRMAxtBYXaABkiFQqGvrujkyi3rfzg76XaDxjYu5pQeGNPgeAkbSmJYINm4FgEuHMu6hg6gQifnr+s74WU9otd970Wk3Lf/T6pALgRUBhj3AHDoBIz0+LNAnwbyONQ3UZX8X6JZ927yj1rXwsTKaLhE4TDgmYTJGBhzD7xZmQKbcvhS/+QHi+SgZF2rJGKiRUkBgTyDqARSJlAhjd0DKYUji/+v7Y/gPxgac1zVhGWLG6MmWAZtSQBEYGdmyh5wggPsC4Apb6s346lh9FDxYGkMtJ1+0MGDTWIkbsNqiAFOq3KTBsCi8uU+yF+Ysb4YeJ6uFmVbIvZKSOM1BgEAijgjhC4xBiM/2TUQFymNKYvp9PsDOlxMuDevapqpsQUUcrEideTggRKI4DCYBqRvgys4vM0Tq0NP0yQKkIvnamCiuSwaw75cC4GTJoyGBNyRMPKocsA+1A/6nReioQfIeK1Vk3GXn3FEHDKAQJEIIRJmsZNSUWiMFobBl2EoGZMp36IzSMeIdCh6mSmNJTBRMKbInfNAME40JhCKsdzbJa4TJMqa3wt7+dQsR8eYp6PaDCbCgWGchfkTSGCyRlWRgCHMTdvycUKjfqj/7S0LJWQ9dAQMhlKJKOAgAAK3boJIAIySchL1ZqbLwdEIZ7q+899PpaBUn+FkJ0g1sg//xQdq4xJii4lyiER5FGoGSAGlG5yKCX5chCjfeXnUVIZIQUQTyAbUWpGN4hFuo0kRsMJYggFEQMkpZhjmwKELGF0ORAMTUe//xKHErKhAExwGwjrzqmRcVrpQszwYeWQoCRJMmGQyShxFxCWzWUndaprxrG/99FkeQIC2QOzJLNXo0BXaUFADYVmNgZBkkAFWzy8r6CQl6YgU8/P68eiSRIcEgHZgMJOKbQch8JCR42EARFGVgiFUpQFOFO+kiTSXHyGq8fSng7ltH7eR5Vc++1THsXSOtMBUJFEbYIEMZgAh00pHWAITJASypQuTsg9y2GKpcfPt9tnwDju93u+d3J3NVMlpioEkVjRUhAkFeTuVAIzRioJpqmOVYqL+1wpzmNVtQmErE3bFlHxp0sIBYIJOwTpSI1K0nQAAa5huAmYlitDKId4NExobZwQugIh6PvbMTZFKbWMOsapT018tgUlQGFPwcTPTTcpyUOhoFiYTSsC0ggRM0gPYF7W0ljNtUoM6UNqEdScdTrXo/XJUgNIAiEMiqDdXCyOiyAohgHTTCChEKLAehNX3C2io7yWz0EwI51BbdqU5nMtmwgwg1FGkaoqZrABZ4I6w5poxIAShjBMcALk0YXdMInimgTkHCNNUTzX08mBP1N3wYEUl1hAQw0EwREHDHQZS6FpEJiV+4HsSRo3GD0C65q+tJAjGXWe3rYN8YkWBHmZR0r8dE+SVSOMgQphOQKCAehcMMZY8izB5Yd7FzdQgMDqT9O3tUd+rgTpSXNAcZoESYkjIU4AQwIiREpOXuMo8exKZ9CucQv+sqOY8RF8rkAQBIKNUISuMlTty1HFDFAUnADL3EmhgfRJovxlvYV0O8RoIj+GPlNICAQwgtMgg1RXDcvM4mQjwASCBCJOrMhIPIntzs4M5pbKpR8mxvcM/FkygJibKqBImLEWoZZhAjVhYTBAA3FB1+OS3AXElU9X3FbJfDGrbH2WAJFFHh1XiLJRCfk1TcoiOWIosIYCCVNneHmLy4+PafFtQeiQzYNPs2TyrCFIqCiDMKk5E1NjGac4SdJAMDEp+EIQOtiCuLl53A6HbUifJpSXywxyQg3tZgjEX66zngCmFMFCRgFXGelJoIGPj+nauLECZf2H+W0If4oE5R4gxogkpVMko3QQlXuKLKAgVggioYHQ+HHOx1zWjwMmn56fTu98kg2QkEhDBNMYbGZSdbChDowkMQQKkiTMXCPLhAjKB2eVH1hyPUxabH2KQEAAQYFd2ikCBkOf7IiRAWKuJmMBwgFYFIaAOdNc1M80nNPWo+RnSEOhG8o1LjtlUoaJZboIRTHRQROiUkimIVAQUICRqjUtbnfyNH8oIj89wAEWwDYI+4ChKkk5UQqTqAgMiiRCAxCAGlAI7SFUgm50o5xapi/5i2ry2RUIICSswI/p5nAHVufOwimHaBQqBoPGEOEgQYiaoeQoigJKbrejnEab+BwLEJJygitWeQ9tnTWRVOxscKuAKotqzELQgIRYYzlKmOSGi8baii35U2O3EBHAYbi4PJxtl5MiGgpJygQlIsNdvBgMQhCMPShyWLphxtCet+8R5pMrjyI1cj/hSGsV9y1GQ4qxpIMMEWjjHpAvBVI1Dk9tE+amh8fztCwt+BzrovEo4xW6rB0tQqWdTTWYRMlQGHboQAEGkFDLKSe3f5SyUhZ/ZuwWA9BNVoCRjSvz6D46o1RmquIUBiPSkHQmkV+V0kPLRLeP9PFlOZWan5dHLdCSGO55dDNHzd0cGSt3hQZWUmANZJwa5XtlfKNMI82tF8r+NL19NBP+rCQCxKMWEpBU70HdC+15Qtem0qNjBkQIc1ISEKAoEgNzB+WMiDaGQJ8UhVAyaEeeRTGz7xxvB+5i5Q4QBYqZScDtHCBQMDKc7ivzXrBtxy/LuYT5lAoZ7yZflMfU2+FM3SYi6cRU3XAmQpfBEIQYy+Xzku8DaPAlvnPA+pQgLxOQlHqnwKPqznhfN2/LgipghDU+THfIEARS57GvVJj7KHlUovah8EsCIoEh4OVQvghlVzJT2+d0G8sCIZbWiGcJFGIKVt0fMXQnMHzox8PHqP6MSChQmnhROLyWlAghVM3sslPQ+YwTIowk6FRYRPaCuwF0jtoyXcjLAYohrEFmia9AFMLeU5KjVkCZAF1j1xyJe1LGWe/zy91i7qagWof20YNPpwAl5EQIHPAckOR/Yaqsw520MygTOh6IiRHOEkE+zZ17q22rX3IBxydj9qaA3I3K14XmipTZ+9mrOzegFclZkqikJPp8GCWGfWfQElOddU75MyErgWQjixSC4yvPLsLOkyxn0o7ae84VJUkqgYBpshF3Vrifjz9s3wfyJ+JxJBjuyrWvATNNk8d19dsxk6rYFiMp5y4qg5b9ZUn73kAZp/ak9ucTxZ8HCwERTMFcvDFNF3nu7kWS1Qw9RJMhikBHvZPmDmGW8/MP5z+j/CyYq2BoMhhU3iSIvi2uqUWvWIE4eOMKu6bKtoK4x9rWl/nr+vNW5c8BrgIJyH2YMtqSicveWUuGMDNZJXGYTksdNvdYssb4tz98/ybzOTTumUMCIjFvEwhYF2dG3jrsmZ3q0qpzPY1m7nd5nvnI2kPef7I8igU3QCXv+lKK2+XOYc9smAsZS1mrJd8ryYfD8p6KOqydJykQgdCLEJk0KU0KatiGSdolZ62Bxf12IUWvuOJ999J4VgIC1UmwGJwxPZczTe2OXkZy34NeY+2TcUp7TghJEBYEAhAzDUEg25rLaypej+O8JNZdI1Wch+yBwt5v8ihxlwoQIDIPQmUmvZ+FODzia94/aeRUVsqQM/YbgwE3AYR4LXPr3lfab9Z8HEffbMzdL62THtELQ/tMXgoQhAjQzclSYT/nz+wx9/HTZmyse6eh0qNlMhRuGT71AEgQgkiYW6y5zh93z8f9pmMEyNw9y3/451qJErnH5KWCQAAl92TFMWpT1qb37diELPZgzi/nmLOPLOTuAjSAkMdhMW+/7ZgGh/g4q9YqiR0oxzBzbDNY2lmCbAIOCAHrhAuJSziyhHWKuSoc7EOl6ljqq06ra3pHGaDyviBhArLwttZpQojf1N1DuNcpeyl/cmhPEYZC5i3evP3W6zKmr3XGv7UPo5zf25f63/7f1OGdZAhIJCDBEAhx9/dxmOWk59cpcAG0DxhJ8Tj+j/93jwDvICESBIFZdVqFwBstA0H18lFeZ8nsyMK6+b86/M//Z2cP2xsoEELtgIE9/M5uZT7/yX5thR0pj6iH2pfT+TipJNo5LCZgKbomMAAC/m5IsSzxvraaxG6AglVf2//782EuYe0ZJUoSOsRdbAJTYed3w9jnj96c4R2BHa2M0tbvazuUlLVLwoAYLBSfEARJ7v52SCzU3msZjv1A4K39ePjpJ3QsSOxSH6LEkByIIUkEk5/RpR/6KY+Mwp40UYbjoPePeCpKNaRzZj9DNpXGBQ1A5PGWv53DtNPH02EdsSsQHrxM23nI4bJDDtc20DhtDCD35pUQMPyArjgOrHhfgBRs7TC//TKmVtIMh3N9/jNnSOSe3BsEjQREfkKhaJxV07EnLDQc85TLQqrFtGJwjn3KLOOmAgSS8ngj8wcAYurLPK/sSqUcjs3TP8Sf/zFLpJkXvtMX4bOSmQMgpPyo6V7ijT/EkqG9YMKRcqzrEk9f576sYitm7nWwRiCxsLM1vCkCqbI/AIRY6yE6O1JJemSvZanx/GX+eK/Ri+xF1/CFFF8qCbIqmNK02A9AjCjF3gkZAveTx/BxPhyDXvvo2AvWOBUsQGoCg2BDqSFoGMSQ5ZAEAscOiByDRSMapdYm205belk0jJIgYuLoEnd5lAkIDK+ErEIEKUvcf2vtvXuepueJ956I3aoG0CDAHNdShEVokiIEg1dkjVSRMbsw3895eKpllsdAmZZl1BFAwRGEaTQCLRswKOXxYGACsqZQpLUDHHn+NuKffZlyyYFtAbJwU0ARGdQaWcZITReM+xQDGCbgGo6prFvNonsH3s5P/+qwfZw7kQhZ7F5xpJwWSRCR0oVSogaYIiwq8zQt7w1z950ZL4eeYfcUCoKdbKFE8hgMwGJhQyNB13ACP7UTEdx5K8Yoap1MBRDs5RQMOSARDIS4FAJkiJqwaFRq1TlD9+7XeZxg2HIo2M8CzIG9BEkkRzYIGEIFw6Jupvl8ysLdlx1lrsuSIUDs68FxCXd4NIWYiCkGRNYdx+e3n+eIu/fr9vS8/uwWKfb2+T92r5A0JoFyAikQjMvoVrZeJrwDpONXvW/KkHUthriCQNbwi/o1fEaKIIcMQiMtIMs6lDxSEWgHYL++8namwLUEhVzECcyDMYBa4nPWudXlhyF+yKwTwSQxhJhVIJ0johDsQNkMPcXZ6sF1qmBjiCD/CqMBnKIgM6/ESWWHL60kFUzWEhhSwLgK4dwUBe0AYKztKUSnjquI0rQshEQh/kr8yu8gBaTbYWI5jyvBnGx65R5SZoKHz3AAFrmWVV3aWEoR+1BsGccnVtlxBSLmAoxBkiFFBOTXA58iJlUxrqr0et4+hq4iWfaem1I+K1NDBAj0IJIVhGlpVOS9oL7MX4KUSPnSyKLpZdrOmUkcSaX4MiQPLMSzVSdXjva5Luf3lOWLE/c+2its2ipmUmUVg8SjhCjLRiZY2geg7I6neYQI0KV5bDo0p+thVYFDAgZIqxGPAwWkdJO5q588zxPXGHpYVVVNZaaFBFyVFRBClWVNsQRmN5jz+fnLcJVTvjCrn7bt6fmQce61VsjUVEyIEGzQM5XpjXOnuB+/pHZeiZK6MFP77t47dVQVkyCJ6bgw8TJKJboGtCkHYk/2HO6hQXD5mds4/FBPyz1NSFVroRwiUQY+r2DM7E3VXX/4HxzXdbiaizake6y1g8y2gx41k3bkXUFSxbJT0Yp3hFC+edJSSl4B4ZEzsX4ce6IeKdESJwFk2U8kugfo7Z/+/zeqPKzLAvtWdlO1zexeTEpiZEAvCgRc5gkaO9OM7Bmrmn1xsj9Oz1/15DFkok2XhYoQW6vBhD7WYvGH9VfuCmQuWcJUdlpJTVWNknubWZbQ8Bxry8ixMyQPF6+enNW6MBPL2/SlbnZmD6kUFouIRoG2alX1Yv7s/v8/FafFRQchmOi2k2q3lfEO5qOQL0rWED3msp3D4T0BAWGXbZnrwPIlIY3Rx/N7wlAxJBAIBNODVtWqkNv14bGj4NIl0WCGvbtCw0RNrO2w4DuGRUWkX6YRsmJfAKbE0qZtKLAuiYzyvj6fV/YwSSSSLRlAkrFUtPJ8P3++e5B1WSEyXdsimRRTMRjYVQZT/IQyyta+hTB7U6CMumxNw+KyZUNV7qkUYBlB3W4216SSYs+ZuzeSMpet8XC3KSAbE0kqU6FcQ36ImCPDIPZHEpTsLVYVW1NB8H3OTkMnAlVy7JNEx8hI6DnO/azQyYW7I5x7OzJUcO/qDBU7U2T8hLLFVJePyj4NB7KHSlpkKkf26hx9lVQUnLEFEtSLr0dG2ejivOdIOTgQEp2AY6vhx1SUWtO9BWiP2Lj0ERrRMGYiZOXqI/RdFbCJJQYJmIJUMs/HAU247Lotp3lQ6U4SMmWxkzHKv5dyZ36O9+81FOxTCbvq3kcuBLogOvMoqu97JUWxIVAAMtBIxFgwaCDmHteew31MCtWQEoYFAdJtIKayqpaOaWuUrt3Z67DBFwRDz9Qlu8WJODpSEDUM1qJJWSK5bL2sezdVA4mSsvF/15yT8lOKjOOB8xbeM5gQa6/+GBLogqIytj2pJAjIDFhlVHKexvNBxT10WcnqYe29p0EQHfs85gr9HBqeS205LDobi7Xb5z1HJhctdznthihFYABGykRObeOH7FExF13OdTJHm2uS6qRkOp87KMhPqYzIrFkre9cBfXB4pYYvibhujsgzhQYgREaRzLNfj1uoc+Ez1VcEdhUCbQb72M+OE/hjmMbp2DvaO2C4/VZLKWNw2WZqsxLFgCQCJjXT0/rShpsvbc30um5Ts20RdPYsXtevRePHIFs5rYHZv4kwVztuXbosptwtNYQNDODnGZq1vkZqWBdlQs9VbEJnIhhopp25OMXPaITZYmIh2cNlsnveeomBdUm46WevNROQICLq3lGmsqXEZaeMUoijGSrKMNlL5hp+SEeIqa1Wxj767E99O5aRBeUlQe2cTLy1hogJuPqjAjK+KJ1ZmRkkSizM2KHuPE78jAaJcfZzO6cpO8lM96BHG8OKiyI9se8+3BOjRjJve20yoEtKXImmpFIoEA2dJAX7EYJhqOK5bcLsZkOstWUvgnFRMPL0fU+AFDB1zGU3sswFK9t3LgwppjEDs8gziJbp7ydR7EypkSrsKePSPWlJVHxJwlxv2VWQCmnuqmuKuWwzOXy6ErqMFSKbVOUeylUgfv/UDPVNa2jIya6W6GPSFpNJ64IgqXqWoZqZYbGdxMVVzd1Jbyspk4gEs/YdGZD4/SVWNRRSFjtbaTXW9uzT6uKLQj+6Zi+HGafXM0YlL8lM6v3ee3fdZlBRuzz2PUxri/yI3n1+8+NtVLB2FoTyXJ68gkjNEzA572pvMnMSNjCkS4Jy08k1zUASK1rJ4k/pC5Dw95NZGaruNXCwv22rrks5hBWFZBI0U8nKVM3cx3ndBWVzuSb1w7k+dp3PnY4gIKGfuzflCBD/Xp/JlV9AcrD/9PHDHNg7DGRqVbW9rx7ShTyGIbOzMPUghmVeOyRf0//6jzQhAeg85pfrgAryjzFrGxqZpacO2l589NvKvYsSX0pTjtxKKflLujKimHkViax//nsiGgkfcI8fH4KEySMCfhW/EBmEcjgLY9B2s1378q1zQ+gymhIyVfLnNbIUd2keJzVqH79KNYQUCD37eEoPgFMJUMzOJx2w7Gjz1PtIDRdab+0H50En0r4MSNfQOJ+fmzMqZloFGYWx8AtXCyFApXIWESA4E2KdR829rdoSoxdifm5jsaIkzc/Yz12tbL0Evoy7hLZ4/hrC5nI1qNFzFP5BXWXlpaUc8jnM//53f7mYJ5ZUQW1xYH1zSRntPcrcU7OyxWpdSgLo+HW2QBeEHBUPpikohR5SdI29UCBmJiN1/ngc72KKllKnwvrtWy9IZv9Pqne6ac1Z5GXcDVFlMJcq0q/qo/uAR5EAuaumKl3BKnKeRQj1+P1zvf3wZ8yE6bJGvo88NtJ8Cst9S01TW8/ExRigAOJiTWtPddhERQQh3rRByqoJEKZB48rvfhfqSLJDcG7nUkpE4dNoMnM+rt/LVEh0EYCRuNwQnSdvvZQYgNzl/VWZ0BjQUbOYmuvojz89rseFU8xMugIGfSIGaOdxPLiWuCBxwZmapq2LKkIQ36gWI6NwyMxzzvTaM/uWNJnYFOHgM6nwW395ybUeGokuwgJdigZDLZZzjQLi7yztDDtZZdU0kljX1SqE3gIoBfKnAsNWc6Xn1mpFvoSLnmF+6qctguR37NX3bGKh6CRGZp372YVUglMGhPl0itA5j9u3U201ua2xmqVEj4jg724q641nCkoG00pKu6dE+Wx4Wc1QdabPJz817NuhN8e0vvkYWH8/CHxSoyZmDhxroFBeYYWXw5H3Dx+UgW9FspoR2wCJ33XWeV4TsCgI5H0SU0d+uYm8xrYCN7ZvcSJs3wJx56zr7CbL/J5y19vRzyfMrNtBIm8Pplu5G3mZNaiHur53f2wKXZ/S2RqjMxJ5u9T57X5gDEGD/1Lg5q2miuaFVlCi1VNuIYZ1ZY6Qs015spIJMj8c85AwScMs8i+lmdOfdyUvlU2dY5u+aP2g4auSO+2Qp8VzCTIDFd94VoUi0cF/GUPm6NuS11qyx+try07NNa7JisC19I8aUcwo4f72ra4JhSRT5l9EQs10Ib5WgMt06u21fpyYLF+LnNS5f6y1BmZS5+5jdS4XNYP8S1foPDmivNpSjDPtYFo7d9B12FVVqV6xCpPKZPP+npsJQgL+C0hknc/q5iV3uJ+mPzyf3kNBXoFEujZOp1bE4GILkj5Or2sBZJD4zyNAcR/nxaseGs5aBsc4jwxdnqk1ek9qmuByQ2fvevu2zE3xLy29Nr3xRcMSMLVj7ygGvqwQQ1HHB6VK5rKnCKvYXSGfBPIdhuRYcx9JvWjISTm0ZfrKslJ0ScpBO7AtnpQZXP5UZarn8YyF+fTPq7OPt7kK86pBCFvPbZjIfkGmIloZp1QUc+ki8tzr7d5VkwiC9A3R9JkqeeVN1qmPdtS2qiF8CYKudhhvC5Od4ioTiqkf3x73rE8R+arRkfHJq6+g9xGTonoZGF2AaSV7ahuWwlxjSLnv6+3AIwUV5cshzFr3s6BeOzBlW/v82j4WFLJ/L+GR8xSnc20Yc60OQ29/fL+efZYE7EniUcd3r87w6ktsLhXXo9Ytid/LtFljdKaBxNUKDDvVNBZoJY+hhGTeDidl5eXDVs335fDDvJ6GisnfQdCb2mF9X2oDc8UBJM9nfsz1YHUDQUChYY3nfFCUrx9UxvWm5SxQlADr7yKPLMejTieeIl24fmeaOgZRtp5UoYJEmSTz6emMeBCmYMc897c15orR38WK0IgayzdFxOAWKtxP5VjL9zVb0QGICHSaUaMj9BiAhDJNZ7Ou1BZYf5s8sh7m/tMyTTZFt8CQ9qTc8ljbXM8ZR8GxuqrQe2aIh2GhpDz57b22EGH9bVHDo2uZHKE0t1JiyZiObbvHNU1paFlrxmFYyUPRlBo5q5/OcSxg9FdIDKajTr+sU3WKG2ojidHHcb6vEk1r1/3t7VzDPBglMvVczx+mgOKvssuhOGObbDVuq5CdAx19bKjG0HsevYaJRwMgSS4HTh9Z5xAWOBAwfan97b3V0Mgb85sqZu4n6RMI19xzqKH0I8L0ciyjn2vJ3hQIEphfjiz9UEeqiBsssCeD1BWIU8sjFDwkBZmlTrm+eZrBSACHtr230oLkZusz932PE6q6gHlQKkfUSfZQImUojs+H5ZfvzDEc3HRhBIJg8chUiIxWan/3PLnEGFZ8OImW3HhREAF5cBoXsnmapjJFPf35//n/eG14iH9SDHK0NmlRdenbeMJEmH9iNKHRt8XOXr9OJXDyT44COwd9ZOZAUfinSREwElecyT9VChGg5J+aAgz+7/8tDVZQOCD6YAAAEF0BnQEqpAH8AT49HItEIiGhEvpttCADxLK3fiecUeY3NXrILX+PRmbleY/2H+O/df2uLg/k/x97VO9DsvzIegf0b/lv3D+YP/C/Zf3e/qb/3+4d+p//Q/wf+S7OXms/dL9yveD9SP9z9Sv+39VJ6QHm6//L2hP3R9H7//6vd6W/0Hph8cP0v+F/IX1H/Ivq381/ev3B/wXuzZb+2zU1+S/hz9n/fv3V+J/9/+zvjD8uP+D1CPyD+ef5n+7fub/lv3g+vz8TtPt18wj3g+4f7z7kfjy+7/7XpJ/If67/lfcZ9gP69/8D7jvbJ/7HjQflv+P+2nwC/0b+5/73/E/mF9N395/7/9D/vP3Q9yv6N/n//b/ovgL/nP9w/6H+A9tD//+7b9sP/57qH7V//0ym4BZu1P1JDUE0H082nbQQ2IO2tqfqSHnx0rlCroyzeWLZOcGqNx3xHRLLpYs9iTa4A8S0v7Y5dxMuCjExjmEoC2Z5evcfjxk56Pvy1sc6kfUvs2pagb0aZZizQm4BZeQijHU08Vi6qdSUqzLdMdFypE2br019dNivx36mwJM5TwjlQ5a+MsxZoTdgXmn/2dRo/yRVd7s4DB0KfqIxmYN8gz7jhqp7ov92QwMhQHXdaG4SeFBa+e/jiRUmde6hUZZizQm4BZKpqlpaINvbpeNFlWCCtMDC8PIgU65qnajCUf65lvlIo57veQRel4q0FnQ9cbMzUPRNd6D9SQ8+OiBlfymmBWqa2CtWbrekJTycyf60G7S3YyecyYMxJRUOdblUQ/JZ3R/mFoFhAV7LynNm7U+zxd+NAxp/9w/8cw4qDxl+5IMfqo93W5EVBtuA87wnePYKqwZIUEcpCuNEp+Zqgd6Soe5KePfuZ9rmKMxR4PSNqomU0H5FaJZaeXlIEfIrhfbPzpsaZKZgXiZjlHXXFYdQmkqIWsxQT2aPaGbpnAvKkdNMKk44mhQgeONd9jHgi7KGOw4aa0Df9/IxWxR46lZr92SaQXslJfMqA1Vvx4vqBLIshiq3XV5OHa7x/JY2jO2xjWmqYpNqJ0oq28jKRl1p2OUTtP0+30Hn15G1xwQcG6bNa+xwY+Xg0h+srnMc/kCWKXPlhgNbU9E+OKjGINXj1g8PgUo9smuW7tQZO/xB9mG2MSUop1WRZymuXtd7ObpMFx5E2bqdAHAQz09timfgK/H7WHIc/fNa6bBYu5uQuKTDgE4np6WbtFAZ8T34aFZZwxa7sRNRvt94CiVNH3Nmn2yYVpniXkIWuIPXxxIcl6OqeOlC/bfTB0tCkyhBvC/CHbtxFtqVyQUZvOnIG1yLOxtOWbnNLFBwv7m/dNC5deUH+iKRt/RNZ4en3I9iBXkxvtmabyTjQKlI1705N3YS7wYhlaZ6Qe65filpEdzrp5Adr5SOUkC35P6eR28FFpKGqS7JYf+Yt/MODAeyKPErzp+UoGOa2/Zkodx4aLShDuT1cuYapXJOz/W3hjfreB/FXrt1KU3T24re+DjQq2N/snlNKID0R8PI8ClMeyJDUovk0tWYYHhn2garV/W7cp+oJJJEbnHgMTtwqO04cjEz3bWnPMEYTNoeRiQVw07Y0MOKQmRP+jJKTIv3F8PekA/JbwbsrurCe6b/ZXsw3cJ9DcajcC6vtgfE3XQZ1JicWVSHz1vZLcx20lDypZrED96Cr7Yq411ZONi/zIuzeDGV3B1KV0gPhO9auY/K8xvVkoPMS++W2oICRUqejSR9bl8X/9rQr+zES9J7w6yHEEl3Y/9DVaeDvIOGxQYth6jGvx6Us+W0BpZR5Hv/ynd/MOX2EYQcEridL2AY5ofgNyAZV1om4/3g+otVL9quk+VmbHcafP5fFNioo/XKu+7iFRufJtRV8IBOlrkM4GO/DDgzd2NB4K5e85e1EQOJ9oNXPhP++/1cWAWa1Vojn4kJ8CLGvVZWNJAKQzxSurH6ByyWuif9cWw58B4oSYYQOowlcWxcJhhgTXj0ZTS3ned+vK96mSObEdzZxjHx5m257XcXAa4VXrQy+5Kxr8fnKTeChSaL4yyl/YUEEcX6UqlCKudXq2Wo8UhTTNxVDketBSrnUWyLkCqi/i5aTk9cGNeosIkTKtIMCMRGK/WtQb6yTJJssCphlnLsf5e+o2+2h+DwtnQ8zTv79/AiUGi4QJiha9bgASGTlBNVk5gf7SziC6Gpd2Rk1RTzLLDXW2rJ6OdFrroy2N7gdDZtOf/VrIymrLTpFiMw6VNrobZRRQns9A+k0jTrj7ZQl5Pdz8f009TZf8nDffHDtw0w/pr/kn7L3jiTc0rDuT7BHrSjbOfvvAiHTEiQ6+Sxhl3/8hivzMgsiK4wZfI0IW9HSPhgUGCYpFRxqT15B3jGXw+IQ2QN2SAorwWcJ2KxwNFc243GX+N9KsIM85nrNGa/RnR6obcHLctZJhTez7QBpeKZTKokI0TDmmgFOqXGY/+TjtyJrpVZ21xGYR6/UhxqohVpz/xMqA6ygP3S2ajPwG6qqI3mMGb2l1Y76vdKdnTFahyKk0d45npjDcXRHtTn+h+WSdQdMDSnP6cLW3RorME4tuiPNw/JBvWtErdgQUo0J28haBUL3RidiOquUh9cuxJUgbkxSL8sD3ESnL43JOz2wwHogPviKl4563ifq0MVoAOyiY3opS5vmeJf7WQd23hFt3GRoqVv7sbX8ZsLJX0xiZFt25VXkUJEzr7dPi+IkxsZFC2VX9suO5+bCkIUFTzPQIj1hMmFdaRPznlXLu0oYQBiGKikytfj/ltFUi6Po3b28Ivja9Y92zaHKdazhSoSRVjM5lggcs+U7+ddQy8zqSA0i0W1P9scag9ybWc/dbzoOIo8T51Ox4ai3AY6QlngJnEF0aXJ8vJodJ5N+3j2PDVAALtpMdBERBH6BIecFdaINEvgsckqc9HPxtCzZtwoIno305SBmnzSx6HN0xSNUrHY9V7he9/pV3d2tCbf9z0z/4PXvUjqsqcaE6154E7HMUJ7kPIBDeec6qoH9w/6D3mebt2WW5j0Xkd8lUsJqQGTV6oBffX0h4ljaNOlowiisW554o0M1BF9VSRQiHbypDl1SuZTQm3BZnF/8FT//VFr5db0GsBPzQSkbz368wkcUDgL8Hn3RPkTsZ8der5+ov+s5PN7If/2cDNsMVQ5ojkSRWK6izUnLvvvvYmia5/J2RsmHiDwxrUtW0iJWy5Yik1qfU1gztchLIgZV9p8ZZihc3aok9+WBLCIZ8w8FJdIrXduDM1ifObixyWhJezNXaFjuTTPJCN1PrXUfCIIPip18Utt/7Xl694j2ptSrMOeN/dUGbAE9yRH4uWof/mRP9uu97aGB5YDQTSRgQpZzDN2zdqfqOosokq9hqJ/cYtf/snh1gzVsJmQazKwwYXy8A/J79rUmld0PXKqDynXrQISjWwGQ7p1k+UTogxn4svPZJa2okK4ydR/eUvtKpmfSt41izFmhNuyN769hik5NK8nGNndpS4DK8ehYs7rhK4oK5SD78IL3Q1+oOGtn8vbxT6aoLNs5jBx1AhNzRa6VwlOA2zEk7rx+BieXCPWYs0JuAWYSg4/3R+JGIvDmMZzn2h5ieduGIAVl/8B/F8/+AoOWk4kPZWuN8V7tFyHAQ7qhN0MKy9+dimhNwCzdqfvRFXK7Tuee4IXjvJvlYhz9V0SWsmsj/BM4w9pwRAm1wBOTcAs3an6kh58oH2HALN2p+pIeXgA/v1O0AKWq1XCozqGDYS5DuRIlEIa6dt5SQq8uqPkBcSd1UvVdKukZ8OPpYVVomcrcaoduvtJg86wANKixvj07Wc4Xs7/r03eHGRVquuwEde2jcMaQS6/GcW38MdKLrMKfFUlSeggHExIGnwfA/wxb5bMGjQxTgycbyKkz0tYIMIt2nAtXeSNCsB2+c/eqDCoJV/c0TY1cl/zYiNxKJ8ciHGXeKXDixAWFhy+UwXWB/CjMICBroK07i5owJszXlnhFaoE0n0K721tGygfT5cRAAr91CoK5cNXtn84GX49Oi88Gzh6P0DCvmEaRLJPoKABgltXPmjyB0evlF4nH0npZLQSQ8qWOuyyuUPlXkxd8GmWa3BEp5fez8unhGwXDhjYec/RSDaaxQQqIvTzkoL18WX32rpQ+rDXr8bMXM9WTrb4iIUEKdL5r+4ZMRUW8FXok54SbY5sPrGcSujGSQAR5K7/DrX0ysIQmXUZ9GJSXqxrfhJepMYCj20a6fvqg8Y50jbdmLGjBhI52CUjzkybTpXHc6ozeSfXYZaw3z4yuH3v1NaSFW+pdk/jWeL6Y/JxIfAepr5nNTwkRJVLStzpcsCUL2vCf47BvQ9iktnU+vM5AI5HM9oY2I8B5rauLAVKIMJPLgRi6t5SHpYqHXm+umhTpNMYxOIbfBa+eJAbFcPgAP6fYiCUyYd+FOmFWEK8eLMlDUGfPN/nIjOkEWjSUUyadEqT/H1ZCG1QotsEGM3BDCRtm2xYscgkUI5t/DgZvUePKE/y5X44No7pkazoXfrwLjPjdlxV9irOnaKk3ytf4NEZyowAgbz6o6fAa9wYM6DfMMOtPhn3RYbxIkY+mTCa6CeZIbndSl4NtVBJE5+2yY7jILubNMic0zqOlX3m9ABTyno4RgLJAY9mC8ONgAU21OA5oI/IZmXrrQxWgstHC5BCnBMcyBDHmTM8ytBJh0doKWfKzUjBTRAN4bp3WZ6pbryhr8msZh98NMizr9pjYUMenPZsAYffhDaI0ovHNEvpwvmN3yDuCRINi/bFcz1lGACKXaFBF+kHAcduKzKeen/D76nEJtxgRC46+7yYaHc3C6t48Yah1vQF92gGGVg8fLyTLO5KdbfcYe/hD3t5po48TvkKgyD8v5A92yTK5anJVqituKyIVUJYR08VWY+/T8WFVbBouAIHdddp9zNDMooTQytFLeHgHJja/6CoR6XT4DA9oruDdgnAl2S1d/6NoRmsDeY50ARoyCxTcxCQ/L1OlPovLBr0KdbWpW55Ly6F/kMAaY8AA7VoKrKHMd5kUBdPmAlFtapb9QSEtsmMCW6NmL3ZaHudnyPoEWYMSvaxwIWHwhhtb44iz2pyu7gXkuJozBgVJeaQ5vUViiG0dmXC0mPduXPKV9a97XTjJD/NmaPrt0T+tpsNpk77o5bU6vS87zEm0We80+eo9YNAZ5XdWBYosGG7L2gDHCWYfT+qOebnUjdHOawDeacet0hNzqn5HBdcktBoD+UyKKv8e/z+9saiU54y842cmsrVB+sb48Js2BJxuY3yDniIFdHoha8Zkp73tGhTF8TEneg8f4EVN70WOp2sKMnrNuuonMtCvYZItTiKDIEURoryvl+Uuz7cmU7NIkPIMMiGDCc/4aLywFbWZ/yrNfJEuo61BmoAACTPiZ7+hCADOfMqIuB2qBaNRIyth8k1Y3IwXAifDfuKlgRHPBUoOChkNOM4S7qgD1swRBy4AxctRBzsOmkioj1Riz3TerB9X68ID+bc9DK5PKS2o4YK7mkgLmzlZ8GojIX1mfwOMCBN81xx4CkOwme3l4KjKIrSy4ovC00thsI5DVC+ikct6psgBqlaNgge0Ti1yX8xQmfQ8kA9xtyrP6Cl4LxVRYzj/xeJAGJcOTA0KfkbUf4Q+FPhUza+3rM8X9eIoOE0dl52blMPE1qq68tzZg71VABhYUGbEVftVZ/C5JiyTB2d3i1uPX++xKsJ/NAoodo01Jh9EHFodiySoPfTK9GigRzq8rPMZ7ADvSlAcPypGRyUBdEu8/zkWUvy4J52eBY0nTI8eg3S1FTjxiWsech+nY54VgtnXtDfHJJJDJcsA6cyjaHcW0xzbsHxn+u1oXxTUnzumok0TI8Xpbw1H580srLFxc0b4T7F8Oj+mHTY/Tz37uEipVAd7WxtndIEuHW4MOAbgyS/voUvbuxQaeqrrRtHdnH8uM8RhdxN+3GFGFL9WYir1TDxFw9DfNcYe5Aya71adDJnG3BT6pGTVEc6VDYx9vh7WI//R5khWcNtn11CNCWp0nv1ftMPdcQzcYTADq9rFqUE6AU/lOTKKQMnDJrWQwPjBdCjLwShZygPfQam+HTw7/gbpg7OBEvh4VLRyF7dYVWyQaFkyP4uOq06uYh6fL4fJu0YRd/Bif6wRiYVVsXxH+1keJHZxLkqhBM84PB5qbQirjbQ/N7KwsZ01NlRymy/sQOFchrjTEJwPHiqnHsYTrpUiTz5v+cJjOfHx2u4v0EsnbWH4dbPDvYzBtJEdXx6sendQnqZ0Z0GJwVxfmNclmLrBwDdnjVld+io8oeiF2HJDlfASNwwu7ljOGR8OkfRPh5YUV9+G+I49G4PhMzdzEm3Ri5xlAQjjVxY+2PIPR5i4YqFBiaQlJzFvY3HWNb9kfX7Pj1nKI20r46Wy1QTaAk8Z5pmqglR0WrkbDzhH980jVJCEN8HnjHBIlrtSkCqzzJ4AuDZvmp0eF4qJhDBT2hvL+irDO+1anVUqjLf7M/skSfuH3D74H5iMv0dbRinxTvzlMlEkxUP8TXrAEBih93IrD0R9vnFUn2taiKZIUE3odqvlxVrsLDhZrEmc3yQb67hxui+te9ZVFqnM0wa72fiElytrre44kHXiRN9VeRB69ldc5xr8ILQtuTHpl0ZgG1An/NJ4WKM6QmMhkMrmEZQDiPUdjSrS4WPj4BPAKxRyeLvFOFx9rM6dMgALgb/eINCfFmlB1qI8k7B7d5YdKsniJFgdJh3Mk2tWlJ9W61uePf8/ahPyE700rjotPbhcyMGWBll8gVdGq50U9CFFuxEpXMA4nQsv/fdwq+kQrA8jz4YvAe5EaPpe+Mgo3IQyP37AiTAPlEiEDiyNrqORu4OvricYMHxFfDb92s4f/Y5ENimR5FKlSiw2oIsOBbJUWaS1tTWKBk7KInv+WiI5M9xwGUie5uae6DKFuusxk2Snl85Lj4lqkUidZUbPzUgsHzZhmr/mZY0JvKHvZIcMLBYnl0xKYS0CsOXPvkP0PEAeiXsSOkZLcyreQxZCe897tSyge5LTn1deHNol31r6vARe/RCpj6gqLd416Q4dgeBJIAbFgfBT2M6yD6Augu18blvRiLuYpca2yO9dBwr8to1DI1Yxpt2m6KBbZzze2euwtKuaq6mdKnZ2nmKRBeITinfO/E9ICFPRf4aIMQUQfVvWUlJ+LIkUbswP+sQ28I+wE+x+dEYiZvv0uUY2zBtK9GcfVw4EiIjVv5ksBPzeBpJcKTuxjQ7wox5HqBUeBatI9ZvlUu0ZzR83tBBeepYpqfViBMaXaYOwlwFalhzVz7hcGlSb9B11LIEUieb14b/RXdSK/aJwr7ZYYb0Verri5otwD889YDhWLZU0vyxpTWJJ0BfhN4W8Dv6qyUCeAsxRMPawNJ+S2FsaPIvN6z4BvoT2I7OTEUXgKUxdKVFgfPT4WOvCc5OGWSZPZqAH/4GLnZtG7znFo2gdOeq4CoPxDlHem8bsStGVcNST8tdcvSr3e5t3ccG18KSKIYoPEoeZ6ZN3Tx2hIcocByIy/RLn0c6qQNPbbydI+5BySvGhwqfdTgXLt2yvDu5X8uYwzmsFjO0aSjld696TZl/JeiZSS2DJhH2MaUeUahvuYVytCyBmPs4Lo+J0qT72X+9ph2yiiaX4XEPhuyImgjOIWmZlfU/Iplo680Qn/WqMMCWqHTFFzwU6D5EbT1GCXPDJiQc8LKyjca0cYlA4VyqlifbFoCHfftfwPl0wvtvbI5QL2p7tnRkLvaZp80oopCy17EI8lP+oFTYAKyt9MrvSD/WZycmWByG+G1Vh/hyNY43sp9btGG540jfdM7WdD7Cwmzm4QMOjz0s4hn8Dlx8xpP7VCBwPCINy6xnM97BSzoMVaLp5cckU5NZcwBvj/j4/MdaUhkZC9HcTQBARS8N5hYtmqbz0zIhgUGLi1UHr5zc2AU+ONwUO94OUEBwLutlmmfNhCeUvt0TjCuBajfH/rCFDQMz4KKhZ72s7ERSuChRO+roUUiRP++D/f0RC4MeRJW9MNQZK2MPIM9vOJB0S6Sx8hDjVuIiH60OyDyVNBOefBs/VFGCYC/QDhenSOVAE/g2g7JsVdUf0bbXVTKrfyCi9d5pSDp7M7vRC8vh/+zEyU+/5mz18e9kQ9n0q4nWTLSEipMHT24kfODFTUHywO4siIpG0WZ+klXgwWeZ0abuP4936H3m7V9S7oXH5SgwdUeISnjOtLYbJgCEZfYZdyYnXsmxwRz0ihXSJrNrIxRcGuO21KAk0Ni4b4xutPdB/mZeIa6JmM9k61EI7HYCFsflpjUC6nJZLB2G7m3jb8QCQzMc5Zj5T7rgesUPoJWta2Ub2JWXT1DCTAwJ7Z+1mv4Kfp0uRGAMhEOFWcyyczWQSw9OlQTbXzJ6gx1kxfxySaTA+TNtBtbq+x0mk2LJ40GW0zH7gINKx0+elPH9CHmu9z6f2Yr4OeGectkAoxGswhaTllRjGaq5MCb6mgfnwsybGv4GxYU4mh6lGAJDWxfx3vo9WDDaUIoEDUXw16xDQ+I1ooD/SLeR7yDA2Dk5XX2csYxETp5M4hllJoapCxCfOvyYx5be6yY00cHFxY2XMtCyUmCNJoYntNc756Tm19QpRUapTiy9a1F9gfqki4V0Ceqnym2Sa2IRLa2e8LkrfSCn+NdKLB6JFN6faE5T7pBWE8hopAVLq0r3unTXuYoPMcy5/sIVesL6aPk93+F8OC+TTstMHLm9JAZiZaPte9I5fIu7jpyMo4AMxmUvcOYpz3GQGGThdq/RDpKsmkxibjxOEN7m6pAqngU3FYKIve8yH82ewK0mNd5IZWH31ZnAAABO1Pou3/sMxswX3TgYNdy+mw/S61OgGiGusN/d1cTFegZLtK2eBgz/T6PQjQh5bdfu8WFzzxZFTr2ZaY8f9gmYieP55OrEVKTHPqL5Kjy6Ht8wS83MYFICVdc/kLwTncP0iG3pJllSKdLlFptmtueHR5XYdIkogaXEhycSB/6xKrFQx24Q4cmxmtEXv1k60c9DZvg3d7rwbKjjNmkSrvs4Wc4R79JHeXX2gCB+dRn/ZFqtLDIMIO1kpWjIGqYMEJCEAPqkNLlwT3bYrQRoXWgRuSkP13V8evbf5RDatz+MLxgav2N1qoSqFpP4lGBlazUDSFeFydDOvZdzNowQ0hzVS7tqYO54yvn32PKPZrQVnCPzfNIaVQzifZyKU0+lpJytND4ouVpLxnM2pufLPdutw7sUFzU72B/Ro61rGKN0nBIgQugN5R4iRD1mOW9ADnqeerYEEenSkmAWsG0SnxdaD3rLLi1n855nHTlqgPddvIvKpw7R5gwWwWYDoM19IGy7EIuHx+K0IPnKUOg39hOA8FXfv4W9lwbzl1oSuFlrthBchcGQ4+1v/oTfd5aeO3ZpgS6s6nJGONZ1br1l1PwTbZU2FXRRtX1EHj0GWOXwskdH6/W5MtRfb1DsY2TkcbR+0q567eiJft8P679W1NFCaXyKQI0HvWhkrNasicnCcWr9lrwrvn/hDOfgJGlDMVFC/hKwviwiufSOoWIpdAtNyKvz8NKEVAOvHdyEFYirSmjDkwSz4+qOXktOtONakCM3/KdmbeXOQrw9FprY1ksRsicycG1fAfPst3J2dAf1ma44Xc9vebCLHbxP4ZX9y9gdA08fV9hlvFBqmqSs3O26JqhI7Ycy58zkpEQP62xiZcGriLf+GiyNevJN5EDc/jXQgkx+hgKPZ22qKgoRXUR6pPyEGMKtypUgeRMiWY5GPIDezQC4OUI3Iey3aHDGQv2w0oMzE3WMWexOQMcoa06j5UQoA5ACGSz3fx0VPyfLh+BtVFWeEAuv8AnnBwZyLFggnp71g21hSGP9huebYuHRPNQvzrxGlovt3QX47Ud1C4t+SDlLJ/hWFrNag97EC1tAOIbbZtyssuFiOpsNAL2cneOs25HqkuWdibrdyzBk1Z7ElM34OWTCVC7nWPo7NP6bZ5uT4A8Xd/cT+DCgJ8ZeYi1suzjW3HHlLym6/0CDAttt4vkAkkDRJicLxvfd+xMUkYa8eeZPxILLGBSWRCNX4xQ81kaRfPRn9KslIVhymFgpNyz+KQn63n2DPWx4I2QVCAhuXCSHGi7hjApXXxhnMr9Ed03A1hlLNAUqp9jC2N3tLCZ9VCpV7aNs74pglY2616x3X54eRKek19pIL8XUUytMhh/4m0Mc3E9fETd1YYv99pVTOIAiSMNQdkaV1myqFS4a3igb3NIDbXtgio2ji4hfvrIAmhnzBFxOTpxckd9EP5t8ZYN5PmAgbmgnEqlaEg+zWuvm5diy3cA36aoWS8PPeZFVlBPEN/UXDRhlCVIu62esX4QYp1gpfqopCNaChsoBGn0b571bzaoPlmyfbBe9uaXuUR+1sJC0Qs2nj/XdEgD/vnawGUiqa2U9DbWej3RyyqBJ6/B1tzrDV1NpM+W9yWQL4PNZUS1JnnvcAI9ZDeBcCCLWdiAIikm0BQmTAS/iwDCviMdPAs/It42mWSE52WlfevCPfL8c2FHIOetwFgXyKo/Zz7/fPg011tyUEOX4jsTiefPW37/wv50+vKYS14iAxLsXz5lQoyuHhJq5IQ0Jcxl1+pr7biCxtfzdhYrsCooMxiIjiccwZJLqzixKebU5D34rBnqNj19zOvuzyvl3F2c7rblWOACzrtlxLp3IIfEj9GNeT9gZZlRp9ntI5OEtpeBa4oZQZqoSykhxhP0LLKzHl/L6Ob2jvjcXP1pJHdkju06RBed49nKhTNL8LIQPz0dv6aR81B1jwz5+XPh9kiPrWI09LrZP4YznZe3HlvV6d+n6PRMzwRw33BpSU4PfKfl6Wn9RODupaei6TspoTHBwPpxqi8g4YeGvk+C3NBz8++sYuDmOoK4p0QQCicDHerbhLjij4ZlIM0kOrYjWsNvhvevxhEMXMKxuZshrrEd37n4CzUcxTxj9OWgviZ98jHKKhYshGjLuj4EaJbslWp5mokgirsGqykBAIpzvaAcMGW63dM2eR9iQ/Uoyx4FzHEJLEhquY1F0hxdKOXpPvLcCaLQpXgvJdrdt3yJWN+AQ54Jn407vlgwnFaav9JDQoMSrHSxmR2o1VE3hPzjE6xE9b/00qEBf4lqwaWHXEufgq/aUq3Og+5M/9OFDpT1GPtuzAR9879mBEp/ylWCg4GqdJnIeoF1RRKP0Nz1JVIrUG1XDbp1C76tg2FkIU3TxiUQvXiqup3N4LkmgIgUYcwuRb6j2c+choM5mFPFBRnbNQ9662kj2gPKy6sOZ4mj9WNr3CA4nu0qVBQZYM+IQNevu8pefOEU6fp8zY0zRA1/eQV0yGC4T9dfNAzOEhY023AbOC7qW+ylNTds2fkufd19V8r97o/cJ/+GGHrWsoAcTVq9oSWFP+zbZygpW9AC8Nm4qKPTcmIl62sm2IKRkHs9yQ4aOWACJymoakQlrAY7J/L+WNzldKKNKE8jR42QmAeeNHOoV27DA74/g13Gzv95rjmhoq1B1BqW3mWizFDGvNK5aftH55cPcAhmMca390xhYgg+Xw7Yyc8pHAyASeNVJbb+/NHYQpGfyLGz9RdWko97yLtYd4XvJeQEi3mQg2DvH82rQ7e4R0RL7Eagu6BGEDdXgDp3sTmhvnd2xtBjJAlR3u92ucuJ6m4jsswQdtelR9xFMbPv6CCTBs0fXGtWHXQZUdKE79wB36P8hGw/tb33+m7rgl6pPXAIGxZb3j7zzp6K62mxYdX3FSpta6u/mNED6NTewTehdbvbLuo9qvyh3w3AempZ4EmZOIMfUCgM9TjGh6tlh12m78dPSh4KuxO/CDskeE6kfc3QopjGXk/grlOqSjAM1+zBeLtXEVkDhY6UTaUDUnxcG8gULS+II4RfQvfT4YR2ODMzhfgfEKhNE9b+DmweGEQ/0C3CZRBStXafuiIwlYauNvh2SrvqIs21Ka403AeRQrOsCOZTRw+S2v3RoqWCqStQl8cF/Q+tPWeI6yuOSGPK0iSmvx/E2yk1WpymDv5wBtOuhOMDvKFBTzWBbxd2hBoRWccvwd3y/zF9cHcZjCDSuRVykSZLp5AOhlnM5jleRPAhRSltEmgCzrEczPYLUARLek5amGGfGW7vpNbkm3ke2TvGp9XWBhcunZsTszeynFwQ8nTtYxyZAt8lbCm3um+uUd9cdr02y1//rnGy9AblLXRR6Te9ejkfo8bjFeMqq1gJxOTMmjB2oJLcjCvgscwMYYLLx94gGva3T8vdNbsSxPCsxb0Q7zaGdwdtpgXwcN5IRBhc+Y5hRoBc+v6jPgc8ujQKH4x05Q1HRaDJxQ2TeiSBKsAvIUKiD0parnm3Fq1c++ZiCf+6fkjfEQYIdWhWpybsWRGi6+somUHCKlOgVA9ufzm3aw5ZM1/xDKMhKX0OFD+GqhyVHzz2QPqvU0U+OFUbZepCa+h225ifkcICGAbvxbcakpVfnWHjD0s/SKJ4d+JuyL2/YDQy7skR3pKpzrQE55QYW+B7sCtBp5m/BbH2alRXiXDsFR52zh54ADD4TCMiP9vP9VoL4xDwIWqZYhDhRXTLi2jzkLbeWQDWPLhAvQwYf6wDUsPpPVFWGt/efZcPqfJsKznLpTOIqT4v7tTtRnAuBB2GGJ8ZIpxPupvHdW0J1YhvD8egU4Qwuhkru6Wfxs3FoR7Clk+2l8UPMmIHanKcTtSUmwwTBLJx+DI/H5LrZl2SvyXoaEFo1OARYJMx0mXYpfjqVFUUnkIuPzVCjC5djsiUPmCohV/UUfC1UW2xN20Nqf3MCEVJOV2KiduebxrxVGdJ+Ng7dt+Jeue/fF4uQIX5jcx8XehkNdOIdH0DUUyR1VQ6RMjAtoRJn8a7sbZdw9Hhby8XI8a3t3njnezRQ6htstYF56c8HULYFMUa7O4jpaXGPUcyPcnxNPfMOiBX6O4AUAFtRQLPN8nYJyp7CCsEbBNOxBvOt+Q+99lWZU4gDR1t1zS49yRZatGu/mqolsuiW1aQeON5+s3pdeDTb8oVjTyylqCL7bX9Labb7Hr0/MBEpfcy+/qOjLmbOb3xJB0Y77dT01S1d5xzkuTv769RLIbPniIs7eO9Q1PkIwxIrEXhkZPDqerUnR5P14cjC2JDHv51qHC83rnR70L6KhtNOJrb4g2xL/yhPZtBDEQVfhnZH9pGfNCehHEchtcdixoBWrV0ZA5DFoCTvQ9fec+BSS5HbLDd1vjdNJcwMM5tuKVUO1ebXwqtyScRFjHZb9wFFZCYquvT9ybiu6H/zbkhX5QhENaE/0x1y4CiMzYQMSbEPvPalNl110ShNQwRXMU9ZSyLqj1edqCT1EwCEbrhsPvl2tLCtllnOkjHjcnO91RyQc44vrPR2HJRC/7EpNwixfAn4fZp9io4ipgyz191U3KCUzwB9kK5YcjYl5bCX732oTcAw3iY0xV0P3AQtK/FHce19hjTcGVnBNuWhR+GSgk1S9Ia1kU4AwsxvmD4mCC++eK4deUG7maG4mCBLBPSGZudY0zivWkqo4b/5Fz1dMHGUOKFPaPQSpfFG9x81EuOWbGxfzbHLZx8FVpBp6Dt4U/DXQbM6MJ83lP2KwfTy6VTcsOMk0fqbe/ZWfFzllAlrknJV4HdGic/mw/CQMQUvYgnQUgGz/nXytzqtPyyK5s3B/gCi8Mf1ZOohU/Ejpeo60FT6UvAfz9mF45NCPI0fOy66/fTs7n2j/C2f0lBb6oQncZ7uk4ZOAIir+9uqESU6+iA8t5AAlMmD/A9IY3DIgV4KnZqveivtqoxcesiOGxnQYGlH95N/b4EhMNHiHtNp+CLACZOSan11udF3dQFz5EMCjkDL4guYqURVqwb+JNtupwPsIj7/0+gEc1BJ7JeNqc71Qu0UcKz6cxgpaTtQfQqq7RxU4FhLyXkDtDVFP6oNaP0qcEt1RNpwCBR3wasCTHT/SaVirXj5cvcIRRUjerD9RD7X4L4Xs7/ETItEZ6E9RNYWDJVDvfIIUN7bJZjIv7YqhJWFdMiYDXX4IhdG7UNpHv9OTq8oI+MC1/kVi4SDyuPlVi0fOFBzWKRzeqzNTyXsdCqjCz8roQViZnh78PyNE5X+YnA3BX5OKFppL7/JJkdnsZtloeZYNC3sHK2EqY+2StW1kaygNFGi1Dy6SoiyI/z3gfaF/OPT8Wh5JBQ3BTwv3Bv8ezEocI0DR/LqtdlBjy+SauvUKfDXLlr4DvrPI09vL5aDX6KpE/rSqDYD+JB9v+5WA9l/bBRfpzK3oAOxZeFALhlnRKGkiEJQHUXXLg2jeB1vGba4kljt4z5i9CUPveY2D07fC9QpVvLlcG29VxM9VoAV7huOp/plq/KA4N/uQBNo5iUnD9lUjSxDULse0zOyn+dGA6BwzFeHr8ASZM93RumKRUF8lBVJ9OgMKUvcjX7XjHRomUNL3X0m2EyC3WF13rkAVLekviuTNDHKCciiOKazA15nz2lW2U0A8P/QCMOhsVvi5SGob0JQ3wKll7aKE6zezCiIIa9Qge3CfQ9u7DCon74vXnSiZDYEp+Flw1F7/5SRt/YnAx+fDN8CbtFy7YdeAzUXZGuVIWIiIEmPxRQjnOINqZC4GOn38aGYfsy8ULVobVwdzzFOrwG37N1kttxY/9jpgIZ+QcVX8C6DiK21ZxBZn4CAlH3tKUWgcoWLfso8jeWhjmsWb+jG//26OJXBPDbHfWkXGk+9mHdtStXCnWZ69u9Li3GJ3ONZ4GRKwa8TYYdM3DyluZBe+xg3zoB2+OhATO3LvHUSXoUwlbxPixZ41vArBWXD3dkqiZP0xJVjta08Q0cERbv0Nmcxn1Rjg/yd2nqTd1JIvLiWBrYmG1JM7odMaDmhYBe/cSvmZgNNtWT0wFTMNL3vejRclUj0z424rBXBtrse2zHX43n9rgKHfJ/bEXvRXRmawVlnsPdums5jl2/tgSUmxBFEhvE5OltU0GHmeqGvd7enQfUAJ7aI/xW6EXbx5VevYLSHohYCE9V64PDvUXwoKjBT2mDn8csT2Rckr/QrClN5aerIGvE7akRw2sbKSZFKFY/i4PTPxLeXzbWDLbNW8hn2haGLjfSLduZVdj4tRlfXv2b/wOys0B5u7lEcBo8gKPSIH5eyzUEsZdPm98hajjr/c/1utcp9xOicnvz/dCx8m9o2dx0C7G5yahACPxwVHCBoFDjMGvMGBrKrm9Yh5+oQq5N5pPRPcoP6kvN1pLI/R2f+qwXE0vnz9pfRsXz/nixNNbtLRMh7uYDtLNcCzxoOOhRVvDdHfTFpT6DuLa2/xxYynq/PsuH5/fSywm2yqFbgKCEtomznGCp0OfFX85HQhPw6D1w6Sq7EOHaqlf0zwqweRYhmheFor3GsLhqLQ9UKrz/anpIxjPAxrnzvgsm457htEttvmCJBR1Z09YMVwssEukBomt68qsx6BhMJHj7YPK9e5us8wqSBFPn1WejV627Qz3QqBWbORvrWueNag9alYf/t+j9C9M/0d0WdRsydKFiF8Bp4sjLnZU/BALSzEpewxeiobPX+Ksy9n+MIMBDhwKWC5JQ91+GQ6ewuTnv1D31MRBMkrztraPg/2OwhbQNBhrfY5nSfkuEP1s3JhKBRdm+yu2XzfT6269/hywm+9nDMI27TTXosRS1hA0b75PsScCy2e6yIEhr0ZzXp1nptcPs5/nm1bxSi8xkHRiDi1laBfdPkJwXfmJVAasFJxd7LHoU5sf8HlK0Vznij+lVMsQnPY2glYf9jqT7BPPrN2QnjRICVDFpn1bP97Ogpqc/G41t6AFvlcH/vTAdlSvwrfFjkFKu1pmK9irtEjzf2rK8YpmgXqRELEHCdWXddwhpf5Uy/H3B8aHe1grtfFwell/K3OvJ7gi3nfKiQSDOriwLjWwr6KEWYF6feAK13iatVF/gfQMB5ef1Q/EhUy5Uei4r+uJ9mkW/gkbesI4ykVQmgnXsLFuCoMU3/nlDEP4nMGeJSKK5m5QGVZ23EmwaJfm3qLul26RJiGwnWipkGL5HwyxsjKTSN9gSVDpG8Bf3fRX8HvTjjAub+aS8aJysQmfqofzix3qqxIARcMkhqCJVvOGL6uIyAFNn8P1ekxmy+w/5QNVSUEKkAWvvLLOC/CW4vvg95+BnrJMjaAS8hqaMmU1NirpVC2471WaFiZJarNZsZnlxRrapc+mlqr5M0WtjfCpmWuDCZUV1JvS7QxFU4dijkPWCf9/QLFoaQf6cqGbdldH6psAIyaDpWkdIcJTtoAfy5H8zIR3MRG/JixwdUF/Bbu4MmxW0qGaMuLkMJXTLA7XhZ+TSXed6SRsh82Cco9qSTXkKZROldY3jkQn+zJSEbOB6L7jgWa+xm+E2+k4x/1uumrrw9YVVzRSn+A2iGiOEWHN9H53JUb4g22aPJkFMDkKBLwEkdldaev9YYIMwY9s2tBV1J64OSryp3/h2/2OQwUXNV4U0UTjl7caezxx+HNwUIsLzCXWbS69KfzRAZxzqQR44ClctZxGKgRzQ6eHce5tyJJ5Yh7GmBZd4kwbt5odGXKWnFFgKhPyXfep3r6KzrrWWyegmyhnGq6lo4GfIJYMZ1WbQl0qwuhw7E4cnEPnc9gGRBoV3HTHtV6XqsrwAyMV3f1sc0/s/ljCFkSE9iT1X43u0s7MWTw6qFTcTcT5Py8tHk8Li9Py4lk3bIBilqTHEOCOmsa74q1HCMqXsxl9gQIoxUdp/IdvoyqWoXqj0IK/YDh2FdBxvshfwmWv9Hu+0izk0tpRhcBeI74h2iqIgEf7EHzaEZrFtmM6o1hagjl3EnSzm8tuhmpt3Bq+4BVy8WvvTfnUqjX9G/tR34by+ZvpTGUToOqXJUsu+zvWIy1Q+M6T8DMvqQoBZTA3O217y5Nfp9WPs96XcNy/VVsWHw+vgbwVOU0Y5/fDqOOa2jVKkxCvYomY0dm0ccf8Kc36EuXAGNdgyZbIfHhn7Wcqpem1eFnu4deEcAyiJI4rd3ee/s6tnZqmE5FFp/61mvul1O3HLTujpkPvAaWZYfX4gOW1Y2tBQxMa9P/7M7eehpglrPmzpAy/wdTB1ustbPPh4iHwVBO9gz9RB6GdHt38EuI/x82aR76L1fmxdWoDLa7CYAiQY2pUUj/pLhQ956oGotes73TNvFRzAfmUso8a/1ZkUC39hd/4FFL+Jrlxcr8+eks8wMEPhHblCF18e73r96Fu4I8rUVE/n88cK8012+ilxmj4Gz/ErHL30PD2mwfE1x6GdeK/WQJcdF25PrO5N8lPdG68xwe4dXmx9pPtFgVkWMLw8p6ZTmxbHNSnw+NKtCq946CFyacSGsdQGxuQWXeyAvC0HisITptgxEM/r9TOVQFCm+ge1F1RUtllTa/zkIYnqFyrw/hxmPZgDn7SEBZhQThbz/fNiwv1r4MItXnSIDriUdqIL/tEIxfTRkKjk7RxSTxAxUN4BYKNHHQiH0YQg7bTlHeBalLyT1t7IOw69RvVqvmFogL4z/QMymyoG5g75kS1IytYtlgfTd0BVp209Vb7bYmQsEnzu5VG3pWowDguFWTv0dBHtcEej2kGk3kzCvt2wUqFlvUe3MU5hnmQ36Jfsr/idzwed6tDJroGkeUAhdcVdO7QsdiVMbiIJej5kHmV3hXEGKJdzVUsgoErFW8YFRfPcMI1vvDAoAkDFYTPPkzA5nrv4hNdIVIdIYD844W1yCoxzLy9EcQVX3Jmhcx+BaK+kJr2XGF3sk9fVq9Hl+E0ZqbZ1Yg735p+/tGgDscOu+0ecNtzykW2l/4aNu4SLxbMR7iZ6eOYnYf+Ja9+gxlfo6c9aJScrQXwoR3lhZoMHpBj3oiWvJrLyNxmPvqsYjQ5mkib0DwkOxEQ7FcxIUgKbthRaUg2p0iUFWTbY+kE3Sd7XtRhgVkyJAv8IkjR2xbrmBYvSrM5+jYNUWIsrVTAItyEgL5EJ+phtrh2fQY6+XlHmt1fvhXsRDDVfW/Gb8tY4Wm4vfPnyJ3zgrUhQsZolLbeAJqChwFLoe/79iu9UdphcnkhB9r/LaWsSG3F+pX4z0coGjEDg8kRx2C+bW+fnaUlB5MLRknrElkePKGEOkN0uCGJfRAUHg3g3KwC5Iy0MnBHgbKJbaF3qKW4i+aP+BQ6qteaX3UJ0MiG8nSGmiQBgK79Q+hhdhqn0swF5EcZ6BXX1NVN+vKIpXz8BnYSowRuSkVzgL18GF5VOmDC6sK1GmC3fuXHA8cm3tPiMZ8G4GDNUiHNeqpzXAXgeBWOHskYt5DphnaTCFriKo4tl7fEGTFeendlyzZ8njyJGf9DLlfB/B78yj0au4YxW81HEy1EVsMy3oXUOFnrsKJT29zNEeEsiZEOedSKFe4vWw9XbW6CKuKWCXsvo+9PcG0aTOEWmef9k7349HQ4pOvYiLXGyB5+9EDjwopJtKeM7w6ZqFiWymQMe0xe7lifuqUpugzqp9cdjf2SW+/8VNDrmpS7p83hkWNATYMKLroBM2RS4/4m/9bCqlMmJod2QIbteKOk55/ORCH6Xs/ilVHKk5M+0VieiGcQynk2Eq684f4S31KRZNzefbt+NOHg4SpqOX3q0GMh87gWBTQlmtmT6+uiX6zc7A3oQmCHGVwFr3rW63aIDXzERUTubNW5WoVT3ftUypz8PnNGAFZ49IYruOkry9YO2MiX/PuD14OB+VDoGpw7ABbPwTPBa8x53Ue6n9BC0xE8+MG9QaDT2EmNsd8+83YCnqraZGyjCzeVO7UqDFn4Y99YIt2O4n1dWD+smzd7M8Xjx7Ubq0+KI7Mu8xW6aE/t6d9Mw5M3Flchy/wf17cDl142NHNkHo4oJzFFPB+RDWraKFG8ffCnEoZGNYGGc4qWI1eUUUxh5No+/JO6+LGRCT2K7SmLkDkS7d6fOgr8HRkVQ+bspRbX8ETuZtkao/o0g4GctLf+zHIam7BEcl4geFYQVBSdn+ccnhIk98+dC1TSlq6EybG95WpwH26f6lM8k7Ep5y5gg9WzULctMirTeZPsiRR9m30XVZaPVApq3Dr+cAwpNx8xjGAxkMw8idunaHK3D8VGAca4gw+gIqWVDi5GgajkZnc2b9nsV0UpVa8BiBDjLKt9lmzg54Rv3j9zwN9YXOCHIOTfXqBWzCd4QoTQJbcjcSL6KH0VU9pZqy+l1z56uK+Y2sPvOaYdAZSYPSJcbV9La0aUGO5CIEDVJ6TdbTxnWD8KHZ+HpZjutEYjR/VrTM7Fq2Khj7ja0djOmPI81tCz6UaAQjRCZSFiHGWGdzGG1jhnsxJ0xsd3Y9D/AY+97kOapfStbh0l308EE+6pLlLm5+vHB1EI6pCBA1b67gk8mdMsHBdprtZhTPdoSZI35cAF1Q1RODOpJYPsNErEuDww0w5pCQi5Wr6hmvH/9ZfwPGuq0J2sqyDGv0dlZSPHfoy/Cssa1Bwra2G7sbx2pjDeBSJu0sgKY5HfxINp5ff0ZLONkp9ZxDz6b7kVPaLB+RJ8lT9+QbutaOrBD3LdqLhrRoA0Cu4DoPrnQYJwyMabIf9vF+6SAYq8/xRyxOL1g6w+q8PdTl8SBeeMeBBHpJcuLXG/vVKTk8ynd8N7G9qxfdgj5eWlTH0m/Zpw3q49WGfoKsdyih38t0x1fi1f6QTv9gQ6vH6XaQ5Immebj7N2zTny0UNI4xc/0YscrGQqEKjygX7GxHEIZML0kNCuOLHWIoyCnRlKvuniYADpocHOW0Z6pKh7AWgfuckmwhzrgSU/fyUbq2z+FDgDH0Culueov7rzOjapBfmiTwn0gdY3RjdwLKF3YxJecJXescUD85AFFAl2PvG+rxBDEjjpPksspLyEZ5b4U6mGAH+eZlntggAOGco5GxGoUlypH4eWncLTNjvFkhjSoi0whd4LY7UAAmfxpVhhYlGQ14OuD+A9WzmmULeZUnOKtoXNJB9OCO0CjNpiGMWqK4S1brshJWurgOj0Jv+Okv+tMkLJ5F4dCRZUpj5e7WD2eYpes3I4wuZxwXWuDcDcfwkrF/ibvGFHe0fkWJi4eES11K03xw9DQFHwu6bcn+Fe7KAIi2fsUwq+iWrXEiYpoaetfvgJqHwn1XyERNSa8vbLs/BHfjyiAqxbhXYJ2PXANVGwEh5oM6lJbStdRBUBRgIweF+8QN9Wf6tF5p/AmDYiSboQvR2O6YpCLBwPGA2lbU3+n1LTVwvfBSHTZX2xy/AifualTNr2/Q14cc6dVNSm1AG6SsuhW3JAY45hBn08SARC1SoO2vxjzuFh1TDD4dT6zPTqHG0u2p9QjLuXU7Axmop0J9l29XAn3qpt0yW/TtA6yRPt5+9ylf+d4vm62mAy6IhCYllyZuuim6TPs0rqdQ+QhUOTSnszv0u7NEHdfY5Fupd7zu4PsLql0p9fiZzhMEn2AZbzcpZ/jTrhrIBicfKLUjgqhSBvBuy0JH5AEiI025G5XH2qbUvi7sU7+1+U+XSfUMQqL9MuVRjnbu6osRaDfzvBf8wfrwVT8YILo+27vMUtux538SmNBljwu+cPbGgiARMnuGOc1wyfwSOC79ai/SS1CYaEZ1MEtSLew/5/wMWxGGNKSTCyhdWCSwDpPrNb6Mml8KnKLP7s5f7OOVJmU8j5dSzBHMt2djHlhwGEFVw/FvDFeHCOhywIZeJJ5YqSRMZGxRF81r39kxcaJcZ5zmrUwaGmmfqBC0xosc94B2HbLGg3PNSmoR7z3pDbvlLuYRUaQpWLIyrwqNrQOtZNYLHqlPGTPVoBJgKQkjypKI7TEcMXkTYIv+ZPyl/wdUNIIxHKxLjpO7wV+o7RjTMh+XyTf8tTMS8PjPdjlW7CAQVnCmv5Bi36yp9FkqTD0EXQnj6uivzxwUGf07A3wtW3zW9HFm24qBkimcNkATuABMFP+MRC5L2ejBI4CGqr1wfIkizjXl9lr0IfB/o8YtfIzTwrl8jQa0N/XLhRaZJaiJMbWbGoFrsnjLeIR8ncwOgDyVVgMlc+CU9xU0CJ0UG5Ge/J6xa386iQddN5/uaI+cHKPUAjpr8yQH88XiCkR1WHu7XH+oWT7GeI1LYNYtYN645kAiVAqMSEAFCmf9OBZ2eSoXiK7JYgzNVflJrsh0lR1vFTSxjlhrtVhZL0PW/E7K8hRA2vYbXY3+8sRID4ik1AnjMzpViKoRBlcqCJE0I4gTS4lbXrQwn7kL8cYUHJLoGCtDylZYfYBHTpW30kKTGRDk+/ygXLGsuDUtM4yQ5KFNbQvN/BGZNC7mm5ocA6AxQnrHhBvJVYmzQW5xFI21k16AuONZxGx2jBi21vR1qmYkSi5jtk5nRiDTFCRaHpBcS5RIYOTTxhgXkMDEoega5xJo2yCiWYr+cNvsb+8lCRqM6cZeoa3YquljQAUa3rd7y5chr2F+hqyshqL/rPw0dIxKgUq2k95AJFNYrYvXbjrP6XJrqQrcw0Z4t7KFQLgdU8d1fv/rA/sg0OHnwFHsbjPBPZqWuAlTvj19Vr9Cdc9dSbHE573OIadJw+t/4wcSsf0Dw3pI6Z+Ump7qu6E2fGXghQNFdI6YV7CX6hw1zOhmd8pVvJK1+cb3325iroQ5hbe6ismlr6pMGd4E4sVz+ce6Z9EX8Z6GlyJ415JgXzWX32h0al0eAA11Oibe23DCWEgV10DaMjxDug0Y4up/pSP1TfcS9ypnL/fRrljpeH0X5Y2X4flbonF5dhXshnR2RESLNoicfl2TR+0iryAQYcahjumTK/vxaAS7slEztdSqIwbhnQb08p++3DoTShlApPz+facqR7sSk4pyQgaw8ZI3BHlFj63qfxdZT583Iz9c8kpBQX7s78OlKFE5UsZkcWdXn0K5iqEw/75ERNaToCk4dvj2JGCU1WCWaoMQbjtz9/Vclh8zWFAGli35/RqvATlWbbJLVb3xwFkr2pzvTsrP87fW8ymQ2PWZ+83KS7heOtu6lSso7J2hxw54Do18FY8gtc58NZJ/Vy+GHaqtfqhpBY/ZxUlCVX/y3FMWHlUpgzV9cwSG1TB8eG1oRhCYvoYXEirBuKsudYIAKSEbAsyIzVNxUdVW036uYGvrHMyfjOqMyougCezr704oh3RdXuSowd5jHE++o7XBbKCozT11dZM7c8si7lTIPSHHvQyIsSona0McZx1wfAwxExOCjUW6xBTItK3mUFx+i8+b3YOk2Rkr9MxHshmTzQ1W28PyEmGdlYxwJg3JcFiJvQQ0kjkKO6IuFh7GDKpBeLuYDWAncjQ8/eETRDxaGoVuiwvW6NkQ0bLwZFPO1twNxZb5f0mmoS6xAHULpNdJVcibcW9N7nJ6GqC0G5omUtVgnxUZMJVKealpflhll+i8ttARwljMef+8QY9hbC4SIl7uBagqY+8pF8k3KbwXbfThFHRUDbiOL+R1Q1u6wOdzMFfgxHZ4cu0oeSJcQinDcaDnkftRlwmLxNSg+nLuBToVXq0+AaLzoXxgTAIgGd97TgtL+RH4Js161ZUOpPlXWO/rlaz+vj65mM4PQQPnMwgOhIlwvA8hYPYDHOQp+tykMjOgPaGgPX+cXd0nQN8/L/xRXTidCL5ibPXPsl4SHItIAy2r7Gr6hVRys1nNmUy0gLSXTEHZNFR9LfPftFh175Qj734HW1e7M/sPY3oQJBuQVTeJ6kHC7Hvuhs1gAbWYFBqZD+i23UgQhqd8DHpzHL+Sz8fH2keOVEpyqs7wpLFuHB432IMuBXl8usnqRObxNWQSii8XCUeVLFAsMDllZ+zdDicgvg7SxJKGfclEHAF5tUH/LVvdXj89EF+d+Y8IqcOazAH+TVucng0B+EiNvycjXDDo2i3GhXqE5ezqlUahIEq7YGSy+G/W/iocslPVD5nJMLHyNGe3xWNzmu825agLxbzEj4sJDZ8HurzV+rmWQAhCcm98Q3pjBy4Gr9y0GULJ2q3qTPe2QYjiTTGFobEzk/WPFCmKrlQaIhLUFfFOise4JqDh12Wb4ytN15us/w3n37pRRGhwJkBpb+8hIDvXPK8e6qxjstZA2XlU/tz17RTT6lAhbxekW6CoZxOfxM3sU2npPL92dSmPvF3xBTjItacBHpi9vZV9yNscpPLtGry6dO3kFPyzNtTgseZt2LFh61TLCN8Rc42ZbpthTaJvwd7zWobc0a9mYqzBXHL5Axh+hVmWvPAnjuuv+9BV51gNEl7XsicTtTeQyQnI+JbpoFLRLyMhzd75QMYYwF4JGyw6Bl4Kl9S9yi69iI+4m8dZd3XWK6nR5J9nL3/VLzmOctqfHn9bxEp7apje3R3VSsLcTVHBwYL5azfUGErg5ExGelNAVbAdTaf4abRQqb7Hxn834JVlC9ji2OsRxSWRQa71LIVhN4jrIIWjk1JYT0mruN8/hu4DVtI7BUb21yFDOAynfm6s/PBTqkhZfYhKTumbj8wbZiD1h06W4cpZJiexHUz5oV5s75z/hXDfD3S+jYZH7P2VwN6fZJ5fX0UrHPlpOa+ZUaQ33ayb45LCuzgRK6KKufqy4TKm3Kgk3d1RieOQWRId0D3M4NuCHbIvDlpKyVJssSHTr5jrAG5Dkv2ZvSyiy1smu0TN2D9AopSMeLbavoCGsOZ9rVShE6VvyMBWcnXw9B8smHMqqOfdFExI4SJZzNam9NqT2Ma5sqHcjx49Flcg4Aau7SUqxFMCHWEqNOjm8caqEcsiWghq6fP+1dsTz9ceE0u1ggxi7kqk4WrDMEQHzJapFkWIOwi5Vy2B4Qel5/ipZIuhw+0BxFd8BeYWJCYbNF57hrFXxlEgbAnX792j/rpEb9Nb4wQ80ILmnOQf/U9xdwFdd6aiyZnogtiaqtSegQIboYyd3xibPJHWEttbdTElQd34HzizQ6THDr8J9Ti5Q86ivFxqFMAM+lJa7vZTOnOlMgBoti4S+X3OTvsuM4jGBwigQuaShLw5QBjp/+6x5A3oxE+n4J7vBpFhUzWdsgLRDZ+au6NmFUXW3tYjdE3TxGNB2u1/5g7Q6VsMeKyYiGDKy5UkNAMYDIcff/8B4bvC+RDNVpsCHDmoCBefDj70gUo/HqSRNvF5COneIGohoHueHSNZGsGMYhsdleS7ZJKHNnP8z5OsbdeO8cBK18xNQ5cO0UBCMZXxYOCNgRoq8+fmM9zI48m+vD8lnDeX3b7z+eZIe3cxAwTY6ADYJ1pTvWfPYg0VsU+Q0BNSsrzMJcIw8EpsZtmC9JL47ka9ydhAWcm4Lhi3gF0rdyvHCTkEyz8UjWhGxbu1vpntUzpKKOZ2LTTX8oJopWC5FxCAKZ2G1K5BCy8R6XETmjpU0i1K1lf3c+8fvL+GdOerw5QJSwxfebZZ3QCkItfcsYxAbuIypKT53jWAdm6GkJ5vwEMWEF0FPQTnhH6nwBwOjPxrB2kH5J7WF9Fl+zq+HwhazUNzgYM1OPVoFmigkuzg5AOXyrn6sVyE5D31sAb507xao0iM9nI/Emao43UXnD4ykLKoCbiVDKHbpSf3Zip4Zi1JEPNOMRKCiYvDK12Nrp0mSjJSP9Q8cTAf3GQ2Q1XN59a9lZvXk7tW3FDV3pkjaCC6XzAGTiqP2yL2g3+53Bjwxx+AoQyz+olOFWQDGwQx1Nf/FdU5wNlqc5fwPuaZJz7CnyxkSQMw3jZjn0FmO8eayPHBtp6SDDLC/GH7avx4grdho3/C5A7mIyETLaqznOmhFvz4LIqKDXp4BY37jCI+CuD2Qw11pr4hAYlXuSC/B95y0mf8Krs6AIDqo6tRQ1yvTxPgmeqh7VFUlAp5ej2a4AB6Z+7TvNxpQ+/eGOLC1fVastnW9vvoN6/2hQuPCSWUfBCDFtREuWL9rqlStnv+8Ed/YJFwX5UmVYA54Wu0PNzb1xO1cE17V8ut5L+lA5giXcWKlWlwDw/fFxnu38mrTE5RQveZCnmcXUuiE0NZsQJ9bdoHAGoJdANMNEob4IUOqiq0xGmZH65yWl0MXsgmYO8kUdu8hsrwy+P9DBEACcHLXFnebQe4B9Akh2bVu5nXxwjZc5BX99/CYpm/5xRSz027xDdc0AA/mP42y1nUpg8byP2Yb6BECOOJofGt0LCF3IAVX6DK7syul4OUd+Wst9fD0QJ4jF6MTuoMCbca8KdafVq6Xqy06Vmx13V7VNrgFkmcdZ7T33QIv7h/2jx29NLxq8ouYR0MXIgs4s37eL0eWVV+qYvJAfMOooEiZJ+RihWwIDFvl9oXgIfIstrmOvXqzls3j9cVn8nbfoVNjGEIDzb6rYVKPJgK6JCLOHciTjwyEjMdHgXbqQLQH5d5sji6AM0AOZDQrAcCAuuT2WPnJpNHPlspWW618EfDPJKLNJ4aAORg/l6b6RkofGB39OLotOn0zr3IjW6sO5CZlBVgO3Myf8p9oamQke9Pm8oWnjfFf2tBVvHG0l+owseQASMFr9hBJ/VjaS1A62fAYXYiaUxd0FbIWCPdaZWdAys8HQEbyKupwjMqqOmFB28ahXe+HkDdvJl6RQnSwKLs72inVjnhWJT81+/tzPWARL3TNh/49JraJa/KFmqV+PBxyanbdb1VkZMtkfT+dVotKbvexKluAgVkq0KqLTQq+MxulbOMvHagtU1V1WDnjTvkQbbKOmqrUqWM1XQOzXGVvYpRdtXNrmjKUMPBCvs+hoQHuRkQlDB1UYEKbIv8W9SURNLtlOIOw4PaS2tGHr66i2EGV/bXG7TUbcAwbC387/h3JlYQdt5548sFtktIOjf6yMwlc5toqkDkvrYJiGnS2eKkUoQPJflyAnRdvdrtsQ1gm08uccloLjwWBeRlJ3Yn3EbHJCYjQHk/B9wBUiYfLNkvmRzPV9nIUupDJneGWoxBcgQMYMLaEPpIc1BPTMonlkBZg/zfJ7ERaIUKijfutRLIFOy5C8Z4QslxPrbYQBW3zht7DKpsxwerfPr6kG09avHMksnuW/wzy59//NU+1revLVn9SDr3RBvLy1WCIT9XEwHItbAOOKw5l2mcDhMfRSD3e8b38W2i5H88UZBhh1a2FL+cxfKylQUJx07L5P53uDUP7xfUaDd3TRqbwin+GCtKYdYAz7bjI42v3oTY6IatUWgEDw3yI7ponQkp5pSqDOzRx50gS/mTZTQJNWHhWjebz0r4GBXxx1OwmN4SVHOHRIvsBYbbYwyh8bpaK4HNmSYXfDa9A/6f4gnazsACtLAM1b4s/ASjBgU9BKHMk3Jhh/Cn+W0jiBzoQDMYkbMUAcuRPyuDGVqoWE8JmyaT+hLGep2IufC3tPBWCwOGzPfnLnAEu4czfORXYOgaqhDGNzcPRCIdxz0b2RXcHAWa9wVd9jisMV9xteC9pqxrerLmT2/e7tCHBJq/XGf5rP/NtO3L/stVXJJXo86X7f5VMa2rBH2xKa/ak8mWYGtOZMy9AVgV2tnDY5FNAbTiwa3NCbAemUnNTDq3vYKT9nrJ/W4RqbYPtTyJkPf4+B4CYzjsJtOR+QPllFQVo2JNh3zY0pUmOOwa33E1i0mXBFGZVVQd80USTJLmULpwLGsPagexT6/766ObtsmSYLTk3Ox2VxH4cMrMLOYp3BeOURbAK2hXN30Y58uNjJ5xKbZGeP9d0apu8G3DS23E0T/GM7HLS9JEPWEhazXwhn1PrkKPOnD5MEYYsFSFiaNCExJsHKsxwb0uVMENLmsRsaSZCm518WrsGlkOzmmxs6Ex/lpUWsbymrsBBgqlwj8cBMwHq5E1f26uUegikS91JdJKZr0uiH+7nkk6rrjN808hcQDz6xTpTTf1adAVREWEKhUMpQv2AsaHpvCZCOxGvHZIRBbQT5xpaGz74q2gcAecz/4HidSzu5TlRNYSX91bqbxNr7UC5uBOLxVDY+Q/ekY4nvlTOV3JTegAAqLquPqvZebop3MnhlK7fm1UTB3/HtT3ybiaBmUZWFFrXqZqC4GGw99wvdGD+NlA9gpBkozZxeF16gaMyInNobFR/8PLzHjYxDi/QzhegSK3BsXp1GAEAOLnGhYxiI+vqqgxQ1hnl4JqbQ7aeCDXXFNsWv2oPjA3DcqKZW3Z2OZn9/Z2tv/BvHosPnoofxKjx7n3gGwFSejlsITX/3ErqYP7NbufsNKWv7aIPXsMiRse+qhZwCsDerxicGnoiwywVa7UG6U6v8JptcssMoO7QkBQahvd0YzSQYq572VjREE+ZidGrQ2TaZTLZwrnj6a3C68d9vcGvyWg9sUSV2u+CC/9/J9aVobDRFoK9bwpYE0s17aFRlu6MJmd6eQSjEm/fZHf9tmdCv3ygsZnkA7grB2YFBWuAHiBKjYqNrUOofQd3heWoeAsjfZwzeLOBeCX3N5Y7TVM9F0gUESXH4WMGe0hvvgyyWLjJPYVD+0NLhbTLIEE4pHur6H1yJ55nB4bVeyiy41b90Nqumf4uFkv6iybJz9gZLDbamwXUUnWmt7NltNxRpm5v1T9jeHqay8zE+lLQGH//uvwVZUJ2dNqd27/hcbKhebqKqpytFRWZxW8CHuNQM/jQb/HgpdhwltZOOZOLcTWRMzEL/2SPNSCuNFnKLu8eKwiA2/h1Pvvit4KOaMvlL/xaBQSVlPJKwUccBmbDXc2oI8cTUl08xeG/oR3e7g3T0C2fH62K+wiQCtNDGHlHGSc4IOZRAW98DurEcZClX7vAHCP6caDQ3bE0bliUlgPTgTAN1CRPyKsUpCZVUxHbeTrPO1eGRpx/QEuVSKLKtDEaJOvDZIOteEbbDZho/X0boAX4IzMA66p3T1sIXJHQ0+aNssb1naJOg12sc4Tq6Wpn7atMlkipdCjwpTfsfuZPn0DP1Qx9srmIEEswTghqok68eXrPYQv22WbwZ139ddChYfzvM0vVVaMNF/+LFbdw2L+xK3KM15wxHhS2I6zgUQ+6Tlcb+XO93F6UYzk0mK9tVsw17A9hvu3GeE/9902elNUo8/o/GT+Zomu9wdzlVaR77DTopSnCvOk6bVuYtIQ5kRct3lGrqEKfvjQLvLFn7LSU83u8tpeHrH53gSqQ+opZa37BVtNPLYuq15sCkoFAnc0Qp3J4OAqOIvvrtrrDkqQBvZj6/Woq7YDI0WwFvZFD3nmdSCVhPZcJYMKjgqO5wi4r6Kw0dIVxuuduTyRSRE65nGYRIGFklGNT6cyWYhjimgpixImQCcfaQYPrPTUI50y08Wjc+9i/deTHhhHJVe5OJwkMqipSujtXok+nwOlFNhCUp3OHkSqDpmQrT4aMvLW30frvOwIRKQZWdNP9noffxHRWKOtNAgozlIgPqhiBy7YMFaK2e7B7x//lutl7ppVrmb/IaB17N/24e09kQJmyGiBADiPDP0UM1KgHn368wV5ukUrfTwQJ/ZX7BGkKuUKSjEZNcgwrgkEV+A4aKDPoXG7962eji3jxrqnlYBiLFxEnWjlUwnAr++u45eICTU3heba9T4hfMm/DmUCWbvo/jGU62BTbDEAsYHNZe50hDEW/etZHYGs4F0TsuXykdttvk8IPXMTG64MRp8D4b3NrQnRFPAXdqsLG6wISpPdSi801S756zi0Xa9ijNxOahGfGaiH5sOv/ODvKfUQ7gRMrB5EAvnyMbDPjYX9CLAY78IAWmAKNQKP3MXMj3Su/0ezQZFO0djbu5Pz0z9h3Em9sxlk5/iMRxYhBvpNvYnqkAfuIGxC5tuVSNFkgs47W12uumYj7znmBbldZK755ZBeVgPW/aaT3P3/4j+zxiAtNh2svSv4cF5YfdynvIbKFCWRcI+rfWAJpvX3jNzOD0Rgq9HBE0xx2jAl/XDEPmpoJwREFNn7P8PM96QZBRo8G/EpkR5KAECdg0FfSXLc6JvFpxX2v4UgbLT0hnlodjdppqI2yGfVweGuV74OJoD7hp3I4nBJnSNQBU0H0+OOdrn1NX15TPKiyE1NdN6LxhVDM7g5xZIUx3xmeuUztn60qR8rwSrQFOBwr4lBx4Nq5MLb7tlixGlRMOKDlCQk6WbHRpx8Nw2XYdqL9WsNjQtllZusG9n+LX6QD8LMXV1cfYjfOGORi8P1dtKY8LX1pTvFXHZtNnhndxQOkZAUq7PPKcbtXbrMPYzzhtOkY8TMwEUGa/18mHfOdt5O+75EBLhLROPeEXOcyg4MuAS+1bSUhHk/N7expOYFdFNMjib8pYzTi4socVTjKJH+/pN0UPwGCZQFVlcq2D55IfTzQqDcUhrJwEbJHxQud0D4mgrgaXBWUkJSnMv4ArbcSxegOCzCpFtIe1rOyrjkmHKbZmcXtNe8Z+vpYUGzJCRMhhuLId8C86UxlPP01EwEJ74nG98NzCm+8pkksj5/fWlKGGydKg1wCsIG/H+/RglAe4PmoaD744n5ZSi1hQQuSAPRTnl/JfSkifeYPg1wDlXM1aTAFFCZIKN9qcaV9ThcSJze+6MBeJl4hkaD/djG18difVCfU+w6CzcrKRUHV/AWW8J6qlIABLDkmHp2qdrsnFoCMp8LYpFXPX23gvlTNrnDtLnmkf0Z8vdUYFkw2UG/2MowESahDs9lu8uK8/8VSEusMwPxYqzJOWVRLGJVDT6AZiDBikldVhHhQ+LW7qymLWEAUsHWPqgwiLrxc4LKYYJ3RdkMnpgfbZiVjL3jnmvHRnsUVuo5MSqAUNKw9lTAImzdYY8apNcXm69wcLY8YMw/6jEknJqE3u73DxohosbhAqgpy0SBKEeVD+hOA7+bKeTWtkQuud3IaigY1w1pKg0Yn8ZV084gdWB4Gj29VQUwAvzGWxlxrOO8vBpjcmUxnz2cSHLiuozkpvGerJDMdIa3if1uuZ/RJyNHoLFBbH60Upz4cJolm3hKd0gTGC+elBlc77MtKhKq1AfBRhVAIDEaiOhonZ3dMz/yJGsh6JlJq1SPUkxtR6yNqgUphde6g9Du1Unjx5KLrl2FUtsSw3SYMdmbfjEXQ/AM8AXguux2ZQNFYlSzVwFm9JmW2/3Xvn3ODF70fzE5ZCwhIBb2EBBw2rL//XEXFq4Ac9tQprXNZs9XQ0N91tv1lMVI7uTvUsshheNa3T6mbc75nsLbx/0W3tWbLxkV8pw7bgQKqbLdKH+AGPjXwt/qRmR2MHEPS3g3SlKb5/JWpOQV0SkKJ8lbPirjoa4+sCPWUjT9ST6XSFauWepRgUuz0poCdwZH4qW4vypNncb4CWHqxR03QaGb7qCEwl9DaOguX4IrYiIIresa8B6tpHugYk/Tn4Fs1qSmkwxlbyvEbChxqo0tOEgFbRmc1QUiKrK3l0BM3NSS9ez9dme599gWDaoMqiX8FMuD+6ZjaicWDEvVfn0jzLz7qAl0Z5lYuVGxSTPceJ2laOq+N+b7+1kBUc3GY6kc6jbJEj7IsMa4oscctv63r719ONByhsVhiGMawMmMw/+YlibKHmQ3+JxinmZSDaTOacsFz/vWWqPfNqE+GUn9BMpEYD3X8e+Z7FaXJSUL3F1lZrYEMrxxax/lr24Hm2bdffopTVoy/tg1tjtPw10DFk3VyXctlvQtL9+mr5ZdAVTjwjc2QdRBrJ1Mq37M7dvOlZqkfYIoqwiU6N2roq+r1TO5I+4HXAAAY0398PEsQ7bM4drqmoeX5Naf28PrURbBDw8P40lH2DuX60U7L55T64R/Yg3+/b6OtX78RfnLCxVIwgMmrBV9/NiC2MNuxGrudiu99tLhzFo0WY4VvZMoHqNMaCSkf4l4p8Q7U3fBfE9j6Ty2EBkPNyy3JYb7N/g0Bxl/pfc1uxvLsfBktNjCZGDsCubH9unlAV6xg8V5lXecAhp1p7TBZ3xnCwqdR9RBlBeWa3uvG+fdbXeFZZBTGyvwWeo6LGQSpNHLsMkyE3DDllHXDFobCFb1ejY89Rqil//UjOaTlN0OOwfrIiDZfDcTxzuGmDmd0mVT1MvNDes3gcp4LYoMh0dFaybwdSDMohajnJmCjbJPpr88V+Ci84nmCnqAxwBidvr579RNOjHrpbicBSnhFiG8a/hc5bTUJxymWHHO51bsV7wOF5VGox6maxrHBzW7mGYkgYXGdEvwRC84yLsOoDWM58CJhXblBwX3gju7pUQ8xBMXE9NkSQ/rDFCu/VWc8gFcLO7DDd8EN0+Mkuozta46DfX+cXGHMEbPJPiqmFuqsDg3c35dL6EV5cp2H6mEmr05cjpZLMK3PIBlmWcpbx/3tvHV6rFy93WTCgJI8d9nK9hjvBjEgkbnLPtk4kzZxPbtQ3Ndr9SsB290ZNJvn38FgHughfi4A95IH4mGqK6ZMpLyIAS8iyhG0PrwcVjEN6lDrKETLd8rHeZSl3y7sK8SAbGgrIHxpKqyIYT9CELzQjYNwtucTLyRmfrauHkjwfK+w6QZxSWEWQ4Le3UKSuNMPSUiQE9oc+O212hY0RlsXIeITmxUsXferZtzOZC3QwmomoCs6OB2qE4VNip6tJRsm5bD40y04nkggsAlCDgnNQ8yOaoIErv/2y60OehDSHZzaQlxG1g84oSxS6P7umCrlqVa+6yaGvKeXB6Taj5bZJA/DNwsTAPFMusYgw54Y/DNqWXwILKZ73ook8Srf3bfMhuxmUFdSaagddiBHF369n3uM2eAgm+K8kO0OpkTR/Ja9qcNjQFi6lAuH4qfjDJQ14bm1EZVOroYI42eZo2llUvXUl+sY+7nvjsZcNgr7rzpjjxLUcQO2N+QNJxxWkycmpxsI09oqW8jbDHEVs1b20QAq66dWSAAAVkiaeblMQrfffLZgt6ym7+HBiKU9gQN9UMQfHhZvxjml0VKoLXpDTdS6twPcBMIQISKoDOVt6JqXEFDc2SVgQH63c9Du4Ctf4LrL6hJBTCXxyTgM2aoDxNrRkKqdAGXlfwcjMshGCSsEiNFFF8ClU39kcgztq2atqyApNltyWicvaHlpjjLoMSBvvUm2M3vYuz300PK+qlJH0CwvsP5qJl+l/SFa0mDJfKdnaVr48a1dVPXElz1OOt82pXxLHgYTxJd6/lfnm4jP6fULgfeaJFVM3L/uj9vTzwnImSFjVs5keQuBQ7EYkyOIkDqlqPGOwsnKdP4gsD6byNF2nSyCRITyPvhG3wYovhbm4c5RXlEFLlyc+vL/YbdSa2fYdUAJpcCcCym4EYR+x2NHCv4qYsi5pKcYdkKbcvjgvM4uj8fpsEoZGcw+vs5Vvgw0PeMmB1SFt2FDv3J9Febqy+J6JCrRi5E1gxr7+ISiaMVw7CDexY8QjN7VE5gMu6Vx5HiOBwvHcjaafgtjm777NoFxEAxE1wSQ51K7pz3DWMD3XnAVRegbqpeYIWx2VX9Lir70nMnI02nrLSEWpYeK3yUcOMGPOnwYsConiCN2GDn4AW1xodn9snpKrWawBOH9Tlc/kLeR5z0QVh0CmBMXyzeGAHl/ODHI9OFbRUm8e688UFi3kcq/rmMH1gWp9n32B00s/pYVv7nKCBESQrJa6hM2Bhskh1pU95NzJhqHJPCHs984QJCTewCbWyAuxEdpgrTHSeKeIuqTIgbQcAl9cHxfbX/WTT2bZSLv4PMUefBbuwixbsNrDCmiBwWojvKTy8eeg1i7LZT8B+8Xx8hSAwDqnPi/aTlkH4+S+e29TstP+ERkcRDqeX1M1f9TMSVDyphkTAjEk4/2AIAAAEbomN3wygWLxogT0Hmlc4pzX4TQOjlZAvymeWlMiQQCrClaeSXb9mBQJhTDtOCrh5wTQXvLYTCSQjMIjyft/PUlA3DGLvrO/xPna4athw6Naqtp9To9K6njP/F9cs+CrO9/SOfsxsTqFcLNkG+4oygcVHdXeCRFX6Rtx/RyBRCkCumsNvPrUUl/DKafe84SQAJO4ZgFov8e1w4offhn7pkUS0374CxsegTjVZwoEMhAWzLf6yako9+INdVLIqMppyBRzo0BfoiMSjniU5eY5gthNPEJLhBjwu/nF99f+UdwU6tsQNXOxcF063Ee6H4EAABw8RQZ6Tek64sw0QDO72b3iLROo1Hsk7rRDKGMih7ZzbqSvZ4lb3Qa46jp2CfRKW46q06uHiKxEkuEXFgpno7pYXYeqVXIvCUOwvhUqH/dd89Dw6imEqhhr4vaYRipQCSSQqgAAAAAAAAAA==";

const SEED_SCHOOLS = buildSeedSchools();

/* ----------------------------------------------------------------------------
 * STORAGE HELPERS
 * -------------------------------------------------------------------------- */

async function loadKey(key, fallback) {
  try {
    if (typeof window === "undefined") return fallback;
    const raw = window.localStorage.getItem(key);
    if (raw != null) return JSON.parse(raw);
  } catch (e) {
    /* not found */
  }
  return fallback;
}

async function saveKey(key, value) {
  try {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.error("Không lưu được", key, e);
  }
}

/* ----------------------------------------------------------------------------
 * SMALL UI PRIMITIVES
 * -------------------------------------------------------------------------- */

function Avatar({ school, size = 56 }) {
  const theme = themeFor(school.id);
  const initials = school.name
    .replace("THPT", "")
    .trim()
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  return (
    <div
      style={{
        width: size, height: size, borderRadius: 14, background: theme.bg, color: theme.text,
        display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700,
        fontSize: size * 0.32, flexShrink: 0, fontFamily: "'Be Vietnam Pro', sans-serif",
      }}
    >
      {initials || "TH"}
    </div>
  );
}

function Pill({ children, tone = "indigo" }) {
  const tones = {
    indigo: { bg: "#EEF2FF", text: "#4338CA" },
    green: { bg: "#ECFDF5", text: "#047857" },
    amber: { bg: "#FFFBEB", text: "#B45309" },
    red: { bg: "#FEF2F2", text: "#B91C1C" },
    gray: { bg: "#F3F4F6", text: "#4B5563" },
  };
  const t = tones[tone];
  return (
    <span style={{ background: t.bg, color: t.text, fontSize: 12, fontWeight: 600, padding: "3px 10px", borderRadius: 999, whiteSpace: "nowrap" }}>
      {children}
    </span>
  );
}

function Button({ children, variant = "primary", onClick, style, type = "button", disabled }) {
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
    fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 600, fontSize: 14.5, borderRadius: 10,
    padding: "11px 20px", cursor: disabled ? "not-allowed" : "pointer", border: "1px solid transparent",
    transition: "transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease", opacity: disabled ? 0.5 : 1,
  };
  const variants = {
    primary: { background: "#4F46E5", color: "#fff", boxShadow: "0 1px 2px rgba(79,70,229,0.3)" },
    secondary: { background: "#fff", color: "#4338CA", border: "1px solid #DDD6FE" },
    ghost: { background: "transparent", color: "#4338CA" },
    danger: { background: "#fff", color: "#DC2626", border: "1px solid #FECACA" },
  };
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseDown={(e) => !disabled && (e.currentTarget.style.transform = "scale(0.97)")}
      onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
      onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
      style={{ ...base, ...variants[variant], ...style }}
    >
      {children}
    </button>
  );
}

function Card({ children, style, onClick, draggable, onDragStart, onDragOver, onDrop }) {
  return (
    <div
      onClick={onClick}
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      style={{ background: "#fff", border: "1px solid #ECEBFB", borderRadius: 16, boxShadow: "0 1px 3px rgba(30,27,75,0.04)", ...style }}
    >
      {children}
    </div>
  );
}

function Field({ label, children, style }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 13, fontWeight: 600, color: "#374151", ...style }}>
      {label}
      {children}
    </label>
  );
}

const inputStyle = {
  border: "1px solid #E5E7EB", borderRadius: 10, padding: "10px 12px", fontSize: 14,
  fontFamily: "'Inter', sans-serif", color: "#1F2937", outline: "none", width: "100%", boxSizing: "border-box",
};

/* ----------------------------------------------------------------------------
 * PAGE HEADER — sticker/emoji lớn kèu tiêu đề, dùng chung cho các trang
 * -------------------------------------------------------------------------- */

function PageHeader({ emoji, title, subtitle, accent = "#EEF2FF" }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 4 }}>
      <div
        style={{
          width: 56, height: 56, borderRadius: 18, background: accent, flexShrink: 0,
          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28,
          boxShadow: "0 4px 14px rgba(79,70,229,0.12)", transform: "rotate(-4deg)",
        }}
      >
        <span style={{ transform: "rotate(4deg)", display: "inline-block" }}>{emoji}</span>
      </div>
      <div>
        <h1 style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 24, color: "#1E1B4B", margin: 0, marginBottom: 2 }}>
          {title}
        </h1>
        {subtitle && <p style={{ fontSize: 13.5, color: "#6B7280", margin: 0 }}>{subtitle}</p>}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * SIDEBAR / SHELL
 * -------------------------------------------------------------------------- */

const NAV_ITEMS = [
  { key: "home",      label: "🏠 Trang chủ",          emoji: "🏠"  },
  { key: "schools",   label: "🏫 Hiểu trường",          emoji: "🏫"  },
  { key: "evaluate",  label: "🎯 Đánh giá cơ hội",      emoji: "🎯"  },
  { key: "wishlist",  label: "🔖 Nguyện vọng của tôi",  emoji: "🔖"  },
  { key: "mocktest",  label: "📝 Phòng luyện đề",       emoji: "📝"  },
  { key: "articles",  label: "📄 Bài viết",              emoji: "📄"  },
  { key: "community", label: "👥 Cộng đồng",             emoji: "👥"  },
];

function Sidebar({ page, setPage }) {
  return (
    <aside
      style={{
        width: 248, flexShrink: 0, borderRight: "1px solid #EFEDFB", background: "#fff",
        display: "flex", flexDirection: "column", padding: "22px 16px", height: "100vh",
        position: "sticky", top: 0, overflowY: "auto",
      }}
    >
      <div style={{ display: "flex", gap: 10, alignItems: "flex-start", padding: "0 8px 22px" }}>
        <div style={{ width: 38, height: 38, borderRadius: 10, background: "#4F46E5", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <GraduationCap size={20} color="#fff" />
        </div>
        <div>
          <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15.5, color: "#1E1B4B", lineHeight: 1.25 }}>
            Chọn trường<br />vào 10
          </div>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#4F46E5", marginTop: 2, fontFamily: "'Be Vietnam Pro', sans-serif" }}>Hiểu trường – Chọn đúng</div>
        </div>
      </div>

      <nav style={{ display: "flex", flexDirection: "column", gap: 2 }}>
        {NAV_ITEMS.map((item) => {
          const active = page === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setPage(item.key)}
              style={{
                display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10,
                border: "none", background: active ? "#EEF2FF" : "transparent", color: active ? "#4338CA" : "#4B5563",
                fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: active ? 600 : 500, fontSize: 14.5,
                cursor: "pointer", textAlign: "left", width: "100%",
              }}
            >
              <span style={{ fontSize: 18 }}>{item.emoji}</span>
              {item.label.replace(/^[^\s]+\s/, "")}
            </button>
          );
        })}
      </nav>

      <div style={{ flex: 1 }} />

      <div style={{ background: "#F5F3FF", borderRadius: 16, padding: 18, textAlign: "center" }}>
        <div style={{ width: 56, height: 56, margin: "0 auto 12px", borderRadius: 14, background: "#EDE9FE", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <Sparkles size={26} color="#7C3AED" />
        </div>
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 13.5, color: "#1E1B4B", marginBottom: 10 }}>
          Đăng nhập để trải nghiệm đầy đủ tính năng
        </div>
        <div style={{ textAlign: "left", display: "flex", flexDirection: "column", gap: 6, marginBottom: 14 }}>
          {["Lưu nguyện vọng", "Nhận gợi ý phù hợp", "Theo dõi lịch sử"].map((t) => (
            <div key={t} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: "#4B5563" }}>
              <CheckCircle2 size={14} color="#4F46E5" />
              {t}
            </div>
          ))}
        </div>
        <Button style={{ width: "100%", padding: "9px 0", fontSize: 13.5 }}>Đăng nhập ngay</Button>
        <div style={{ fontSize: 12.5, color: "#7C7C9C", marginTop: 8, cursor: "pointer" }}>Tạo tài khoản mới</div>
      </div>
    </aside>
  );
}

function TopBar() {
  return (
    <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 32px", borderBottom: "1px solid #EFEDFB", background: "#fff" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, color: "#374151", fontWeight: 600, fontSize: 14.5, cursor: "pointer" }}>
        <MapPin size={17} color="#4F46E5" />
        Hà Nội
        <ChevronDown size={15} />
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <Button variant="secondary">Đăng nhập</Button>
        <Button>Đăng ký</Button>
      </div>
    </header>
  );
}

/* ----------------------------------------------------------------------------
 * HOME PAGE
 * -------------------------------------------------------------------------- */

function FeatureCard({ icon: Icon, iconBg, iconColor, title, desc, cta, ctaColor, onClick }) {
  return (
    <Card style={{ padding: 22, cursor: "pointer" }} onClick={onClick}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: iconBg, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
        <Icon size={22} color={iconColor} />
      </div>
      <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15.5, color: "#1E1B4B", marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 13.5, color: "#6B7280", lineHeight: 1.5, marginBottom: 14 }}>{desc}</div>
      <div style={{ display: "flex", alignItems: "center", gap: 5, color: ctaColor, fontWeight: 600, fontSize: 13.5 }}>
        {cta} <ArrowRight size={15} />
      </div>
    </Card>
  );
}

function latestYearOf(scores) {
  return Math.max(...Object.keys(scores).map(Number));
}

function SchoolCard({ school, onClick }) {
  const latestYear = latestYearOf(school.scores);
  return (
    <Card style={{ overflow: "hidden", cursor: "pointer", flexShrink: 0, width: 256 }} onClick={onClick}>
      <div style={{ height: 120, background: `linear-gradient(135deg, ${themeFor(school.id).bg}, #fff)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <School size={40} color={themeFor(school.id).text} strokeWidth={1.5} />
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15, color: "#1E1B4B", marginBottom: 4 }}>{school.name}</div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12.5, color: "#9CA3AF", marginBottom: 12 }}>
          <MapPin size={13} /> {school.district}, Hà Nội
        </div>
        <div style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 2 }}>Điểm chuẩn {latestYear}</div>
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 22, color: "#4F46E5", marginBottom: 12 }}>
          {school.scores[latestYear].toFixed(2)}
        </div>
        <Button variant="secondary" style={{ width: "100%", padding: "8px 0", fontSize: 13.5 }}>Xem chi tiết</Button>
      </div>
    </Card>
  );
}

function StatBlock({ icon: Icon, value, label }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <div style={{ width: 44, height: 44, borderRadius: 12, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <Icon size={22} color="#4F46E5" />
      </div>
      <div>
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 19, color: "#1E1B4B" }}>{value}</div>
        <div style={{ fontSize: 12.5, color: "#6B7280", lineHeight: 1.3 }}>{label}</div>
      </div>
    </div>
  );
}

function HomePage({ schools, goTo, openSchool }) {
  const featured = [...schools].sort((a, b) => latestYearOf(b.scores) === latestYearOf(a.scores) ? (b.scores[latestYearOf(b.scores)] - a.scores[latestYearOf(a.scores)]) : 0).slice(0, 8);
  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ background: "linear-gradient(120deg, #EEF2FF 0%, #F5F3FF 60%, #FAF5FF 100%)", borderRadius: 24, padding: "40px 40px", display: "flex", alignItems: "center", gap: 36, marginBottom: 32, flexWrap: "wrap" }}>
        <div style={{ flex: "1 1 380px", minWidth: 320 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "#fff", borderRadius: 999, padding: "6px 14px", marginBottom: 16, boxShadow: "0 2px 8px rgba(79,70,229,0.1)" }}>
            <Sparkles size={14} color="#4F46E5" />
            <span style={{ fontSize: 12.5, fontWeight: 700, color: "#4F46E5" }}>Đồng hành cùng bạn vào lớp 10</span>
          </div>
          <h1 style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 36, color: "#1E1B4B", lineHeight: 1.2, margin: 0, marginBottom: 10, letterSpacing: 0.5 }}>
            EDU FIT 10
          </h1>
          <p style={{ fontSize: 15, color: "#52527A", lineHeight: 1.6, marginBottom: 8, maxWidth: 480 }}>
            Giải pháp chọn trường lớp 10 thông minh cho học sinh Hà Nội.
          </p>
          <p style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 16, color: "#4F46E5", marginBottom: 24 }}>
            Thấu hiểu bản thân — Chọn trường như ý
          </p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            <Button onClick={() => goTo("evaluate")} style={{ padding: "13px 24px" }}>Đánh giá cơ hội ngay</Button>
            <Button variant="secondary" onClick={() => goTo("schools")} style={{ padding: "13px 24px" }}>Khám phá trường</Button>
          </div>
        </div>

        <div style={{ flex: "1 1 320px", minWidth: 280, display: "flex", alignItems: "center", justifyContent: "center", gap: 18 }}>
          {/* Hình học sinh nam đội mũ cử nhân, cầm bằng tốt nghiệp — ảnh do người dùng cung cấp, đã tách nền */}
          <div style={{ width: 210, height: 254, flexShrink: 0, position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <div style={{ position: "absolute", inset: -10, borderRadius: "50%", background: "radial-gradient(circle, #EEF2FF 0%, rgba(250,245,255,0) 68%)" }} />
            <span style={{ position: "absolute", top: 6, left: 4, fontSize: 16, opacity: 0.75 }}>✦</span>
            <span style={{ position: "absolute", top: 34, right: 2, fontSize: 13, opacity: 0.65 }}>✦</span>
            <span style={{ position: "absolute", bottom: 30, right: 6, fontSize: 15, opacity: 0.55 }}>✦</span>
            <div style={{ position: "absolute", bottom: 4, width: 150, height: 16, borderRadius: "50%", background: "#E0E7FF" }} />
            <img
              src={BOY_GRAD_IMG}
              alt="Học sinh đội mũ cử nhân cầm bằng tốt nghiệp"
              style={{ position: "relative", width: "100%", height: "100%", objectFit: "contain", filter: "drop-shadow(0 10px 16px rgba(30,27,75,0.18))" }}
            />
          </div>

          {/* Badge thông tin xếp dọc từ trên xuống dưới */}
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {[
              { icon: Landmark, label: "Thông tin trường" },
              { icon: BarChart3, label: "Điểm chuẩn" },
              { icon: CheckCircle2, label: "Khả năng trúng tuyển" },
            ].map((b, i) => {
              const Icon = b.icon;
              return (
                <div key={i} style={{ background: "#fff", borderRadius: 999, boxShadow: "0 4px 14px rgba(79,70,229,0.15)", padding: "9px 16px", display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, fontWeight: 600, color: "#374151", whiteSpace: "nowrap" }}>
                  <Icon size={15} color="#4F46E5" /> {b.label}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <h2 style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 19, color: "#1E1B4B", marginBottom: 16 }}>Khám phá ngay</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: 16, marginBottom: 36 }}>
        <FeatureCard icon={Landmark} iconBg="#EEF2FF" iconColor="#4F46E5" title="Hiểu trường" desc="Xem thông tin, điểm chuẩn, chỉ tiêu, học phí và so sánh các trường THPT." cta="Khám phá" ctaColor="#4F46E5" onClick={() => goTo("schools")} />
        <FeatureCard icon={UserCircle2} iconBg="#ECFDF5" iconColor="#10B981" title="Đánh giá cơ hội" desc="Nhập điểm 3 lần thi gần nhất để xem khả năng trúng tuyển khách quan." cta="Đánh giá ngay" ctaColor="#10B981" onClick={() => goTo("evaluate")} />
        <FeatureCard icon={Bookmark} iconBg="#F0FDF4" iconColor="#22C55E" title="Nguyện vọng của tôi" desc="Lưu và sắp xếp nguyện vọng, theo dõi thứ tự ưu tiên của bạn." cta="Xem ngay" ctaColor="#22C55E" onClick={() => goTo("wishlist")} />
        <FeatureCard icon={ClipboardList} iconBg="#FEF3F2" iconColor="#EF4444" title="Phòng luyện đề" desc="Làm đề trắc nghiệm Toán, Văn, Anh và chấm điểm ngay." cta="Luyện đề ngay" ctaColor="#EF4444" onClick={() => goTo("mocktest")} />
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <h2 style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 19, color: "#1E1B4B", margin: 0 }}>Các trường được quan tâm nhiều</h2>
        <div onClick={() => goTo("schools")} style={{ color: "#4F46E5", fontWeight: 600, fontSize: 13.5, cursor: "pointer" }}>Xem tất cả →</div>
      </div>
      <div style={{ display: "flex", gap: 16, overflowX: "auto", paddingBottom: 8, marginBottom: 36 }}>
        {featured.map((s) => (
          <SchoolCard key={s.id} school={s} onClick={() => openSchool(s.id)} />
        ))}
      </div>

      <div style={{ background: "#F5F3FF", borderRadius: 20, padding: "26px 32px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 24 }}>
        <StatBlock icon={Landmark} value="200+" label="Trường THPT tại Hà Nội" />
        <StatBlock icon={ClipboardList} value="500+" label="Bài test đánh giá năng lực" />
        <StatBlock icon={Users} value="6000+" label="Học sinh đã tin dùng nền tảng" />
        <StatBlock icon={ShieldCheck} value="Bảo mật tuyệt đối" label="Mọi thông tin cá nhân đều được lưu trữ và bảo vệ an toàn" />
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * SCHOOLS PAGE ("Hiểu trường") — list + CRUD + so sánh trường
 * -------------------------------------------------------------------------- */

function emptyForm() {
  return {
    id: null, name: "", district: DISTRICTS[0], type: "Công lập", quota: "", tuition: "",
    address: "", phone: "", email: "", facebook: "", website: "", intro: "",
    score2024: "", score2025: "", score2026: "",
  };
}

function SchoolFormModal({ form, setForm, onClose, onSave }) {
  const update = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const isEdit = !!form.id;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 60, padding: 20 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 18, width: "100%", maxWidth: 560, maxHeight: "90vh", overflowY: "auto", padding: 28 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 18, color: "#1E1B4B" }}>
            {isEdit ? "Sửa thông tin trường" : "Thêm trường mới"}
          </div>
          <button onClick={onClose} style={{ border: "none", background: "#F3F4F6", borderRadius: 8, padding: 6, cursor: "pointer" }}>
            <X size={18} color="#6B7280" />
          </button>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <Field label="Tên trường *">
            <input style={inputStyle} value={form.name} onChange={update("name")} placeholder="VD: THPT Kim Liên" />
          </Field>

          <Field label="Địa chỉ">
            <input style={inputStyle} value={form.address} onChange={update("address")} placeholder="VD: Số 1 Phương Mai, Đống Đa, Hà Nội" />
          </Field>

          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Quận / Huyện" style={{ flex: 1 }}>
              <select style={inputStyle} value={form.district} onChange={update("district")}>
                {DISTRICTS.map((d) => (<option key={d} value={d}>{d}</option>))}
              </select>
            </Field>
            <Field label="Loại trường" style={{ flex: 1 }}>
              <select style={inputStyle} value={form.type} onChange={update("type")}>
                <option>Công lập</option><option>Tư thục</option><option>Chuyên</option>
              </select>
            </Field>
          </div>

          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Chỉ tiêu (học sinh)" style={{ flex: 1 }}>
              <input style={inputStyle} type="number" min="0" value={form.quota} onChange={update("quota")} placeholder="VD: 600" />
            </Field>
            <Field label="Học phí (đ/tháng)" style={{ flex: 1 }}>
              <input style={inputStyle} type="number" min="0" value={form.tuition} onChange={update("tuition")} placeholder="VD: 217000" />
            </Field>
          </div>

          <div style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginTop: 4 }}>Điểm chuẩn theo năm</div>
          <div style={{ fontSize: 11.5, color: "#9CA3AF", marginTop: -8, marginBottom: 4 }}>
            2024 theo thang 50 điểm (Toán, Văn hệ số 2) · 2025–2026 theo thang 30 điểm (không hệ số)
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <Field label="2024 (/50)" style={{ flex: 1 }}>
              <input style={inputStyle} type="number" step="0.01" value={form.score2024} onChange={update("score2024")} placeholder="—" />
            </Field>
            <Field label="2025 (/30)" style={{ flex: 1 }}>
              <input style={inputStyle} type="number" step="0.01" value={form.score2025} onChange={update("score2025")} placeholder="—" />
            </Field>
            <Field label="2026 (/30)" style={{ flex: 1 }}>
              <input style={inputStyle} type="number" step="0.01" value={form.score2026} onChange={update("score2026")} placeholder="—" />
            </Field>
          </div>

          <div style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginTop: 4 }}>Thông tin liên hệ (tùy chọn)</div>
          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Số điện thoại" style={{ flex: 1 }}>
              <input style={inputStyle} value={form.phone} onChange={update("phone")} placeholder="024 xxxx xxxx" />
            </Field>
            <Field label="Email" style={{ flex: 1 }}>
              <input style={inputStyle} value={form.email} onChange={update("email")} placeholder="ten@hanoiedu.vn" />
            </Field>
          </div>
          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Facebook" style={{ flex: 1 }}>
              <input style={inputStyle} value={form.facebook} onChange={update("facebook")} placeholder="facebook.com/..." />
            </Field>
            <Field label="Website" style={{ flex: 1 }}>
              <input style={inputStyle} value={form.website} onChange={update("website")} placeholder="truong.edu.vn" />
            </Field>
          </div>
          <Field label="Giới thiệu trường">
            <textarea style={{ ...inputStyle, minHeight: 80, resize: "vertical", fontFamily: "'Inter', sans-serif" }} value={form.intro} onChange={update("intro")} placeholder="Giới thiệu ngắn về truyền thống, thế mạnh của trường..." />
          </Field>
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 26 }}>
          <Button variant="secondary" onClick={onClose} style={{ flex: 1 }}>Hủy</Button>
          <Button onClick={onSave} style={{ flex: 1 }} disabled={!form.name.trim()}>{isEdit ? "Lưu thay đổi" : "Thêm trường"}</Button>
        </div>
      </div>
    </div>
  );
}

// Danh sách ảnh trường đẹp từ Unsplash (người cầm sách, học sinh, trường học)
const SCHOOL_IMAGES = [
  "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1513258496099-48168024aec0?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1564981797816-1043664bf78d?w=200&h=120&fit=crop",
  "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=200&h=120&fit=crop",
];

function getSchoolImg(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return SCHOOL_IMAGES[h % SCHOOL_IMAGES.length];
}

// Card trường kiểu mới — giống link mẫu: ảnh thật, badge Công lập, tên, địa chỉ, kiểm định, rating, lượt xem
function SchoolListCard({ school, onClick, isFav, onToggleFav }) {
  const latestYear = Math.max(...Object.keys(school.scores).map(Number));
  return (
    <Card style={{ display: "flex", gap: 0, alignItems: "stretch", cursor: "pointer", overflow: "hidden" }} onClick={onClick}>
      {/* Ảnh bên trái */}
      <div style={{ flexShrink: 0, width: 130, position: "relative", overflow: "hidden" }}>
        <img
          src={getSchoolImg(school.id)}
          alt={school.name}
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          onError={(e) => { e.target.style.display = "none"; e.target.parentNode.style.background = themeFor(school.id).bg; }}
        />
        <button
          onClick={(e) => { e.stopPropagation(); onToggleFav(school.id); }}
          title={isFav ? "Bỏ yêu thích" : "Yêu thích"}
          style={{
            position: "absolute", top: 8, right: 8, width: 28, height: 28, borderRadius: 999, border: "none",
            background: "rgba(255,255,255,0.92)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
          }}
        >
          <Heart size={14} color={isFav ? "#EF4444" : "#9CA3AF"} fill={isFav ? "#EF4444" : "none"} />
        </button>
      </div>

      {/* Nội dung */}
      <div style={{ flex: 1, minWidth: 0, padding: "14px 16px", display: "flex", flexDirection: "column", gap: 4 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
          <span style={{ background: "#22C55E", color: "#fff", fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 4 }}>
            {school.type}
          </span>
          {school.accredited && (
            <span style={{ display: "flex", alignItems: "center", gap: 3, fontSize: 11, color: "#10B981" }}>
              <BadgeCheck size={13} /> Kiểm định CLGD
            </span>
          )}
        </div>

        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15, color: "#1E1B4B" }}>
          {school.name}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12.5, color: "#9CA3AF" }}>
          <MapPin size={12} />
          {school.address || `${school.district}, Hà Nội`}
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: 12, color: "#6B7280", flexWrap: "wrap", marginTop: 2 }}>
          {school.rating && (
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <Star size={12} color="#F59E0B" fill="#F59E0B" /> {school.rating.toFixed(1)}
            </span>
          )}
          {school.views && (
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              <Eye size={12} /> {school.views.toLocaleString("vi-VN")} đã xem
            </span>
          )}
          <span style={{ fontWeight: 600, color: "#4F46E5" }}>
            Điểm chuẩn {latestYear}: {school.scores[latestYear].toFixed(2)}
          </span>
          {!!school.tuition && (
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              💰 {Number(school.tuition).toLocaleString("vi-VN")}đ/tháng
            </span>
          )}
          {!!school.admissionRate && (
            <span style={{ display: "flex", alignItems: "center", gap: 3 }}>
              🎯 Tỷ lệ trúng tuyển: {school.admissionRate}
            </span>
          )}
        </div>
      </div>

      {/* Nút bên phải */}
      <div style={{ display: "flex", alignItems: "center", padding: "0 16px", flexShrink: 0 }}>
        <Button variant="secondary" onClick={(e) => { e.stopPropagation(); onClick(); }}
          style={{ background: "#4F46E5", color: "#fff", border: "none", padding: "8px 16px", fontSize: 13 }}>
          Xem chi tiết
        </Button>
      </div>
    </Card>
  );
}

// Modal chi tiết trường theo mẫu ảnh: ảnh lớn, thông tin bên trái (học sinh, kiểm định, năm thành lập, liên hệ), giới thiệu bên phải
function SchoolDetailModal({ school, onClose, onAddWishlist, inWishlist, onCompare }) {
  if (!school) return null;
  const years = Object.keys(school.scores).map(Number).sort();
  const theme = themeFor(school.id);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 20, width: "100%", maxWidth: 760, maxHeight: "90vh", overflowY: "auto" }}>
        <div style={{ height: 220, position: "relative", overflow: "hidden", borderRadius: "20px 20px 0 0" }}>
          <img
            src={`https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=760&h=220&fit=crop`}
            alt={school.name}
            style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
            onError={(e) => { e.target.style.display="none"; }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.55))", borderRadius: "20px 20px 0 0" }} />
          <div style={{ position: "absolute", bottom: 18, left: 22 }}>
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 22, color: "#fff", textShadow: "0 1px 4px rgba(0,0,0,0.5)" }}>
              {school.name}
            </div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.85)", marginTop: 3 }}>
              <MapPin size={13} style={{ display: "inline", marginRight: 4 }} />{school.address || `${school.district}, Hà Nội`}
            </div>
          </div>
          <button onClick={onClose} style={{ position: "absolute", top: 14, right: 14, border: "none", background: "rgba(255,255,255,0.9)", borderRadius: 999, padding: 8, cursor: "pointer" }}>
            <X size={18} color="#374151" />
          </button>
        </div>

        <div style={{ padding: 28, display: "flex", gap: 28, flexWrap: "wrap" }}>
          {/* LEFT: info blocks */}
          <div style={{ width: 220, flexShrink: 0, display: "flex", flexDirection: "column", gap: 16 }}>
            <div>
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 18, color: "#1E1B4B" }}>{school.name.replace("THPT ", "")}</div>
              <Pill tone="green">{school.type}</Pill>
            </div>

            <InfoBlock icon={MapPin} label={school.address || `${school.district}, Hà Nội`} />
            {school.studentCount ? <InfoBlock icon={Users} label={`${school.studentCount.toLocaleString("vi-VN")} học sinh`} sub="Tổng số học sinh" /> : null}
            {school.accredited ? <InfoBlock icon={Star} label="Kiểm định chất lượng giáo dục" /> : null}
            {school.founded ? <InfoBlock icon={Calendar} label={`${school.founded}`} sub="Năm thành lập" /> : null}

            <div>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: "#1E1B4B", marginBottom: 8 }}>Liên hệ</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {school.phone && <ContactRow icon={Phone} value={school.phone} />}
                {school.email && <ContactRow icon={Mail} value={school.email} />}
                {school.facebook && <ContactRow icon={Facebook} value={school.facebook} />}
                {school.website && <ContactRow icon={Globe} value={school.website} />}
                {!school.phone && !school.email && !school.facebook && !school.website && (
                  <div style={{ fontSize: 12.5, color: "#C4C4D8" }}>Chưa có thông tin liên hệ</div>
                )}
              </div>
            </div>
          </div>

          {/* RIGHT: intro + scores */}
          <div style={{ flex: "1 1 320px", minWidth: 280 }}>
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15.5, color: "#1E1B4B", marginBottom: 10, display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ width: 4, height: 18, background: "#4F46E5", borderRadius: 2, display: "inline-block" }} />
              Giới thiệu trường
            </div>
            <div style={{ fontSize: 13.5, color: "#4B5563", lineHeight: 1.7, marginBottom: 20 }}>
              {school.intro || "Thông tin giới thiệu chi tiết về trường sẽ sớm được cập nhật."}
            </div>

            <div style={{ background: "#FAFAFD", borderRadius: 14, padding: 16, marginBottom: 16 }}>
              <div style={{ fontSize: 12.5, color: "#9CA3AF", marginBottom: 10, fontWeight: 600 }}>ĐIỂM CHUẨN CÁC NĂM</div>
              <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
                {years.map((y) => (
                  <div key={y}>
                    <div style={{ fontSize: 12, color: "#9CA3AF" }}>{y}{y === 2025 ? " (quy đổi)" : ""}</div>
                    <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 20, color: theme.text }}>{school.scores[y].toFixed(2)}</div>
                    <div style={{ fontSize: 10.5, color: "#B5B5C9" }}>/ {y <= 2024 ? 50 : 30} điểm{y === 2025 ? " (đã quy đổi sang thang 30)" : ""}</div>
                  </div>
                ))}
              </div>
              <div style={{ fontSize: 11, color: "#9CA3AF", marginTop: 10, lineHeight: 1.4 }}>
                * Từ 2025, Hà Nội đổi cách tính điểm xét tuyển: Toán + Văn + Ngoại ngữ không nhân hệ số (tối đa 30), thay vì (Toán + Văn)×2 + Ngoại ngữ như trước (tối đa 50).
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5, color: "#374151", marginBottom: 8 }}>
              <span>Chỉ tiêu tuyển sinh</span>
              <span style={{ fontWeight: 700 }}>{school.quota ? `${school.quota} học sinh` : "Chưa cập nhật"}</span>
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13.5, color: "#374151", marginBottom: 22 }}>
              <span>Học phí dự kiến</span>
              <span style={{ fontWeight: 700 }}>{school.tuition ? `${Number(school.tuition).toLocaleString("vi-VN")} đ/tháng` : "Chưa cập nhật"}</span>
            </div>

            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <Button variant="secondary" onClick={() => onCompare(school.id)}><Scale size={15} /> So sánh</Button>
              <Button onClick={() => onAddWishlist(school.id)} style={{ flex: 1 }} disabled={inWishlist}>
                <Bookmark size={15} /> {inWishlist ? "Đã trong nguyện vọng" : "Thêm nguyện vọng"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoBlock({ icon: Icon, label, sub }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ width: 36, height: 36, borderRadius: 10, background: "#EEF2FF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <Icon size={17} color="#4F46E5" />
      </div>
      <div>
        {sub && <div style={{ fontSize: 11, color: "#9CA3AF" }}>{sub}</div>}
        <div style={{ fontSize: 13, fontWeight: 600, color: "#374151" }}>{label}</div>
      </div>
    </div>
  );
}

function ContactRow({ icon: Icon, value }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: "#4B5563" }}>
      <Icon size={14} color="#9CA3AF" /> {value}
    </div>
  );
}

// ----- SO SÁNH TRƯỜNG -----
function CompareModal({ schools, compareIds, setCompareIds, onClose, inline = false }) {
  const [query, setQuery] = useState("");
  const selected = compareIds.map((id) => schools.find((s) => s.id === id)).filter(Boolean);
  const candidates = schools.filter((s) => !compareIds.includes(s.id) && s.name.toLowerCase().includes(query.toLowerCase()));

  function addSlot(id) {
    if (compareIds.length >= 3) return;
    setCompareIds((prev) => [...prev, id]);
    setQuery("");
  }
  function removeSlot(id) {
    setCompareIds((prev) => prev.filter((x) => x !== id));
  }

  const years = [2024, 2025, 2026];

  const Wrapper = inline ? "div" : "div";
  const outerStyle = inline
    ? {}
    : { position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 60, padding: 20 };
  const innerStyle = inline
    ? { background: "#fff", borderRadius: 18, width: "100%", padding: 24, border: "1px solid #ECEBFB" }
    : { background: "#fff", borderRadius: 18, width: "100%", maxWidth: 880, maxHeight: "88vh", overflowY: "auto", padding: 24 };

  return (
    <Wrapper style={outerStyle} onClick={inline ? undefined : onClose}>
      <div onClick={inline ? undefined : (e) => e.stopPropagation()} style={innerStyle}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Scale size={20} color="#4F46E5" />
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 18, color: "#1E1B4B" }}>So sánh trường học</div>
          </div>
          {!inline && (
            <button onClick={onClose} style={{ border: "none", background: "#F3F4F6", borderRadius: 8, padding: 6, cursor: "pointer" }}>
              <X size={18} color="#6B7280" />
            </button>
          )}
        </div>
        <div style={{ fontSize: 12.5, color: "#9CA3AF", marginBottom: 18 }}>
          Tiêu chí so sánh: Khoảng cách đến nơi ở · Loại hình trường · Điểm chuẩn 3 năm · Tỷ lệ chọi · Xe đưa đón
        </div>

        <div style={{ overflowX: "auto", marginBottom: 18 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ background: "#FAFAFD" }}>
                {["Tiêu chí", ...Array.from({ length: 3 }, (_, i) => `Trường ${i + 1}`)].map((h) => (
                  <th key={h} style={{ textAlign: "left", padding: "10px 12px", color: "#6B7280", fontWeight: 600, borderBottom: "1px solid #ECEBFB", whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={tdLabelStyle}>Tên trường</td>
                {[0, 1, 2].map((i) => (
                  <td key={i} style={tdStyle}>
                    {selected[i] ? (
                      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                        <Avatar school={selected[i]} size={30} />
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 12.5 }}>{selected[i].name}</div>
                          <button onClick={() => removeSlot(selected[i].id)} style={{ border: "none", background: "none", color: "#DC2626", fontSize: 11, cursor: "pointer", padding: 0 }}>Bỏ chọn</button>
                        </div>
                      </div>
                    ) : (
                      <span style={{ color: "#C4C4D8" }}>Chưa chọn</span>
                    )}
                  </td>
                ))}
              </tr>
              <tr>
                <td style={tdLabelStyle}>Địa chỉ</td>
                {[0, 1, 2].map((i) => (<td key={i} style={tdStyle}>{selected[i]?.address || (selected[i] ? `${selected[i].district}, Hà Nội` : "—")}</td>))}
              </tr>
              <tr>
                <td style={tdLabelStyle}>Loại hình</td>
                {[0, 1, 2].map((i) => (<td key={i} style={tdStyle}>{selected[i]?.type || "—"}</td>))}
              </tr>
              {years.map((y) => (
                <tr key={y}>
                  <td style={tdLabelStyle}>Điểm chuẩn {y} {y <= 2024 ? "(/50)" : "(/30)"}</td>
                  {[0, 1, 2].map((i) => (
                    <td key={i} style={tdStyle}>{selected[i]?.scores?.[y] != null ? selected[i].scores[y].toFixed(2) : "—"}</td>
                  ))}
                </tr>
              ))}
              <tr>
                <td style={tdLabelStyle}>Tỷ lệ trúng tuyển ước tính</td>
                {[0, 1, 2].map((i) => (<td key={i} style={tdStyle}>{selected[i]?.admissionRate || "—"}</td>))}
              </tr>
              <tr>
                <td style={tdLabelStyle}>Xe đưa đón</td>
                {[0, 1, 2].map((i) => (<td key={i} style={tdStyle}>{selected[i] ? (selected[i].busService ? "Có" : "Không") : "—"}</td>))}
              </tr>
              <tr>
                <td style={tdLabelStyle}>Khoảng cách (ước tính)</td>
                {[0, 1, 2].map((i) => (<td key={i} style={tdStyle}>{selected[i]?.distanceKm != null ? `${selected[i].distanceKm} km` : "—"}</td>))}
              </tr>
            </tbody>
          </table>
        </div>

        {compareIds.length < 3 && (
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginBottom: 8 }}>Thêm trường để so sánh ({compareIds.length}/3)</div>
            <div style={{ position: "relative", marginBottom: 10 }}>
              <Search size={16} color="#9CA3AF" style={{ position: "absolute", left: 14, top: 13 }} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm trường..." style={{ ...inputStyle, paddingLeft: 38 }} />
            </div>
            <div style={{ maxHeight: 180, overflowY: "auto", display: "flex", flexDirection: "column", gap: 6 }}>
              {candidates.slice(0, 30).map((s) => (
                <div key={s.id} onClick={() => addSlot(s.id)} style={{ display: "flex", alignItems: "center", gap: 10, padding: 8, borderRadius: 10, cursor: "pointer", border: "1px solid #F3F2FC" }}>
                  <Avatar school={s} size={32} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 12.5, color: "#1E1B4B" }}>{s.name}</div>
                    <div style={{ fontSize: 11, color: "#9CA3AF" }}>{s.district}</div>
                  </div>
                  <Plus size={15} color="#4F46E5" />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </Wrapper>
  );
}

const tdStyle = { padding: "10px 12px", borderBottom: "1px solid #F3F2FC", color: "#374151" };
const tdLabelStyle = { ...tdStyle, fontWeight: 600, color: "#1E1B4B", whiteSpace: "nowrap" };

function SchoolsPage({ schools, detailId, setDetailId, wishlist, setWishlist, favorites, setFavorites }) {
  const [tab, setTab] = useState("info"); // "info" | "compare"
  const [query, setQuery] = useState("");
  const [districtFilter, setDistrictFilter] = useState("Tất cả");
  const [distanceFilter, setDistanceFilter] = useState("Tất cả");
  const [scoreFilter, setScoreFilter] = useState("Tất cả");
  const [typeFilter, setTypeFilter] = useState([]);
  const [compareIds, setCompareIds] = useState([]);
  const [favOnly, setFavOnly] = useState(false);

  function toggleFav(id) {
    setFavorites((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  const hasSearchedOrFiltered =
    query.trim() !== "" ||
    districtFilter !== "Tất cả" ||
    distanceFilter !== "Tất cả" ||
    scoreFilter !== "Tất cả" ||
    typeFilter.length > 0 ||
    favOnly;

  const filtered = useMemo(() => {
    if (!hasSearchedOrFiltered) return [];
    return schools.filter((s) => {
      const matchQuery = s.name.toLowerCase().includes(query.toLowerCase());
      const matchDistrict = districtFilter === "Tất cả" || s.district === districtFilter;
      const matchDistance =
        distanceFilter === "Tất cả" ||
        (s.distanceKm == null) ||
        (distanceFilter === "<2km" && s.distanceKm < 2) ||
        (distanceFilter === "2-5km" && s.distanceKm >= 2 && s.distanceKm <= 5) ||
        (distanceFilter === ">5km" && s.distanceKm > 5);
      const ly = latestYearOf(s.scores);
      const sc = s.scores[ly];
      const matchScore =
        scoreFilter === "Tất cả" ||
        (scoreFilter === "cao" && sc >= 25.5) ||
        (scoreFilter === "tb" && sc >= 23 && sc < 25.5) ||
        (scoreFilter === "thap" && sc < 23);
      const matchType = typeFilter.length === 0 || typeFilter.includes(s.type);
      const matchFav = !favOnly || favorites.includes(s.id);
      return matchQuery && matchDistrict && matchDistance && matchScore && matchType && matchFav;
    });
  }, [hasSearchedOrFiltered, schools, query, districtFilter, distanceFilter, scoreFilter, typeFilter, favOnly, favorites]);

  const detailSchool = schools.find((s) => s.id === detailId) || null;

  function toggleType(t) {
    setTypeFilter((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  }

  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ marginBottom: 18 }}>
        <PageHeader emoji="🏫" title="Hiểu trường" subtitle={`${schools.length} trường THPT · Xem điểm chuẩn, chỉ tiêu, học phí và so sánh trường`} accent="#EEF2FF" />
      </div>

      {/* Banner ảnh học sinh cầm sách đẹp — giống trang mẫu */}
      <div style={{ borderRadius: 20, overflow: "hidden", marginBottom: 20, position: "relative", height: 200 }}>
        <img
          src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1200&h=200&fit=crop&auto=format"
          alt="Học sinh cầm sách"
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          onError={(e) => { e.target.src = "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=1200&h=200&fit=crop"; }}
        />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(79,70,229,0.88) 0%, rgba(79,70,229,0.45) 55%, rgba(79,70,229,0.05) 100%)" }} />
        <div style={{ position: "absolute", top: 0, left: 0, bottom: 0, display: "flex", flexDirection: "column", justifyContent: "center", padding: "0 32px" }}>
          <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 22, color: "#fff", marginBottom: 6 }}>
            📚 Tìm trường phù hợp với bạn
          </div>
          <div style={{ fontSize: 14, color: "rgba(255,255,255,0.9)" }}>
            So sánh điểm chuẩn · Xem vị trí · Đánh giá khả năng trúng tuyển
          </div>
        </div>
      </div>

      {/* Tab: Thông tin trường / So sánh trường */}
      <div style={{ display: "flex", gap: 6, background: "#F3F2FC", borderRadius: 12, padding: 5, marginBottom: 20, width: "fit-content" }}>
        {[
          { key: "info", label: "🏫 Thông tin trường" },
          { key: "compare", label: "⚖️ So sánh trường" },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            style={{
              border: "none", borderRadius: 9, padding: "9px 18px", cursor: "pointer",
              fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 13.5,
              background: tab === t.key ? "#fff" : "transparent",
              color: tab === t.key ? "#4338CA" : "#6B7280",
              boxShadow: tab === t.key ? "0 1px 4px rgba(30,27,75,0.1)" : "none",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "info" ? (
        <>
          <div style={{ display: "flex", gap: 12, marginBottom: 14, flexWrap: "wrap" }}>
            <div style={{ position: "relative", flex: "1 1 280px" }}>
              <Search size={16} color="#9CA3AF" style={{ position: "absolute", left: 14, top: 13 }} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="🔍 Tìm theo tên trường..." style={{ ...inputStyle, paddingLeft: 38 }} />
            </div>
            <button
              onClick={() => setFavOnly((v) => !v)}
              style={{
                display: "flex", alignItems: "center", gap: 7, border: favOnly ? "1px solid #FCA5A5" : "1px solid #E5E7EB",
                background: favOnly ? "#FEF2F2" : "#fff", color: favOnly ? "#DC2626" : "#4B5563", borderRadius: 10,
                padding: "0 16px", cursor: "pointer", fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 600, fontSize: 13.5,
              }}
            >
              <Heart size={15} fill={favOnly ? "#DC2626" : "none"} /> {favOnly ? "Chỉ trường đã thích" : "Hiển thị tất cả trường"}
            </button>
          </div>

          {/* Thanh tiêu chí lọc luôn hiện sẵn */}
          <Card style={{ padding: 18, marginBottom: 18 }}>
            <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
              <div style={{ minWidth: 200 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: "#374151", marginBottom: 8 }}>📍 Địa bàn (Quận/Huyện)</div>
                <select value={districtFilter} onChange={(e) => setDistrictFilter(e.target.value)} style={{ ...inputStyle, width: 200 }}>
                  <option>Tất cả</option>
                  {DISTRICTS.map((d) => (<option key={d} value={d}>{d}</option>))}
                </select>
              </div>
              <div style={{ minWidth: 200 }}>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: "#374151", marginBottom: 8 }}>📊 Mức điểm chuẩn</div>
                <select value={scoreFilter} onChange={(e) => setScoreFilter(e.target.value)} style={{ ...inputStyle, width: 220 }}>
                  <option value="Tất cả">Tất cả mức điểm</option>
                  <option value="cao">Điểm cao (từ 25.5 trở lên)</option>
                  <option value="tb">Điểm trung bình (23.0 - 25.5)</option>
                  <option value="thap">Điểm sàn dưới (dưới 23.0)</option>
                </select>
              </div>
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: "#374151", marginBottom: 8 }}>📏 Khoảng cách so với nơi ở</div>
                <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
                  {["Tất cả", "<2km", "2-5km", ">5km"].map((d) => (
                    <label key={d} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 13, color: "#4B5563", cursor: "pointer" }}>
                      <input type="radio" checked={distanceFilter === d} onChange={() => setDistanceFilter(d)} /> {d}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 600, color: "#374151", marginBottom: 8 }}>🏫 Loại hình trường</div>
                <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
                  {["Công lập", "Tư thục", "Chuyên", "Dân lập", "Dạy nghề"].map((t) => (
                    <label key={t} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 13, color: "#4B5563", cursor: "pointer" }}>
                      <input type="checkbox" checked={typeFilter.includes(t)} onChange={() => toggleType(t)} /> {t}
                    </label>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {!hasSearchedOrFiltered ? (
            <div style={{ textAlign: "center", padding: "70px 20px", color: "#9CA3AF" }}>
              <Search size={34} style={{ marginBottom: 12 }} />
              <div style={{ fontWeight: 700, fontSize: 15.5, color: "#4B5563", marginBottom: 4 }}>Nhập tên trường hoặc chọn tiêu chí lọc để bắt đầu tìm kiếm</div>
              <div style={{ fontSize: 13.5 }}>Danh sách {schools.length} trường THPT sẽ hiện ra ngay khi bạn tìm hoặc lọc</div>
            </div>
          ) : filtered.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: "#9CA3AF" }}>
              <Search size={32} style={{ marginBottom: 10 }} />
              <div style={{ fontWeight: 600, fontSize: 15 }}>Không tìm thấy trường phù hợp</div>
              <div style={{ fontSize: 13.5 }}>Thử đổi từ khóa tìm kiếm hoặc bộ lọc</div>
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {filtered.map((s) => (
                <SchoolListCard key={s.id} school={s} onClick={() => setDetailId(s.id)} isFav={favorites.includes(s.id)} onToggleFav={toggleFav} />
              ))}
            </div>
          )}
        </>
      ) : (
        <CompareModal schools={schools} compareIds={compareIds} setCompareIds={setCompareIds} inline />
      )}

      {detailSchool && (
        <SchoolDetailModal
          school={detailSchool}
          onClose={() => setDetailId(null)}
          onAddWishlist={(id) => setWishlist((prev) => (prev.includes(id) ? prev : [...prev, id]))}
          inWishlist={wishlist.includes(detailSchool.id)}
          onCompare={(id) => { setCompareIds([id]); setDetailId(null); setTab("compare"); }}
        />
      )}
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * EVALUATE PAGE ("Đánh giá cơ hội") — nhập điểm 3 lần thi gần nhất
 * -------------------------------------------------------------------------- */

function chanceFor(myScore, schoolScore) {
  const diff = myScore - schoolScore;
  if (diff >= 1.5) return { label: "Khả năng cao", tone: "green", pct: "≥80%" };
  if (diff >= 0) return { label: "Khả năng trung bình", tone: "amber", pct: "60-80%" };
  if (diff >= -1.5) return { label: "Khá rủi ro", tone: "red", pct: "30-60%" };
  return { label: "Khả năng thấp", tone: "red", pct: "<30%" };
}

function emptyAttempt() {
  return { math: "", literature: "", english: "" };
}

function attemptTotal(a) {
  const m = parseFloat(a.math) || 0;
  const l = parseFloat(a.literature) || 0;
  const e = parseFloat(a.english) || 0;
  return m + l + e;
}

// Haversine — tính khoảng cách (km) giữa 2 tọa độ
function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Tọa độ thật của 8 trường chi tiết (WGS84)
const SCHOOL_COORDS = {
  "s1": { lat: 21.0015, lon: 105.8412 }, // THPT Kim Liên - Phương Mai, Đống Đa
  "s2": { lat: 21.0225, lon: 105.7950 }, // THPT Yên Hòa - Trung Kính, Cầu Giấy
  "s3": { lat: 21.0020, lon: 105.8150 }, // THPT Nhân Chính - Thanh Xuân
  "s4": { lat: 20.9780, lon: 105.7760 }, // THPT Lê Quý Đôn - Hà Đông
  "s5": { lat: 21.0245, lon: 105.8455 }, // THPT Việt Đức - Lý Thường Kiệt, HBT
  "s6": { lat: 21.0400, lon: 105.8340 }, // THPT Phan Đình Phùng - Cửa Bắc, Ba Đình
  "s7": { lat: 20.9890, lon: 105.8480 }, // THPT Hoàng Văn Thụ - Hoàng Mai
  "s8": { lat: 21.0450, lon: 105.8900 }, // THPT Nguyễn Gia Thiều - Long Biên
};

// Tọa độ trung tâm từng quận/huyện Hà Nội
const DISTRICT_COORDS = {
  "Ba Đình":{ lat:21.0370,lon:105.8340 }, "Hoàn Kiếm":{ lat:21.0285,lon:105.8520 },
  "Hai Bà Trưng":{ lat:21.0060,lon:105.8650 }, "Đống Đa":{ lat:21.0210,lon:105.8380 },
  "Tây Hồ":{ lat:21.0760,lon:105.8230 }, "Cầu Giấy":{ lat:21.0300,lon:105.7950 },
  "Thanh Xuân":{ lat:20.9960,lon:105.8120 }, "Hoàng Mai":{ lat:20.9730,lon:105.8600 },
  "Long Biên":{ lat:21.0620,lon:105.9090 }, "Nam Từ Liêm":{ lat:21.0130,lon:105.7640 },
  "Bắc Từ Liêm":{ lat:21.0680,lon:105.7730 }, "Hà Đông":{ lat:20.9730,lon:105.7760 },
  "Đông Anh":{ lat:21.1480,lon:105.8450 }, "Gia Lâm":{ lat:21.0010,lon:105.9280 },
  "Sóc Sơn":{ lat:21.2580,lon:105.8440 }, "Thanh Trì":{ lat:20.9450,lon:105.8450 },
  "Hoài Đức":{ lat:21.0280,lon:105.7370 }, "Đan Phượng":{ lat:21.0930,lon:105.6960 },
  "Thạch Thất":{ lat:21.0630,lon:105.6360 }, "Quốc Oai":{ lat:20.9820,lon:105.6530 },
  "Chương Mỹ":{ lat:20.9400,lon:105.7100 }, "Thanh Oai":{ lat:20.8960,lon:105.7830 },
  "Thường Tín":{ lat:20.8700,lon:105.8640 }, "Ứng Hòa":{ lat:20.7360,lon:105.7760 },
  "Mỹ Đức":{ lat:20.6880,lon:105.7220 }, "Ba Vì":{ lat:21.0790,lon:105.4420 },
  "Sơn Tây":{ lat:21.1380,lon:105.5060 }, "Phúc Thọ":{ lat:21.1010,lon:105.5580 },
  "Mê Linh":{ lat:21.1780,lon:105.7400 }, "Phú Xuyên":{ lat:20.7500,lon:105.9170 },
};

function AttemptInput({ index, attempt, onChange }) {
  const update = (key) => (e) => onChange({ ...attempt, [key]: e.target.value });
  const total = attemptTotal(attempt);
  const filled = attempt.math !== "" && attempt.literature !== "" && attempt.english !== "";
  return (
    <div style={{ border: "1px solid #ECEBFB", borderRadius: 12, padding: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#374151" }}>Lần thi {index + 1}</div>
        {filled && <Pill tone="indigo">{total.toFixed(2)} điểm</Pill>}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input style={{ ...inputStyle, padding: "8px 10px", fontSize: 13 }} type="number" step="0.25" min="0" max="10" value={attempt.math} onChange={update("math")} placeholder="Toán" />
        <input style={{ ...inputStyle, padding: "8px 10px", fontSize: 13 }} type="number" step="0.25" min="0" max="10" value={attempt.literature} onChange={update("literature")} placeholder="Văn" />
        <input style={{ ...inputStyle, padding: "8px 10px", fontSize: 13 }} type="number" step="0.25" min="0" max="10" value={attempt.english} onChange={update("english")} placeholder="Anh" />
      </div>
    </div>
  );
}

// Chọn nơi ở bằng dropdown quận/huyện — không cần API ngoài
function HomeAddressInput({ homeCoords, setHomeCoords }) {
  const districts = Object.keys(DISTRICT_COORDS);
  const [selectedDistrict, setSelectedDistrict] = useState("");
  const [gpsLoading, setGpsLoading] = useState(false);
  const [gpsError, setGpsError] = useState("");

  function handleSelectDistrict(district) {
    setSelectedDistrict(district);
    setGpsError("");
    if (!district) { setHomeCoords(null); return; }
    const c = DISTRICT_COORDS[district];
    setHomeCoords({ lat: c.lat, lon: c.lon, display: `Quận/Huyện ${district}, Hà Nội` });
  }

  function handleGPS() {
    if (!navigator.geolocation) { setGpsError("Trình duyệt không hỗ trợ GPS."); return; }
    setGpsLoading(true);
    setGpsError("");
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setHomeCoords({ lat: pos.coords.latitude, lon: pos.coords.longitude, display: "Vị trí GPS hiện tại" });
        setSelectedDistrict("(GPS)");
        setGpsLoading(false);
      },
      () => { setGpsError("Không lấy được GPS. Hãy chọn quận/huyện thủ công."); setGpsLoading(false); }
    );
  }

  return (
    <div style={{ border: "1.5px solid #C7D2FE", borderRadius: 14, padding: 16, background: "#F5F3FF", marginBottom: 16 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
        <MapPin size={17} color="#4F46E5" />
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14, color: "#1E1B4B" }}>Nơi ở của bạn</div>
        <div style={{ fontSize: 11.5, color: "#9CA3AF" }}>để tính khoảng cách</div>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <select
          value={selectedDistrict}
          onChange={(e) => handleSelectDistrict(e.target.value)}
          style={{ ...inputStyle, flex: 1, fontSize: 13 }}
        >
          <option value="">-- Chọn Quận / Huyện nơi ở --</option>
          {districts.map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>
        <button
          onClick={handleGPS}
          disabled={gpsLoading}
          title="Dùng GPS tự động"
          style={{
            border: "1px solid #DDD6FE", borderRadius: 10, padding: "0 14px",
            background: "#fff", cursor: "pointer", display: "flex", alignItems: "center",
            gap: 5, fontSize: 13, color: "#4F46E5", fontWeight: 600, flexShrink: 0,
            opacity: gpsLoading ? 0.6 : 1,
          }}
        >
          <MapPin size={14} />{gpsLoading ? "..." : "GPS"}
        </button>
      </div>

      {gpsError && <div style={{ fontSize: 12, color: "#DC2626", marginBottom: 6 }}>{gpsError}</div>}

      {homeCoords ? (
        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: "#047857", background: "#ECFDF5", borderRadius: 8, padding: "7px 10px" }}>
          <CheckCircle2 size={14} color="#10B981" />
          <span style={{ fontWeight: 600 }}>Đã chọn: </span>
          <span style={{ color: "#374151" }}>{homeCoords.display}</span>
        </div>
      ) : (
        <div style={{ fontSize: 11.5, color: "#9CA3AF" }}>
          Chọn quận/huyện hoặc bấm GPS → hệ thống tự tính khoảng cách từ nơi ở đến từng trường và đề xuất đường đi ngắn nhất qua Google Maps.
        </div>
      )}
    </div>
  );
}

// Danh sách mẫu trường dạy nghề — gợi ý khi điểm của học sinh thấp hơn nhiều so với các trường THPT trong địa bàn
const VOCATIONAL_SCHOOLS = [
  { name: "Trường Trung cấp nghề Tổng hợp Hà Nội", note: "Đào tạo Công nghệ ô tô, Điện công nghiệp, Nấu ăn" },
  { name: "Trường Cao đẳng nghề Công nghiệp Hà Nội", note: "Đào tạo song song văn hóa THPT + nghề, ra trường sớm" },
  { name: "Trường Trung cấp Kinh tế – Du lịch Hoa Sữa", note: "Thế mạnh Nhà hàng - Khách sạn, Du lịch" },
  { name: "Trường Cao đẳng nghề Việt Nam - Hàn Quốc", note: "Cơ khí, Điện tử, Công nghệ thông tin" },
];

function EvaluatePage({ schools, openSchool }) {
  const [attempts, setAttempts] = useState([emptyAttempt(), emptyAttempt(), emptyAttempt()]);
  const [submitted, setSubmitted] = useState(false);
  const [maxDistKm, setMaxDistKm] = useState(15);
  const [homeCoords, setHomeCoords] = useState(null);
  const [districtFilter, setDistrictFilter] = useState("Tất cả");
  const [typeFilter, setTypeFilter] = useState([]);

  const filledAttempts = attempts.filter((a) => a.math !== "" && a.literature !== "" && a.english !== "");
  const allFilled = filledAttempts.length === 3;

  function toggleType(t) {
    setTypeFilter((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  }

  const average = useMemo(() => {
    if (filledAttempts.length === 0) return 0;
    const sum = filledAttempts.reduce((acc, a) => acc + attemptTotal(a), 0);
    return sum / filledAttempts.length;
  }, [filledAttempts]);

  // Tính khoảng cách thật từ nhà đến từng trường (nếu đã có tọa độ nhà + trường)
  const schoolsWithDist = useMemo(() => {
    return schools
      .filter((s) => s.scores[2026] != null)
      .filter((s) => typeFilter.length === 0 || typeFilter.includes(s.type))
      .map((s) => {
        let realDistKm = null;
        if (homeCoords && SCHOOL_COORDS[s.id]) {
          realDistKm = haversine(homeCoords.lat, homeCoords.lon, SCHOOL_COORDS[s.id].lat, SCHOOL_COORDS[s.id].lon);
        }
        return { ...s, realDistKm };
      });
  }, [schools, homeCoords, typeFilter]);

  // Trường trong địa bàn (quận/huyện) đã chọn — dùng để cảnh báo khi điểm quá thấp so với cả khu vực
  const schoolsInDistrict = useMemo(() => {
    if (districtFilter === "Tất cả") return [];
    return schoolsWithDist.filter((s) => s.district === districtFilter);
  }, [schoolsWithDist, districtFilter]);

  const lowChanceInDistrict = useMemo(() => {
    if (districtFilter === "Tất cả" || schoolsInDistrict.length === 0 || average === 0) return false;
    const minBenchmark = Math.min(...schoolsInDistrict.map((s) => s.scores[2026]));
    return average <= minBenchmark - 3;
  }, [schoolsInDistrict, districtFilter, average]);

  // Các trường ở địa bàn khác mà học sinh có cơ hội trúng tuyển tốt hơn
  const alternativeDistrictSchools = useMemo(() => {
    if (!lowChanceInDistrict) return [];
    return schoolsWithDist
      .filter((s) => s.district !== districtFilter && average >= s.scores[2026] - 1.5)
      .sort((a, b) => (average - a.scores[2026] < average - b.scores[2026] ? 1 : -1))
      .slice(0, 5);
  }, [schoolsWithDist, lowChanceInDistrict, districtFilter, average]);

  const ranked = useMemo(() => {
    return schoolsWithDist
      .filter((s) => districtFilter === "Tất cả" || s.district === districtFilter)
      .map((s) => {
        const benchmark = s.scores[2026];
        const distForFilter = s.realDistKm ?? s.distanceKm;
        return { school: s, benchmark, chance: chanceFor(average, benchmark), distForFilter };
      })
      .filter((r) => !homeCoords || maxDistKm >= 15 || r.distForFilter == null || r.distForFilter <= maxDistKm)
      .sort((a, b) => {
        // Ưu tiên sắp xếp: trường trong tầm khoảng cách lên trước, rồi theo điểm chuẩn
        if (homeCoords) {
          const dA = a.distForFilter ?? 999;
          const dB = b.distForFilter ?? 999;
          if (Math.abs(dA - dB) > 0.5) return dA - dB;
        }
        return a.benchmark - b.benchmark;
      });
  }, [schoolsWithDist, average, homeCoords, maxDistKm, districtFilter]);

  function updateAttempt(i, value) {
    setAttempts((prev) => prev.map((a, idx) => (idx === i ? value : a)));
  }

  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ marginBottom: 24 }}>
        <PageHeader emoji="🎯" title="Đánh giá cơ hội" subtitle="Nhập điểm 3 lần thi và địa chỉ nhà để hệ thống tính khoảng cách & đường đi ngắn nhất đến từng trường" accent="#ECFDF5" />
      </div>

      <div style={{ display: "flex", gap: 24, flexWrap: "wrap", marginBottom: 28 }}>
        <Card style={{ padding: 24, flex: "1 1 340px", maxWidth: 420 }}>

          {/* Địa chỉ nơi ở */}
          <HomeAddressInput homeCoords={homeCoords} setHomeCoords={setHomeCoords} />

          {/* Nhập điểm */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <Calculator size={17} color="#4F46E5" />
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14, color: "#1E1B4B" }}>Điểm 3 lần thi gần nhất</div>
            <div style={{ fontSize: 11.5, color: "#9CA3AF" }}>thang 0–10</div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 14 }}>
            {attempts.map((a, i) => (
              <AttemptInput key={i} index={i} attempt={a} onChange={(v) => updateAttempt(i, v)} />
            ))}
          </div>

          <div style={{ background: "#FAFAFD", borderRadius: 12, padding: 14, marginBottom: 14 }}>
            <div style={{ fontSize: 12.5, color: "#9CA3AF", marginBottom: 4 }}>
              Điểm trung bình {filledAttempts.length > 0 ? `(${filledAttempts.length} lần đã nhập)` : ""}
            </div>
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 26, color: "#4F46E5" }}>
              {average.toFixed(2)} <span style={{ fontSize: 14, color: "#9CA3AF", fontWeight: 600 }}>/ 30</span>
            </div>
          </div>

          {/* Bộ lọc địa bàn & loại trường */}
          <Field label="Địa bàn (Quận/Huyện)" style={{ marginBottom: 14 }}>
            <select value={districtFilter} onChange={(e) => setDistrictFilter(e.target.value)} style={inputStyle}>
              <option>Tất cả</option>
              {DISTRICTS.map((d) => (<option key={d} value={d}>{d}</option>))}
            </select>
          </Field>

          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#374151", marginBottom: 8 }}>Loại trường</div>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              {["Công lập", "Chuyên", "Dân lập", "Dạy nghề"].map((t) => (
                <label key={t} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 13, color: "#4B5563", cursor: "pointer" }}>
                  <input type="checkbox" checked={typeFilter.includes(t)} onChange={() => toggleType(t)} /> {t}
                </label>
              ))}
            </div>
          </div>

          {/* Slider khoảng cách */}
          <Field label={`Lọc khoảng cách tối đa: ${maxDistKm >= 15 ? "Tất cả" : maxDistKm + " km"}`} style={{ marginBottom: 14 }}>
            <input type="range" min="2" max="15" step="1" value={maxDistKm} onChange={(e) => setMaxDistKm(Number(e.target.value))} style={{ width: "100%" }} />
          </Field>

          <Button onClick={() => setSubmitted(true)} disabled={filledAttempts.length === 0} style={{ width: "100%" }}>
            Xem cơ hội trúng tuyển
          </Button>
          {!allFilled && filledAttempts.length > 0 && (
            <div style={{ fontSize: 11.5, color: "#B45309", marginTop: 8 }}>
              * Nên nhập đủ 3 lần thi để kết quả khách quan và chính xác hơn.
            </div>
          )}
        </Card>

        <div style={{ flex: "2 1 480px", display: "flex", flexDirection: "column", gap: 20 }}>
          {!submitted ? (
            <Card style={{ padding: 40, textAlign: "center", color: "#9CA3AF" }}>
              <Calculator size={36} style={{ marginBottom: 12 }} />
              <div style={{ fontWeight: 600, fontSize: 15, color: "#4B5563" }}>Chưa có kết quả đánh giá</div>
              <div style={{ fontSize: 13.5, marginTop: 4 }}>Nhập điểm các lần thi ở bên trái rồi nhấn "Xem cơ hội trúng tuyển"</div>
            </Card>
          ) : (
            <>
              {lowChanceInDistrict && (
                <Card style={{ padding: 20, background: "#FEF2F2", border: "1px solid #FCA5A5" }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                    <AlertTriangle size={20} color="#DC2626" style={{ flexShrink: 0, marginTop: 2 }} />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: "#B91C1C", marginBottom: 4 }}>
                        Điểm của bạn thấp hơn nhiều so với các trường tại {districtFilter}
                      </div>
                      <div style={{ fontSize: 13, color: "#7F1D1D", lineHeight: 1.6 }}>
                        Điểm trung bình {average.toFixed(2)} thấp hơn ít nhất 3 điểm so với toàn bộ trường công lập trong địa bàn này.
                        Bạn nên cân nhắc chọn một địa bàn khác để tăng khả năng trúng tuyển. Dưới đây là một vài gợi ý:
                      </div>
                      {alternativeDistrictSchools.length > 0 && (
                        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 12 }}>
                          {alternativeDistrictSchools.map(({ id, name, district, scores }) => (
                            <div key={id} style={{ background: "#fff", borderRadius: 8, padding: "8px 12px", display: "flex", justifyContent: "space-between", fontSize: 12.5 }}>
                              <span style={{ fontWeight: 600, color: "#1E1B4B", cursor: "pointer" }} onClick={() => openSchool(id)}>{name}</span>
                              <span style={{ color: "#4F46E5" }}>{district} · {scores[2026].toFixed(2)} điểm</span>
                            </div>
                          ))}
                        </div>
                      )}
                      <div style={{ marginTop: 14, borderTop: "1px dashed #FCA5A5", paddingTop: 12 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: "#92400E", marginBottom: 6 }}>🔧 Phương án tham khảo thêm: Trường dạy nghề</div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                          {VOCATIONAL_SCHOOLS.map((v) => (
                            <div key={v.name} style={{ background: "#fff", borderRadius: 8, padding: "8px 12px", fontSize: 12.5 }}>
                              <div style={{ fontWeight: 600, color: "#1E1B4B" }}>{v.name}</div>
                              <div style={{ color: "#9CA3AF" }}>{v.note}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              )}
              <ChanceTable ranked={ranked} average={average} openSchool={openSchool} homeCoords={homeCoords} />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// Bảng "CƠ HỘI TRÚNG TUYỂN CỦA BẠN" — có cột khoảng cách + nút mở đường đi Google Maps
function ChanceTable({ ranked, average, openSchool, homeCoords }) {
  const [selectedIds, setSelectedIds] = useState([]);
  const [pageNum, setPageNum] = useState(1);
  const pageSize = 5;
  const totalPages = Math.max(1, Math.ceil(ranked.length / pageSize));
  const pageItems = ranked.slice((pageNum - 1) * pageSize, pageNum * pageSize);

  function toggleSelect(id) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  // Tạo URL Google Maps đường đi từ nhà → trường (đường ngắn nhất, phương tiện ô tô)
  function getDirectionsUrl(school) {
    const dest = SCHOOL_COORDS[school.id];
    if (!dest) {
      // fallback: tìm tên địa chỉ trường trên Google Maps
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(school.address || school.name + " Hà Nội")}`;
    }
    const destStr = `${dest.lat},${dest.lon}`;
    if (homeCoords) {
      const originStr = `${homeCoords.lat},${homeCoords.lon}`;
      return `https://www.google.com/maps/dir/?api=1&origin=${originStr}&destination=${destStr}&travelmode=driving`;
    }
    return `https://www.google.com/maps/search/?api=1&query=${destStr}`;
  }

  const hasRealDist = ranked.some((r) => r.school.realDistKm != null);

  return (
    <Card style={{ overflow: "hidden" }}>
      <div style={{ background: "linear-gradient(135deg, #6366F1, #818CF8)", padding: "18px 24px", textAlign: "center" }}>
        <div style={{ color: "#fff", fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 18, marginBottom: 6 }}>CƠ HỘI TRÚNG TUYỂN CỦA BẠN</div>
        <div style={{ display: "inline-block", background: "rgba(255,255,255,0.18)", color: "#fff", fontSize: 11.5, padding: "4px 12px", borderRadius: 999 }}>
          * Thông tin này chỉ mang tính tham khảo, không mang tính quyết định.
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "12px 20px", borderBottom: "1px solid #ECEBFB", flexWrap: "wrap", gap: 8 }}>
        <Pill tone="indigo">TS10 Thường</Pill>
        <div style={{ fontSize: 13, color: "#374151" }}>
          Tổng điểm xét tuyển của bạn là <strong>{average.toFixed(2)}</strong> điểm
          {homeCoords && <span style={{ color: "#4F46E5", marginLeft: 10 }}>· Đã tính khoảng cách từ nhà</span>}
        </div>
      </div>

      <div style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, minWidth: hasRealDist ? 820 : 720 }}>
          <thead>
            <tr style={{ background: "#FAFAFD" }}>
              <th style={thStyle}>STT</th>
              <th style={thStyle}>Tên trường</th>
              <th style={thStyle}>Địa chỉ</th>
              <th style={thStyle}>Điểm chuẩn 2026</th>
              <th style={thStyle}>% trúng tuyển</th>
              {hasRealDist && <th style={thStyle}>Khoảng cách</th>}
              {hasRealDist && <th style={thStyle}>Đường đi ngắn nhất</th>}
              <th style={thStyle}>Chọn</th>
            </tr>
          </thead>
          <tbody>
            {pageItems.map(({ school, benchmark, chance }, idx) => (
              <tr key={school.id} style={{ background: selectedIds.includes(school.id) ? "#F5F3FF" : "transparent" }}>
                <td style={tdStyle}>{(pageNum - 1) * pageSize + idx + 1}</td>
                <td style={tdStyle}>
                  <span style={{ color: "#4338CA", fontWeight: 600, cursor: "pointer" }} onClick={() => openSchool(school.id)}>
                    {school.name}
                  </span>
                </td>
                <td style={{ ...tdStyle, maxWidth: 160, whiteSpace: "normal", lineHeight: 1.4 }}>
                  {school.address || `${school.district}, Hà Nội`}
                </td>
                <td style={tdStyle}><strong>{benchmark.toFixed(2)}</strong></td>
                <td style={tdStyle}><Pill tone={chance.tone}>{chance.pct}</Pill></td>
                {hasRealDist && (
                  <td style={tdStyle}>
                    {school.realDistKm != null ? (
                      <span style={{ fontWeight: 700, color: school.realDistKm <= 3 ? "#047857" : school.realDistKm <= 7 ? "#B45309" : "#4B5563" }}>
                        {school.realDistKm.toFixed(1)} km
                      </span>
                    ) : (
                      <span style={{ color: "#C4C4D8" }}>—</span>
                    )}
                  </td>
                )}
                {hasRealDist && (
                  <td style={tdStyle}>
                    <a
                      href={getDirectionsUrl(school)}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{
                        display: "inline-flex", alignItems: "center", gap: 4, padding: "5px 10px",
                        borderRadius: 8, background: "#EEF2FF", color: "#4338CA", fontWeight: 600,
                        fontSize: 12, textDecoration: "none", whiteSpace: "nowrap",
                      }}
                    >
                      <MapPin size={12} />
                      {homeCoords && SCHOOL_COORDS[school.id] ? "Xem đường đi" : "Xem bản đồ"}
                    </a>
                  </td>
                )}
                <td style={tdStyle}>
                  <input type="checkbox" checked={selectedIds.includes(school.id)} onChange={() => toggleSelect(school.id)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 6, padding: "14px 0" }}>
        <button onClick={() => setPageNum((p) => Math.max(1, p - 1))} disabled={pageNum === 1} style={pagerBtnStyle(false)}>‹</button>
        {Array.from({ length: totalPages }, (_, i) => i + 1).slice(0, 8).map((p) => (
          <button key={p} onClick={() => setPageNum(p)} style={pagerBtnStyle(p === pageNum)}>{p}</button>
        ))}
        <button onClick={() => setPageNum((p) => Math.min(totalPages, p + 1))} disabled={pageNum === totalPages} style={pagerBtnStyle(false)}>›</button>
      </div>

      {selectedIds.length > 0 && (() => {
        const selectedRanked = ranked
          .filter((r) => selectedIds.includes(r.school.id))
          .sort((a, b) => b.benchmark - a.benchmark); // điểm chuẩn cao nhất → NV1
        function classify(diff) {
          if (diff >= 1.5) return { label: "An toàn", tone: "green", icon: "💚" };
          if (diff >= 0) return { label: "Vừa sức", tone: "amber", icon: "💛" };
          return { label: "Thách thức", tone: "red", icon: "❤️" };
        }
        return (
          <div style={{ padding: "0 20px 20px" }}>
            <Card style={{ padding: 18, background: "#F5F3FF", border: "1px solid #DDD6FE" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                <Target size={17} color="#4F46E5" />
                <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14, color: "#1E1B4B" }}>
                  Gợi ý xếp nguyện vọng cho {selectedRanked.length} trường đã chọn
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {selectedRanked.map((r, i) => {
                  const c = classify(average - r.benchmark);
                  const nvLabel = i === 0 ? "NV1" : i === 1 ? "NV2" : i === 2 ? "NV3" : `NV${i + 1}`;
                  return (
                    <div key={r.school.id} style={{ background: "#fff", borderRadius: 10, padding: "10px 14px", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                      <span style={{ width: 36, height: 26, borderRadius: 7, background: "#4F46E5", color: "#fff", fontWeight: 700, fontSize: 11.5, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{nvLabel}</span>
                      <span style={{ fontWeight: 600, fontSize: 13, color: "#1E1B4B", flex: 1, minWidth: 140 }}>{r.school.name}</span>
                      <span style={{ fontSize: 12.5, color: "#6B7280" }}>Điểm chuẩn: {r.benchmark.toFixed(2)}</span>
                      <Pill tone={c.tone}>{c.icon} {c.label}</Pill>
                    </div>
                  );
                })}
              </div>
              <div style={{ fontSize: 11.5, color: "#7C7C9C", marginTop: 10 }}>
                💡 Sắp xếp theo điểm chuẩn giảm dần: NV1 là trường điểm cao nhất trong nhóm bạn chọn, NV cuối là trường an toàn nhất.
              </div>
            </Card>
          </div>
        );
      })()}

      <div style={{ display: "flex", gap: 10, justifyContent: "center", padding: "0 20px 20px" }}>
        <Button variant="secondary">Xem lại kết quả</Button>
        <Button disabled={selectedIds.length === 0}>Lưu kết quả ({selectedIds.length})</Button>
      </div>
    </Card>
  );
}

const thStyle = { textAlign: "left", padding: "10px 12px", color: "#6B7280", fontWeight: 600, borderBottom: "1px solid #ECEBFB", whiteSpace: "nowrap", background: "#FAFAFD" };

function pagerBtnStyle(active) {
  return {
    width: 30, height: 30, borderRadius: 8, border: "none", cursor: "pointer",
    background: active ? "#4F46E5" : "#F3F4F6", color: active ? "#fff" : "#4B5563",
    fontWeight: 600, fontSize: 13,
  };
}

/* ----------------------------------------------------------------------------
 * WISHLIST PAGE ("Nguyện vọng của tôi")
 * -------------------------------------------------------------------------- */

function WishlistPage({ schools, wishlist, setWishlist }) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [dragIndex, setDragIndex] = useState(null);
  const [targetScore, setTargetScore] = useState("");

  const wishedSchools = wishlist.map((id) => schools.find((s) => s.id === id)).filter(Boolean);
  const availableSchools = schools.filter((s) => !wishlist.includes(s.id) && s.name.toLowerCase().includes(query.toLowerCase()));

  function addToWishlist(id) { setWishlist((prev) => [...prev, id]); }
  function removeFromWishlist(id) { setWishlist((prev) => prev.filter((x) => x !== id)); }

  function handleDrop(index) {
    if (dragIndex === null || dragIndex === index) return;
    setWishlist((prev) => {
      const next = [...prev];
      const [moved] = next.splice(dragIndex, 1);
      next.splice(index, 0, moved);
      return next;
    });
    setDragIndex(null);
  }

  const targetNum = parseFloat(targetScore);
  const hasTarget = !isNaN(targetNum) && targetScore !== "";

  function safetyFor(school) {
    if (!hasTarget) return null;
    const ly = latestYearOf(school.scores);
    const benchmark = school.scores[ly];
    const diff = targetNum - benchmark;
    if (diff >= 1.5) return { label: "An toàn", tone: "green", icon: "💚" };
    if (diff >= 0) return { label: "Vừa sức", tone: "amber", icon: "💛" };
    return { label: "Rủi ro cao", tone: "red", icon: "❤️" };
  }

  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 18, flexWrap: "wrap", gap: 14 }}>
        <PageHeader emoji="🔖" title="Nguyện vọng của tôi" subtitle={`Kéo thả để sắp xếp thứ tự ưu tiên · ${wishedSchools.length} trường đã chọn`} accent="#F0FDF4" />
        <div style={{ display: "flex", gap: 10 }}>
          {wishedSchools.length >= 2 && (
            <Button variant="secondary" onClick={() => window.print()}>🖨️ Xuất phiếu PDF</Button>
          )}
          <Button onClick={() => setPickerOpen(true)}><Plus size={16} /> Thêm nguyện vọng</Button>
        </div>
      </div>

      {/* Quy tắc xếp nguyện vọng */}
      <div style={{ background: "#FFF7ED", border: "1px solid #FDE68A", borderRadius: 12, padding: "10px 16px", marginBottom: 20, display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 18 }}>💡</span>
        <span style={{ fontSize: 13, color: "#92400E" }}>
          <strong>Quy tắc:</strong> Điểm chuẩn NV1 &gt; NV2 &gt; NV3 — xếp trường có điểm chuẩn cao nhất ở vị trí 1, thấp dần.
          Kéo thả để thay đổi thứ tự.
        </span>
      </div>

      {/* Thanh công cụ thẩm định mức độ an toàn */}
      {wishedSchools.length > 0 && (
        <Card style={{ padding: 18, marginBottom: 20, background: "#F5F3FF", border: "1px solid #DDD6FE" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <ShieldCheck size={18} color="#4F46E5" />
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14, color: "#1E1B4B" }}>
              Thẩm định mức độ an toàn của nguyện vọng
            </div>
          </div>
          <div style={{ fontSize: 12.5, color: "#6B7280", marginBottom: 12 }}>
            Nhập điểm xét tuyển ước tính / mục tiêu chặng cuối của bạn để hệ thống thẩm định từng nguyện vọng: 💚 An toàn · 💛 Vừa sức · ❤️ Rủi ro cao.
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <input
              type="number" step="0.25" min="0" max="30"
              value={targetScore}
              onChange={(e) => setTargetScore(e.target.value)}
              placeholder="VD: 24.5"
              style={{ ...inputStyle, width: 160 }}
            />
            <span style={{ fontSize: 12.5, color: "#9CA3AF" }}>/ 30 điểm (thang 2025–2026)</span>
          </div>
        </Card>
      )}

      {wishedSchools.length === 0 ? (
        <Card style={{ padding: 50, textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 12 }}>🔖</div>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#1E1B4B", marginBottom: 4 }}>Chưa có nguyện vọng nào</div>
          <div style={{ fontSize: 13.5, color: "#9CA3AF", marginBottom: 18 }}>
            Thêm các trường bạn quan tâm để theo dõi và sắp xếp thứ tự nguyện vọng
          </div>
          <Button onClick={() => setPickerOpen(true)} style={{ margin: "0 auto" }}>
            <Plus size={16} /> Thêm nguyện vọng đầu tiên
          </Button>
        </Card>
      ) : (
        <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
          {/* Danh sách kéo thả */}
          <div style={{ flex: "1 1 400px", display: "flex", flexDirection: "column", gap: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 4 }}>✏️ Danh sách nguyện vọng</div>
            {wishedSchools.map((s, i) => {
              const latestYear = latestYearOf(s.scores);
              const nvLabel = i === 0 ? "NV1" : i === 1 ? "NV2" : i === 2 ? "NV3" : `NV${i+1}`;
              const nvColor = i === 0 ? "#4F46E5" : i === 1 ? "#0891B2" : i === 2 ? "#059669" : "#6B7280";
              const safety = safetyFor(s);
              return (
                <Card key={s.id} draggable onDragStart={() => setDragIndex(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => handleDrop(i)}
                  style={{ padding: 14, display: "flex", alignItems: "center", gap: 12, cursor: "grab", borderColor: dragIndex === i ? "#C7D2FE" : "#ECEBFB", background: dragIndex === i ? "#F5F3FF" : "#fff" }}>
                  <GripVertical size={16} color="#C4C4D8" />
                  <div style={{ width: 38, height: 38, borderRadius: 10, background: nvColor, color: "#fff", fontWeight: 800, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    {nvLabel}
                  </div>
                  <Avatar school={s} size={40} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14.5, color: "#1E1B4B" }}>{s.name}</div>
                    <div style={{ fontSize: 12.5, color: "#9CA3AF", display: "flex", alignItems: "center", gap: 4, flexWrap: "wrap" }}>
                      <MapPin size={12} /> {s.district}
                      <span style={{ color: "#4F46E5", fontWeight: 600, marginLeft: 6 }}>
                        Điểm chuẩn {latestYear}: {s.scores[latestYear].toFixed(2)}
                      </span>
                      {safety && (
                        <span style={{ marginLeft: 6 }}>
                          <Pill tone={safety.tone}>{safety.icon} {safety.label}</Pill>
                        </span>
                      )}
                    </div>
                  </div>
                  <button onClick={() => removeFromWishlist(s.id)} style={{ border: "none", background: "#FEF2F2", borderRadius: 8, padding: 8, cursor: "pointer" }}>
                    <Trash2 size={15} color="#DC2626" />
                  </button>
                </Card>
              );
            })}
          </div>

          {/* Phiếu mô phỏng */}
          <div style={{ flex: "1 1 320px", minWidth: 300 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: "#374151", marginBottom: 4 }}>📋 Mô phỏng phiếu đăng ký</div>
            <Card style={{ padding: 20, background: "#FFFDF7", border: "2px solid #FDE68A" }}>
              <div style={{ textAlign: "center", marginBottom: 14 }}>
                <div style={{ fontWeight: 800, fontSize: 13.5, color: "#1E1B4B", textTransform: "uppercase", letterSpacing: 0.5 }}>
                  Phiếu đăng ký nguyện vọng thi vào lớp 10 THPT
                </div>
                <div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>Năm học: 2026 – 2027</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 14, fontSize: 12.5 }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <span style={{ color: "#374151", fontWeight: 600, minWidth: 120 }}>Họ và tên:</span>
                  <span style={{ color: "#9CA3AF", fontStyle: "italic" }}>Học sinh trải nghiệm</span>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <span style={{ color: "#374151", fontWeight: 600, minWidth: 120 }}>Khu vực tuyển sinh:</span>
                  <span style={{ color: "#9CA3AF", fontStyle: "italic" }}>Hà Nội</span>
                </div>
              </div>
              <div style={{ borderTop: "1px solid #FDE68A", paddingTop: 12 }}>
                <div style={{ fontSize: 11.5, fontWeight: 700, color: "#374151", marginBottom: 8 }}>
                  DANH SÁCH NGUYỆN VỌNG
                </div>
                {wishedSchools.slice(0, 5).map((s, i) => {
                  const latestYear = latestYearOf(s.scores);
                  return (
                    <div key={s.id} style={{ display: "flex", gap: 8, padding: "8px 0", borderBottom: i < wishedSchools.length - 1 ? "1px dashed #FDE68A" : "none", alignItems: "center" }}>
                      <div style={{ width: 24, height: 24, borderRadius: 6, background: i === 0 ? "#4F46E5" : i === 1 ? "#0891B2" : "#059669", color: "#fff", fontWeight: 700, fontSize: 11, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                        {i + 1}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, fontSize: 12.5, color: "#1E1B4B" }}>{s.name}</div>
                        <div style={{ fontSize: 11, color: "#9CA3AF" }}>
                          Điểm chuẩn {latestYear}: {s.scores[latestYear].toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
              {wishedSchools.length >= 2 && (
                <div style={{ marginTop: 14 }}>
                  {(() => {
                    const scores = wishedSchools.map(s => s.scores[latestYearOf(s.scores)]);
                    const valid = scores.every((v, i) => i === 0 || scores[i - 1] >= v);
                    return valid ? (
                      <div style={{ background: "#ECFDF5", border: "1px solid #6EE7B7", borderRadius: 8, padding: "7px 12px", fontSize: 12, color: "#047857", display: "flex", alignItems: "center", gap: 6 }}>
                        <CheckCircle2 size={14} /> Thứ tự nguyện vọng hợp lệ (NV1 ≥ NV2 ≥ NV3)
                      </div>
                    ) : (
                      <div style={{ background: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 8, padding: "7px 12px", fontSize: 12, color: "#B91C1C", display: "flex", alignItems: "center", gap: 6 }}>
                        ⚠️ Cần xem lại thứ tự — kéo thả để sắp NV1 có điểm cao nhất
                      </div>
                    );
                  })()}
                </div>
              )}
            </Card>
          </div>
        </div>
      )}

      {pickerOpen && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(30,27,75,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 }} onClick={() => setPickerOpen(false)}>
          <div onClick={(e) => e.stopPropagation()} style={{ background: "#fff", borderRadius: 18, width: "100%", maxWidth: 480, maxHeight: "80vh", display: "flex", flexDirection: "column", padding: 24 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 17, color: "#1E1B4B" }}>
                🔍 Chọn trường thêm vào nguyện vọng
              </div>
              <button onClick={() => setPickerOpen(false)} style={{ border: "none", background: "#F3F4F6", borderRadius: 8, padding: 6, cursor: "pointer" }}>
                <X size={18} color="#6B7280" />
              </button>
            </div>
            <div style={{ position: "relative", marginBottom: 14 }}>
              <Search size={16} color="#9CA3AF" style={{ position: "absolute", left: 14, top: 13 }} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Tìm trường..." style={{ ...inputStyle, paddingLeft: 38 }} />
            </div>
            <div style={{ overflowY: "auto", display: "flex", flexDirection: "column", gap: 8 }}>
              {availableSchools.length === 0 ? (
                <div style={{ textAlign: "center", color: "#9CA3AF", padding: 24, fontSize: 13.5 }}>Không còn trường nào để thêm</div>
              ) : (
                availableSchools.slice(0, 50).map((s) => {
                  const ly = latestYearOf(s.scores);
                  return (
                    <div key={s.id} onClick={() => addToWishlist(s.id)} style={{ display: "flex", alignItems: "center", gap: 10, padding: 10, borderRadius: 10, cursor: "pointer", border: "1px solid #F3F2FC" }}>
                      <Avatar school={s} size={38} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1E1B4B" }}>{s.name}</div>
                        <div style={{ fontSize: 12, color: "#9CA3AF" }}>{s.district} · Điểm chuẩn {ly}: {s.scores[ly].toFixed(2)}</div>
                      </div>
                      <Plus size={16} color="#4F46E5" />
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * MOCK TEST PAGE ("Thi thử") — bộ đề trắc nghiệm mẫu Toán / Văn / Anh
 * -------------------------------------------------------------------------- */

const MOCK_TESTS = {
  math: {
    label: "Toán",
    color: "#4F46E5",
    questions: [
      { q: "Giá trị của biểu thức 2x + 3 khi x = 4 là?", options: ["9", "10", "11", "12"], answer: 2, topic: "Biểu thức đại số" },
      { q: "Phương trình x² − 5x + 6 = 0 có nghiệm là?", options: ["x=2, x=3", "x=1, x=6", "x=-2, x=-3", "x=2, x=-3"], answer: 0, topic: "Phương trình bậc hai" },
      { q: "Cho tam giác vuông có 2 cạnh góc vuông 3cm và 4cm, cạnh huyền bằng?", options: ["5cm", "6cm", "7cm", "8cm"], answer: 0, topic: "Hình học" },
      { q: "Hàm số y = (m-1)x + 2 đồng biến khi?", options: ["m > 1", "m < 1", "m = 1", "m ≠ 1"], answer: 0, topic: "Hàm số bậc nhất" },
      { q: "Diện tích hình tròn bán kính r = 3cm (lấy π ≈ 3.14) là?", options: ["18.84 cm²", "28.26 cm²", "9.42 cm²", "37.68 cm²"], answer: 1, topic: "Hình học" },
      { q: "Tổng hai nghiệm của phương trình x² − 7x + 10 = 0 là?", options: ["5", "7", "10", "-7"], answer: 1, topic: "Phương trình bậc hai" },
      { q: "Cho a > b > 0, biểu thức nào sau đây luôn đúng?", options: ["a² > b²", "a² < b²", "a² = b²", "Không xác định"], answer: 0, topic: "Bất đẳng thức" },
      { q: "Số nghiệm của phương trình |x − 2| = 3 là?", options: ["0", "1", "2", "3"], answer: 2, topic: "Phương trình chứa dấu giá trị tuyệt đối" },
      { q: "Một hình chữ nhật có chu vi 20cm, chiều dài gấp đôi chiều rộng. Diện tích là?", options: ["20 cm²", "22.2 cm²", "24 cm²", "26 cm²"], answer: 1, topic: "Hình học" },
      { q: "Giá trị nhỏ nhất của hàm số y = x² − 4x + 5 là?", options: ["1", "2", "3", "0"], answer: 0, topic: "Hàm số bậc hai" },
    ],
  },
  literature: {
    label: "Ngữ văn",
    color: "#EF4444",
    questions: [
      { q: "Tác phẩm \"Lặng lẽ Sa Pa\" của tác giả nào?", options: ["Nguyễn Thành Long", "Kim Lân", "Nguyễn Quang Sáng", "Tô Hoài"], answer: 0, topic: "Tác giả - tác phẩm" },
      { q: "Bài thơ \"Mùa xuân nho nhỏ\" thể hiện cảm xúc của tác giả về điều gì?", options: ["Tình yêu thiên nhiên", "Khát vọng dâng hiến cho đời", "Nỗi nhớ quê hương", "Tình mẫu tử"], answer: 1, topic: "Đọc hiểu văn bản" },
      { q: "Truyện ngắn \"Chiếc lược ngà\" viết về tình cảm gì?", options: ["Tình bạn", "Tình cha con", "Tình thầy trò", "Tình yêu đôi lứa"], answer: 1, topic: "Đọc hiểu văn bản" },
      { q: "Biện pháp tu từ nào được sử dụng trong câu 'Mặt trời xuống biển như hòn lửa'?", options: ["So sánh", "Nhân hóa", "Ẩn dụ", "Hoán dụ"], answer: 0, topic: "Biện pháp tu từ" },
      { q: "Văn bản \"Bàn về đọc sách\" thuộc thể loại nào?", options: ["Nghị luận xã hội", "Truyện ngắn", "Tản văn", "Hồi ký"], answer: 0, topic: "Thể loại văn bản" },
      { q: "Câu nào sau đây có sử dụng phép nhân hóa?", options: ["Trời thu xanh ngắt", "Ông trời mặc áo giáp đen", "Mây trắng bay nhanh", "Mưa rơi trên mái nhà"], answer: 1, topic: "Biện pháp tu từ" },
      { q: "Tác giả của \"Truyện Kiều\" là ai?", options: ["Nguyễn Du", "Nguyễn Trãi", "Hồ Xuân Hương", "Nguyễn Đình Chiểu"], answer: 0, topic: "Tác giả - tác phẩm" },
      { q: "Trong câu ghép, các vế câu được nối với nhau bằng gì?", options: ["Chỉ dấu phẩy", "Quan hệ từ hoặc dấu câu", "Chỉ liên từ", "Không cần nối"], answer: 1, topic: "Ngữ pháp" },
      { q: "Thể thơ của bài \"Sang thu\" (Hữu Thỉnh) là gì?", options: ["Lục bát", "Thất ngôn bát cú", "Năm chữ", "Tự do"], answer: 2, topic: "Thể loại văn bản" },
      { q: "Phương thức biểu đạt chính của một bài văn nghị luận là gì?", options: ["Tự sự", "Miêu tả", "Nghị luận", "Biểu cảm"], answer: 2, topic: "Phương thức biểu đạt" },
    ],
  },
  english: {
    label: "Tiếng Anh",
    color: "#10B981",
    questions: [
      { q: "Choose the correct word: She ___ to school every day.", options: ["go", "goes", "going", "gone"], answer: 1, topic: "Present simple" },
      { q: "What is the past tense of \"go\"?", options: ["goed", "gone", "went", "going"], answer: 2, topic: "Irregular verbs" },
      { q: "Choose the synonym of \"happy\":", options: ["sad", "joyful", "angry", "tired"], answer: 1, topic: "Vocabulary" },
      { q: "I have lived here ___ 2015.", options: ["for", "since", "in", "at"], answer: 1, topic: "Present perfect" },
      { q: "Choose the correct sentence:", options: ["She don't like coffee.", "She doesn't likes coffee.", "She doesn't like coffee.", "She not like coffee."], answer: 2, topic: "Present simple" },
      { q: "The opposite of \"expensive\" is:", options: ["cheap", "costly", "rich", "valuable"], answer: 0, topic: "Vocabulary" },
      { q: "If it rains, we ___ stay at home.", options: ["will", "would", "did", "are"], answer: 0, topic: "Conditional sentences" },
      { q: "Choose the correct passive form: They build a house.", options: ["A house build by them.", "A house is built by them.", "A house was building.", "A house builds."], answer: 1, topic: "Passive voice" },
      { q: "My brother is interested ___ playing football.", options: ["on", "at", "in", "with"], answer: 2, topic: "Prepositions" },
      { q: "Choose the word with different stress pattern:", options: ["happy", "table", "famous", "machine"], answer: 3, topic: "Pronunciation" },
    ],
  },
};

function MockTestPage() {
  const [subject, setSubject] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  useEffect(() => {
    (async () => {
      const saved = await loadKey("mocktest_history", []);
      setHistory(saved);
      setLoadingHistory(false);
    })();
  }, []);

  function startTest(key) {
    setSubject(key);
    setAnswers({});
    setSubmitted(false);
  }

  function selectAnswer(qIndex, optIndex) {
    setAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
  }

  const test = subject ? MOCK_TESTS[subject] : null;
  const totalQuestions = test ? test.questions.length : 0;
  const correctCount = test
    ? test.questions.reduce((acc, q, i) => acc + (answers[i] === q.answer ? 1 : 0), 0)
    : 0;
  const scoreOnTen = test ? (correctCount / totalQuestions) * 10 : 0;

  // Phân tích điểm yếu theo chủ đề (topic) — dùng để hiển thị "bạn kém ở đâu"
  const topicStats = useMemo(() => {
    if (!test) return [];
    const map = {};
    test.questions.forEach((q, i) => {
      const t = q.topic || "Khác";
      if (!map[t]) map[t] = { topic: t, correct: 0, total: 0 };
      map[t].total += 1;
      if (answers[i] === q.answer) map[t].correct += 1;
    });
    return Object.values(map).sort((a, b) => (a.correct / a.total) - (b.correct / b.total));
  }, [test, answers]);

  const weakTopics = topicStats.filter((t) => t.correct / t.total < 1);
  const wrongQuestions = test
    ? test.questions.map((q, i) => ({ q, i, chosen: answers[i] })).filter((x) => x.chosen !== x.q.answer)
    : [];

  async function finishTest() {
    setSubmitted(true);
    const entry = { subject, subjectLabel: test.label, score: scoreOnTen, correct: correctCount, total: totalQuestions, date: new Date().toISOString() };
    const next = [entry, ...history].slice(0, 20);
    setHistory(next);
    await saveKey("mocktest_history", next);
  }

  if (!subject) {
    return (
      <div style={{ padding: "28px 32px 48px" }}>
        <div style={{ marginBottom: 24 }}>
          <PageHeader emoji="📝" title="Phòng luyện đề" subtitle="Chọn môn để làm bài thi thử trắc nghiệm và tính điểm ngay" accent="#FEF3F2" />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16, marginBottom: 32 }}>
          {Object.entries(MOCK_TESTS).map(([key, t]) => (
            <Card key={key} style={{ padding: 22, cursor: "pointer" }} onClick={() => startTest(key)}>
              <div style={{ width: 44, height: 44, borderRadius: 12, background: `${t.color}15`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
                <ClipboardList size={22} color={t.color} />
              </div>
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 16, color: "#1E1B4B", marginBottom: 6 }}>Đề thi thử {t.label}</div>
              <div style={{ fontSize: 13, color: "#6B7280", marginBottom: 14 }}>{t.questions.length} câu trắc nghiệm · Thang điểm 10</div>
              <div style={{ display: "flex", alignItems: "center", gap: 5, color: t.color, fontWeight: 600, fontSize: 13.5 }}>
                Bắt đầu làm bài <ArrowRight size={15} />
              </div>
            </Card>
          ))}
        </div>

        {!loadingHistory && history.length > 0 && (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
              <Clock size={17} color="#4F46E5" />
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 16, color: "#1E1B4B" }}>Lịch sử thi thử</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8, maxWidth: 560 }}>
              {history.map((h, i) => (
                <Card key={i} style={{ padding: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1E1B4B" }}>{h.subjectLabel}</div>
                    <div style={{ fontSize: 11.5, color: "#9CA3AF" }}>{new Date(h.date).toLocaleString("vi-VN")}</div>
                  </div>
                  <Pill tone={h.score >= 7 ? "green" : h.score >= 5 ? "amber" : "red"}>
                    {h.correct}/{h.total} câu · {h.score.toFixed(1)} điểm
                  </Pill>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ padding: "28px 32px 48px", maxWidth: 720 }}>
      <button onClick={() => setSubject(null)} style={{ display: "flex", alignItems: "center", gap: 6, border: "none", background: "none", color: "#4F46E5", fontWeight: 600, fontSize: 13.5, cursor: "pointer", marginBottom: 16, padding: 0 }}>
        <ChevronRight size={15} style={{ transform: "rotate(180deg)" }} /> Quay lại chọn môn
      </button>

      <h1 style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 22, color: "#1E1B4B", margin: 0, marginBottom: 4 }}>Đề thi thử {test.label}</h1>
      <p style={{ fontSize: 13.5, color: "#6B7280", margin: 0, marginBottom: 22 }}>{totalQuestions} câu trắc nghiệm</p>

      {!submitted ? (
        <>
          <div style={{ display: "flex", flexDirection: "column", gap: 14, marginBottom: 20 }}>
            {test.questions.map((q, qi) => (
              <Card key={qi} style={{ padding: 18 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#1E1B4B", marginBottom: 12 }}>Câu {qi + 1}. {q.q}</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {q.options.map((opt, oi) => (
                    <label key={oi} style={{
                      display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", borderRadius: 9,
                      border: answers[qi] === oi ? "1.5px solid #4F46E5" : "1px solid #E5E7EB",
                      background: answers[qi] === oi ? "#EEF2FF" : "#fff", cursor: "pointer", fontSize: 13.5, color: "#374151",
                    }}>
                      <input type="radio" name={`q${qi}`} checked={answers[qi] === oi} onChange={() => selectAnswer(qi, oi)} />
                      {opt}
                    </label>
                  ))}
                </div>
              </Card>
            ))}
          </div>
          <Button onClick={finishTest} disabled={Object.keys(answers).length < totalQuestions} style={{ width: "100%" }}>
            Nộp bài ({Object.keys(answers).length}/{totalQuestions} câu đã làm)
          </Button>
        </>
      ) : (
        <>
          <Card style={{ padding: 32, textAlign: "center", marginBottom: 20 }}>
            <Award size={40} color={test.color} style={{ marginBottom: 12 }} />
            <div style={{ fontSize: 13.5, color: "#9CA3AF", marginBottom: 6 }}>Kết quả bài thi {test.label}</div>
            <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 800, fontSize: 40, color: test.color, marginBottom: 6 }}>{scoreOnTen.toFixed(1)}</div>
            <div style={{ fontSize: 14, color: "#374151", marginBottom: 22 }}>Đúng {correctCount}/{totalQuestions} câu</div>
            <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
              <Button variant="secondary" onClick={() => startTest(subject)}><RotateCcw size={15} /> Làm lại</Button>
              <Button onClick={() => setSubject(null)}>Chọn môn khác</Button>
            </div>
          </Card>

          {/* Phân tích điểm yếu theo chủ đề */}
          <Card style={{ padding: 22, marginBottom: 20 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <Target size={18} color={test.color} />
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15, color: "#1E1B4B" }}>
                Bạn kém ở đâu?
              </div>
            </div>
            <div style={{ fontSize: 12.5, color: "#9CA3AF", marginBottom: 14 }}>
              Phân tích kết quả theo từng chủ đề để biết nên ôn tập phần nào trước.
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {topicStats.map((t) => {
                const pct = Math.round((t.correct / t.total) * 100);
                const tone = pct === 100 ? "#10B981" : pct >= 50 ? "#F59E0B" : "#EF4444";
                return (
                  <div key={t.topic}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
                      <span style={{ color: "#374151", fontWeight: 600 }}>{t.topic}</span>
                      <span style={{ color: tone, fontWeight: 700 }}>{t.correct}/{t.total} đúng</span>
                    </div>
                    <div style={{ height: 8, background: "#F3F4F6", borderRadius: 999, overflow: "hidden" }}>
                      <div style={{ height: "100%", width: `${pct}%`, background: tone, borderRadius: 999 }} />
                    </div>
                  </div>
                );
              })}
            </div>
            {weakTopics.length > 0 ? (
              <div style={{ marginTop: 16, background: "#FEF2F2", border: "1px solid #FCA5A5", borderRadius: 10, padding: "10px 14px", display: "flex", gap: 8, alignItems: "flex-start" }}>
                <AlertTriangle size={16} color="#DC2626" style={{ flexShrink: 0, marginTop: 1 }} />
                <div style={{ fontSize: 12.5, color: "#B91C1C" }}>
                  <strong>Chủ đề cần ôn thêm:</strong> {weakTopics.map((t) => t.topic).join(", ")}.
                </div>
              </div>
            ) : (
              <div style={{ marginTop: 16, background: "#ECFDF5", border: "1px solid #6EE7B7", borderRadius: 10, padding: "10px 14px", display: "flex", gap: 8, alignItems: "center" }}>
                <CheckCircle2 size={16} color="#10B981" />
                <div style={{ fontSize: 12.5, color: "#047857" }}>Xuất sắc! Bạn đã làm đúng toàn bộ các chủ đề trong đề thi này.</div>
              </div>
            )}
          </Card>

          {/* Danh sách câu sai kèm đáp án đúng để ôn lại */}
          {wrongQuestions.length > 0 && (
            <Card style={{ padding: 22 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                <BookOpen size={18} color="#EF4444" />
                <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15, color: "#1E1B4B" }}>
                  Xem lại {wrongQuestions.length} câu làm sai
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {wrongQuestions.map(({ q, i, chosen }) => (
                  <div key={i} style={{ borderLeft: "3px solid #FCA5A5", paddingLeft: 12 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#1E1B4B", marginBottom: 6 }}>
                      Câu {i + 1}. {q.q}
                      <Pill tone="gray"> {q.topic}</Pill>
                    </div>
                    <div style={{ fontSize: 12.5, color: "#B91C1C", marginBottom: 2 }}>
                      Bạn chọn: {chosen != null ? q.options[chosen] : "(chưa chọn)"}
                    </div>
                    <div style={{ fontSize: 12.5, color: "#047857" }}>
                      Đáp án đúng: {q.options[q.answer]}
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * AI CHATBOT — bong bóng tròn nổi ở góc, gọi Claude API thật dựa trên dữ liệu trường
 * -------------------------------------------------------------------------- */

function buildSchoolsContext(schools) {
  // Tóm tắt ngắn để đưa vào system prompt, tránh quá dài
  const top = [...schools]
    .filter((s) => s.scores[2026] != null)
    .sort((a, b) => b.scores[2026] - a.scores[2026])
    .slice(0, 40)
    .map((s) => `${s.name} (${s.district}) - điểm chuẩn 2026: ${s.scores[2026]}`)
    .join("; ");
  return top;
}

function ChatWidget({ schools }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "assistant", content: "Chào bạn! Mình là trợ lý AI hỗ trợ chọn trường vào lớp 10. Bạn muốn hỏi gì về điểm chuẩn, các trường THPT ở Hà Nội, hay cách chọn nguyện vọng?" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, open]);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;
    const nextMessages = [...messages, { role: "user", content: text }];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);

    try {
      const schoolsContext = buildSchoolsContext(schools);
      const systemPrompt =
        "Bạn là trợ lý AI tư vấn chọn trường THPT cho học sinh và phụ huynh ở Hà Nội, trong app 'Chọn trường vào 10'. " +
        "Trả lời ngắn gọn, thân thiện, bằng tiếng Việt. Dưới đây là dữ liệu điểm chuẩn 2026 (thang 30 điểm, không hệ số) của một số trường để bạn tham khảo khi trả lời: " +
        schoolsContext +
        ". Nếu không có dữ liệu trường được hỏi, hãy nói rõ là bạn không có thông tin chính xác và đề nghị người dùng kiểm tra tại mục Hiểu trường trong app.";

      const apiMessages = nextMessages.slice(-8).map((m) => ({ role: m.role, content: m.content }));

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: systemPrompt,
          messages: apiMessages,
        }),
      });

      const data = await response.json();
      let replyText = "";
      if (data && data.content) {
        replyText = data.content.map((b) => (b.type === "text" ? b.text : "")).filter(Boolean).join("\n");
      }
      if (!replyText) replyText = "Xin lỗi, mình chưa thể trả lời câu này. Bạn thử hỏi lại theo cách khác nhé.";
      setMessages((prev) => [...prev, { role: "assistant", content: replyText }]);
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", content: "Có lỗi khi kết nối tới trợ lý AI. Bạn vui lòng thử lại sau." }]);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  return (
    <>
      {open && (
        <div
          style={{
            position: "fixed", bottom: 96, right: 28, width: 340, maxWidth: "90vw", height: 460,
            background: "#fff", borderRadius: 18, boxShadow: "0 12px 40px rgba(30,27,75,0.22)",
            display: "flex", flexDirection: "column", overflow: "hidden", zIndex: 100,
            border: "1px solid #ECEBFB",
          }}
        >
          <div style={{ background: "linear-gradient(135deg, #4F46E5, #6366F1)", padding: "14px 16px", display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 32, height: 32, borderRadius: 999, background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Bot size={18} color="#fff" />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ color: "#fff", fontWeight: 700, fontSize: 13.5, fontFamily: "'Be Vietnam Pro', sans-serif" }}>Trợ lý chọn trường AI</div>
              <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 10.5 }}>Luôn sẵn sàng hỗ trợ bạn</div>
            </div>
            <button onClick={() => setOpen(false)} style={{ border: "none", background: "rgba(255,255,255,0.15)", borderRadius: 999, padding: 6, cursor: "pointer" }}>
              <X size={15} color="#fff" />
            </button>
          </div>

          <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: 14, display: "flex", flexDirection: "column", gap: 10 }}>
            {messages.map((m, i) => (
              <div key={i} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start" }}>
                <div style={{
                  maxWidth: "85%", padding: "8px 12px", borderRadius: 12, fontSize: 13, lineHeight: 1.5,
                  background: m.role === "user" ? "#4F46E5" : "#F3F4F6",
                  color: m.role === "user" ? "#fff" : "#374151", whiteSpace: "pre-wrap",
                }}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div style={{ display: "flex", justifyContent: "flex-start" }}>
                <div style={{ padding: "8px 12px", borderRadius: 12, background: "#F3F4F6", color: "#9CA3AF", fontSize: 13 }}>Đang trả lời...</div>
              </div>
            )}
          </div>

          <div style={{ padding: 12, borderTop: "1px solid #ECEBFB", display: "flex", gap: 8 }}>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Hỏi về trường, điểm chuẩn..."
              style={{ ...inputStyle, flex: 1, padding: "9px 12px", fontSize: 13 }}
            />
            <button onClick={sendMessage} disabled={loading || !input.trim()} style={{ border: "none", background: "#4F46E5", borderRadius: 10, width: 38, height: 38, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, opacity: loading || !input.trim() ? 0.5 : 1 }}>
              <Send size={16} color="#fff" />
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen((v) => !v)}
        style={{
          position: "fixed", bottom: 28, right: 28, width: 58, height: 58, borderRadius: "50%",
          background: "linear-gradient(135deg, #4F46E5, #818CF8)", border: "none", cursor: "pointer",
          display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 6px 20px rgba(79,70,229,0.4)",
          zIndex: 100,
        }}
        title="Hỏi trợ lý AI"
      >
        {open ? <X size={24} color="#fff" /> : <MessageSquare size={24} color="#fff" />}
      </button>
    </>
  );
}

/* ----------------------------------------------------------------------------
 * ARTICLES PAGE ("Bài viết") — tin tuyển sinh & review kinh nghiệm thi cử
 * -------------------------------------------------------------------------- */

const ARTICLES = [
  {
    id: "a1",
    tag: "Điểm chuẩn",
    tone: "indigo",
    title: "Toàn cảnh điểm chuẩn lớp 10 Hà Nội 2026: Trường nào tăng, trường nào giảm?",
    excerpt: "Phân tích biến động điểm chuẩn NV1 so với năm 2025 tại 30 quận huyện, chỉ ra nhóm trường có mức tăng mạnh nhất.",
    author: "Ban biên tập EduFit",
    date: "10/07/2026",
    img: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=500&h=300&fit=crop",
  },
  {
    id: "a2",
    tag: "Kinh nghiệm",
    tone: "green",
    title: "Thủ khoa Toán chia sẻ lộ trình ôn 3 tháng nước rút trước kỳ thi",
    excerpt: "Bí quyết phân bổ thời gian, luyện dạng đề hình học thực tế và cách giữ tâm lý ổn định trong phòng thi.",
    author: "Trần Minh Hoàng — Thủ khoa Chuyên KHTN",
    date: "08/07/2026",
    img: "https://images.unsplash.com/photo-1513258496099-48168024aec0?w=500&h=300&fit=crop",
  },
  {
    id: "a3",
    tag: "Tuyển sinh",
    tone: "amber",
    title: "Hướng dẫn đăng ký nguyện vọng: Những lỗi phụ huynh hay mắc phải",
    excerpt: "Tổng hợp các sai sót thường gặp khi xếp NV1, NV2, NV3 khiến học sinh trượt oan dù đủ điểm.",
    author: "Ban biên tập EduFit",
    date: "05/07/2026",
    img: "https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?w=500&h=300&fit=crop",
  },
  {
    id: "a4",
    tag: "Tâm lý thi cử",
    tone: "red",
    title: "Áp lực phòng thi: Làm sao để con giữ bình tĩnh trước giờ G?",
    excerpt: "Chuyên gia tâm lý học đường gợi ý các bài tập hít thở và cách trò chuyện cùng con trong tuần thi.",
    author: "ThS. Tâm lý học đường Ngọc Anh",
    date: "02/07/2026",
    img: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=500&h=300&fit=crop",
  },
  {
    id: "a5",
    tag: "Kinh nghiệm",
    tone: "green",
    title: "Á khoa Văn: Cách viết mở bài nghị luận xã hội ăn trọn điểm",
    excerpt: "Công thức 3 bước mở bài không sáo rỗng, áp dụng được cho mọi dạng đề nghị luận xã hội lớp 10.",
    author: "Phạm Thu Trang — Á khoa THPT Kim Liên",
    date: "28/06/2026",
    img: "https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=500&h=300&fit=crop",
  },
  {
    id: "a6",
    tag: "Điểm chuẩn",
    tone: "indigo",
    title: "So sánh thang điểm 2024 và 2025-2026: Vì sao Hà Nội đổi cách tính?",
    excerpt: "Giải thích chi tiết sự thay đổi từ thang 50 (nhân hệ số) sang thang 30 và ảnh hưởng đến chiến lược chọn trường.",
    author: "Ban biên tập EduFit",
    date: "20/06/2026",
    img: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=500&h=300&fit=crop",
  },
];

function ArticleCard({ article }) {
  return (
    <Card style={{ overflow: "hidden", cursor: "pointer" }}>
      <div style={{ height: 150, overflow: "hidden" }}>
        <img src={article.img} alt={article.title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
      </div>
      <div style={{ padding: 16 }}>
        <div style={{ marginBottom: 8 }}>
          <Pill tone={article.tone}>{article.tag}</Pill>
        </div>
        <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14.5, color: "#1E1B4B", marginBottom: 6, lineHeight: 1.4 }}>
          {article.title}
        </div>
        <div style={{ fontSize: 12.5, color: "#6B7280", lineHeight: 1.5, marginBottom: 14 }}>
          {article.excerpt}
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11.5, color: "#9CA3AF" }}>
          <span>{article.author}</span>
          <span>{article.date}</span>
        </div>
      </div>
    </Card>
  );
}

function ArticlesPage() {
  const [tagFilter, setTagFilter] = useState("Tất cả");
  const tags = ["Tất cả", "Điểm chuẩn", "Kinh nghiệm", "Tuyển sinh", "Tâm lý thi cử"];
  const filtered = tagFilter === "Tất cả" ? ARTICLES : ARTICLES.filter((a) => a.tag === tagFilter);

  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ marginBottom: 20 }}>
        <PageHeader emoji="📄" title="Bài viết" subtitle="Tin tức tuyển sinh & review kinh nghiệm thi cử từ các thủ khoa, á khoa" accent="#FDF2F8" />
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 22, flexWrap: "wrap" }}>
        {tags.map((t) => (
          <button
            key={t}
            onClick={() => setTagFilter(t)}
            style={{
              border: "none", borderRadius: 999, padding: "8px 16px", cursor: "pointer",
              fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 600, fontSize: 13,
              background: tagFilter === t ? "#4F46E5" : "#F3F2FC",
              color: tagFilter === t ? "#fff" : "#4B5563",
            }}
          >
            {t}
          </button>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 18 }}>
        {filtered.map((a) => (
          <ArticleCard key={a.id} article={a} />
        ))}
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * COMMUNITY PAGE ("Cộng đồng") — Confession ẩn danh + Mini-livestream cố vấn
 * -------------------------------------------------------------------------- */

const SAMPLE_CONFESSIONS = [
  { id: "c1", content: "Còn 3 tháng nữa thi mà điểm Toán vẫn dậm chân tại chỗ, mọi người có mẹo nào luyện đề hình hiệu quả hơn không? 😥", time: "2 giờ trước", likes: 24, replies: 6 },
  { id: "c2", content: "Vừa thi thử xong được 24.5/30, so với điểm chuẩn năm ngoái của trường mình nhắm thì hơi run 😅 Có ai cùng cảnh không?", time: "5 giờ trước", likes: 41, replies: 13 },
  { id: "c3", content: "Bố mẹ mình cứ so sánh với 'con nhà người ta' suốt, áp lực kinh khủng. Có bạn nào tìm được cách nói chuyện với phụ huynh mà không cãi nhau không? 🙏", time: "1 ngày trước", likes: 87, replies: 22 },
];

function ConfessionCard({ post, onLike }) {
  return (
    <Card style={{ padding: 16 }}>
      <div style={{ display: "flex", gap: 10 }}>
        <div style={{ width: 34, height: 34, borderRadius: 999, background: "#EEF2FF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <UserCircle2 size={20} color="#4F46E5" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
            <span style={{ fontWeight: 700, fontSize: 13, color: "#1E1B4B" }}>Ẩn danh</span>
            <span style={{ fontSize: 11.5, color: "#9CA3AF" }}>{post.time}</span>
          </div>
          <div style={{ fontSize: 13.5, color: "#374151", lineHeight: 1.6, marginBottom: 10 }}>{post.content}</div>
          <div style={{ display: "flex", gap: 16 }}>
            <button onClick={onLike} style={{ display: "flex", alignItems: "center", gap: 5, border: "none", background: "none", cursor: "pointer", color: "#6B7280", fontSize: 12.5, padding: 0 }}>
              <ThumbsUp size={14} /> {post.likes}
            </button>
            <span style={{ display: "flex", alignItems: "center", gap: 5, color: "#6B7280", fontSize: 12.5 }}>
              <MessageCircle size={14} /> {post.replies} bình luận
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
}

function CommunityPage() {
  const [posts, setPosts] = useState(SAMPLE_CONFESSIONS);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [reminderSet, setReminderSet] = useState(false);

  useEffect(() => {
    (async () => {
      const saved = await loadKey("community_confessions", null);
      if (saved && saved.length) setPosts(saved);
      setLoading(false);
    })();
  }, []);

  async function postConfession() {
    const text = draft.trim();
    if (!text) return;
    const entry = { id: `c${Date.now()}`, content: text, time: "Vừa xong", likes: 0, replies: 0 };
    const next = [entry, ...posts];
    setPosts(next);
    setDraft("");
    await saveKey("community_confessions", next);
  }

  function likePost(id) {
    setPosts((prev) => {
      const next = prev.map((p) => (p.id === id ? { ...p, likes: p.likes + 1 } : p));
      saveKey("community_confessions", next);
      return next;
    });
  }

  return (
    <div style={{ padding: "28px 32px 48px" }}>
      <div style={{ marginBottom: 20 }}>
        <PageHeader emoji="👥" title="Cộng đồng" subtitle="Nơi kết nối, chia sẻ gánh nặng tâm lý thi cử và nhận mẹo thực chiến từ các thủ khoa, á khoa" accent="#ECFDF5" />
      </div>

      <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
        <div style={{ flex: "2 1 420px", display: "flex", flexDirection: "column", gap: 16 }}>
          {/* Đăng confession ẩn danh */}
          <Card style={{ padding: 18 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <Megaphone size={18} color="#4F46E5" />
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14, color: "#1E1B4B" }}>Đăng bài viết ẩn danh (Confession)</div>
            </div>
            <textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              placeholder="Chia sẻ áp lực, thắc mắc hay câu chuyện ôn thi của bạn... (hoàn toàn ẩn danh)"
              style={{ ...inputStyle, minHeight: 76, resize: "vertical", fontFamily: "'Inter', sans-serif", marginBottom: 10 }}
            />
            <div style={{ display: "flex", justifyContent: "flex-end" }}>
              <Button onClick={postConfession} disabled={!draft.trim()}>
                <Send size={15} /> Đăng Confession
              </Button>
            </div>
          </Card>

          {/* Dòng trạng thái thảo luận */}
          <div style={{ fontSize: 13, fontWeight: 700, color: "#374151" }}>Dòng trạng thái thảo luận gần đây</div>
          {loading ? (
            <div style={{ color: "#9CA3AF", fontSize: 13 }}>Đang tải...</div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {posts.map((p) => (
                <ConfessionCard key={p.id} post={p} onLike={() => likePost(p.id)} />
              ))}
            </div>
          )}
        </div>

        <div style={{ flex: "1 1 280px", minWidth: 280 }}>
          {/* Mini-livestream cố vấn */}
          <Card style={{ padding: 0, overflow: "hidden" }}>
            <div style={{ background: "linear-gradient(135deg, #4F46E5, #818CF8)", padding: "16px 18px", display: "flex", alignItems: "center", gap: 8 }}>
              <Radio size={18} color="#fff" />
              <div style={{ color: "#fff", fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 14 }}>✨ Lịch Mini-Livestream Cố vấn</div>
            </div>
            <div style={{ padding: 18 }}>
              <div style={{ marginBottom: 10 }}>
                <Pill tone="red">🔴 LIVE sắp diễn ra</Pill>
              </div>
              <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 15, color: "#1E1B4B", marginBottom: 8, lineHeight: 1.4 }}>
                Bí kíp "nuốt trọn" 0.5 điểm hình thực tế lớp 10
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                <div style={{ width: 30, height: 30, borderRadius: 999, background: "#EEF2FF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                  <UserCircle2 size={18} color="#4F46E5" />
                </div>
                <div style={{ fontSize: 12.5, color: "#6B7280" }}>
                  Cố vấn: <strong style={{ color: "#374151" }}>Thủ khoa Trần Minh Hoàng</strong><br />Chuyên KHTN
                </div>
              </div>
              <Button
                onClick={() => setReminderSet(true)}
                disabled={reminderSet}
                style={{ width: "100%" }}
                variant={reminderSet ? "secondary" : "primary"}
              >
                {reminderSet ? <><CheckCircle2 size={15} /> Đã đặt lịch nhắc</> : <><PlayCircle size={15} /> Đặt lịch nhắc hẹn</>}
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * PLACEHOLDER PAGES
 * -------------------------------------------------------------------------- */

function PlaceholderPage({ icon: Icon, title, desc }) {
  return (
    <div style={{ padding: "60px 32px", textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 16, background: "#EEF2FF", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}>
        <Icon size={30} color="#4F46E5" />
      </div>
      <div style={{ fontFamily: "'Be Vietnam Pro', sans-serif", fontWeight: 700, fontSize: 18, color: "#1E1B4B", marginBottom: 6 }}>{title}</div>
      <div style={{ fontSize: 14, color: "#9CA3AF" }}>{desc}</div>
    </div>
  );
}

/* ----------------------------------------------------------------------------
 * ROOT APP
 * -------------------------------------------------------------------------- */

export default function App() {
  const [page, setPage] = useState("home");
  const [schools, setSchoolsState] = useState(SEED_SCHOOLS);
  const [wishlist, setWishlistState] = useState([]);
  const [favorites, setFavoritesState] = useState([]);
  const [detailId, setDetailId] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const savedSchools = await loadKey("schools", null);
      const savedWishlist = await loadKey("wishlist", []);
      const savedFavorites = await loadKey("favorites", []);
      if (savedSchools && savedSchools.length) setSchoolsState(savedSchools);
      else await saveKey("schools", SEED_SCHOOLS);
      setWishlistState(savedWishlist || []);
      setFavoritesState(savedFavorites || []);
      setLoading(false);
    })();
  }, []);

  const setSchools = useCallback((updater) => {
    setSchoolsState((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveKey("schools", next);
      return next;
    });
  }, []);

  const setWishlist = useCallback((updater) => {
    setWishlistState((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveKey("wishlist", next);
      return next;
    });
  }, []);

  const setFavorites = useCallback((updater) => {
    setFavoritesState((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      saveKey("favorites", next);
      return next;
    });
  }, []);

  function openSchool(id) {
    setPage("schools");
    setDetailId(id);
  }

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: "#FAFAFD", minHeight: "100vh", display: "flex", color: "#1F2937" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Be+Vietnam+Pro:wght@600;700;800&display=swap');
        * { box-sizing: border-box; }
        input:focus, select:focus, textarea:focus { border-color: #818CF8 !important; box-shadow: 0 0 0 3px rgba(129,140,248,0.18); }
        ::-webkit-scrollbar { height: 8px; width: 8px; }
        ::-webkit-scrollbar-thumb { background: #DDD6FE; border-radius: 8px; }
      `}</style>

      <Sidebar page={page} setPage={setPage} />

      <div style={{ flex: 1, minWidth: 0 }}>
        <TopBar />

        {loading ? (
          <div style={{ padding: 60, textAlign: "center", color: "#9CA3AF" }}>Đang tải dữ liệu...</div>
        ) : (
          <>
            {page === "home" && <HomePage schools={schools} goTo={setPage} openSchool={openSchool} />}
            {page === "schools" && (
              <SchoolsPage schools={schools} detailId={detailId} setDetailId={setDetailId} wishlist={wishlist} setWishlist={setWishlist} favorites={favorites} setFavorites={setFavorites} />
            )}
            {page === "evaluate" && <EvaluatePage schools={schools} openSchool={openSchool} />}
            {page === "wishlist" && <WishlistPage schools={schools} wishlist={wishlist} setWishlist={setWishlist} />}
            {page === "mocktest" && <MockTestPage />}
            {page === "articles" && <ArticlesPage />}
            {page === "community" && <CommunityPage />}
          </>
        )}
      </div>

      <ChatWidget schools={schools} />
    </div>
  );
}
