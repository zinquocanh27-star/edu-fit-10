import App from "@/components/diem-chuan-app"

export default function Page() {
  return <App />
}
